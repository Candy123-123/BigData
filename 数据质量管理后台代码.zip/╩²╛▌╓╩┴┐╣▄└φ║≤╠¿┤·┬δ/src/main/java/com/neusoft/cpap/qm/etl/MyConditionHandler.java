package com.neusoft.cpap.qm.etl;

import org.springframework.stereotype.Component;

import com.espertech.esper.client.hook.ConditionHandler;
import com.espertech.esper.client.hook.ConditionHandlerContext;
@Component
public class MyConditionHandler implements ConditionHandler {

	@Override
	public void handle(ConditionHandlerContext context) {
		//System.out.println(context.getEngineCondition());
	
		// TODO Auto-generated method stub
		//System.out.println("detected exception");
	}

}
