package com.neusoft.cpap.qm.vo;

import java.util.List;

import lombok.Data;
/**
 * 下拉列表key-value
 * @author tengh
 *
 */
@Data
public class ComboxVo {
	private String label;
	private String value;
	private List<ComboxVo> enumList;
}
