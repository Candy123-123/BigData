package com.neusoft.cpap.conductor.entity;

import com.neusoft.cpap.conductor.model.EtlProcessGroup;

public class EtlProcessGroups{
	private EtlProcessGroupPo primaryEtlProcessGroup;
	private EtlProcessGroupPo secondaryEtlProcessGroup;
	public EtlProcessGroupPo getPrimaryEtlProcessGroup() {
		return primaryEtlProcessGroup;
	}
	public void setPrimaryEtlProcessGroup(EtlProcessGroupPo primaryEtlProcessGroup) {
		this.primaryEtlProcessGroup = primaryEtlProcessGroup;
	}
	public EtlProcessGroupPo getSecondaryEtlProcessGroup() {
		return secondaryEtlProcessGroup;
	}
	public void setSecondaryEtlProcessGroup(EtlProcessGroupPo secondaryEtlProcessGroup) {
		this.secondaryEtlProcessGroup = secondaryEtlProcessGroup;
	}
	
}
