package com.neusoft.cpap.qm.dao;

import java.util.List;
import java.util.Map;

import com.neusoft.cpap.qm.vo.BaseTaskResult;
import com.neusoft.cpap.qm.vo.BasicRuleVo;
import com.neusoft.cpap.qm.vo.DataSourceVo;
import com.neusoft.cpap.qm.vo.QmSampleRatioTab;
import com.neusoft.cpap.qm.vo.QmSourceTab;
import com.nokia.sai.micro.framework.dao.BaseDao;

public interface QmConfigDao extends BaseDao{
	List<DataSourceVo> queryDataSourceList(Map<?,?> paramMap);
	void addDataSourceList(DataSourceVo dataSourceVo);
	void delDataSourceList(String id);
	List<BasicRuleVo> queryBasicRuleList(Map<?,?> paramMap);
	void addCustomRule(Map map);
	void delCustomRule(String id);
	int checkExistCustomName(Map map);
	List<QmSourceTab> queryDsourceData(Map<?,?> paramMap);
	List<QmSampleRatioTab> querySamepleRatio(Map<String, Object> map);
	void delSamepleRatio(List<Long> listId);
	List<BaseTaskResult> queryStatis(Map map);
	List querySchemeId(Map map);
}
