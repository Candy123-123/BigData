package com.neusoft.cpap.qm.etl;

import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class Process {

	private String processName;
	private List<Node> processNode;
	
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public List<Node> getProcessNode() {
		return processNode;
	}
	public void setProcessNode(List<Node> processNode) {
		this.processNode = processNode;
	}
	@Override
	public String toString() {
		return "Process [processName=" + processName + ", processNode="
				+ processNode + "]";
	}
	

}
