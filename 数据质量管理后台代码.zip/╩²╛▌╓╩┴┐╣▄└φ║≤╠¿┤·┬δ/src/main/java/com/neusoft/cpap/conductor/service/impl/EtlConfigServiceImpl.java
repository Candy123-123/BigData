package com.neusoft.cpap.conductor.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.base.Joiner;
import com.neusoft.cpap.conductor.common.ActionEnum;
import com.neusoft.cpap.conductor.common.Constants;
import com.neusoft.cpap.conductor.dao.EtlConfigDao;
import com.neusoft.cpap.conductor.entity.EtlNodeValuePo;
import com.neusoft.cpap.conductor.entity.EtlProcessGroupMapPo;
import com.neusoft.cpap.conductor.entity.EtlProcessGroupPo;
import com.neusoft.cpap.conductor.entity.EtlProcessGroups;
import com.neusoft.cpap.conductor.entity.EtlProcessNodeExecPo;
import com.neusoft.cpap.conductor.entity.EtlProcessNodePo;
import com.neusoft.cpap.conductor.entity.EtlProcessPo;
import com.neusoft.cpap.conductor.entity.EtlTimerJobPo;
import com.neusoft.cpap.conductor.entity.vo.EtlOptionVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessExecVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessListVo;
import com.neusoft.cpap.conductor.model.EtlNodeValue;
import com.neusoft.cpap.conductor.model.EtlOptionValue;
import com.neusoft.cpap.conductor.model.EtlProcess;
import com.neusoft.cpap.conductor.model.EtlProcessGroup;
import com.neusoft.cpap.conductor.model.EtlProcessGroupMap;
import com.neusoft.cpap.conductor.model.EtlProcessNode;
import com.neusoft.cpap.conductor.model.EtlTimerJob;
import com.neusoft.cpap.conductor.model.EtlUserConfig;
import com.neusoft.cpap.conductor.service.EtlConfigCommonService;
import com.neusoft.cpap.conductor.service.EtlConfigService;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;
import com.nokia.sai.micro.framework.util.IdUtil;


@Service
@Transactional
public class EtlConfigServiceImpl implements EtlConfigService {
	private static final Logger logger = LoggerFactory.getLogger(EtlConfigServiceImpl.class);
	private static final String SERVICE_NAME = "etl.service.EtlConfigServiceImpl";

	@Autowired
	private EtlConfigCommonService etlConfigCommonService;

	@Autowired
	private EtlConfigDao etlConfigdao;
	/**缓冲字节*/
    public static final int BUFFER = 1024;
	// 保存etl（包括新增和修改）
	public ResultEntity saveEtlProcessPo(EtlProcessPo etlProcessPo) throws Exception {
		ResultEntity resultEntity = new ResultEntity();
		resultEntity.setStatus(true);
		try {
			Long newProcessId=etlConfigdao.selectProcessId();
			EtlProcess etlProcess = etlProcessPo.getEtlProcess();
//			etlProcess.setUserId(BaseContextHandler.getUsername());
			if (etlProcess == null) {
				logger.warn("{} saveEtlProcessVo getEtlProcess is null", SERVICE_NAME);
				resultEntity.setStatus(false);
				return resultEntity;
			}
			int ProcessNameIfExists= etlConfigdao.selectProcessNameIfExists(etlProcessPo.getEtlProcess().getProcessCode());
			Map paramMap=new HashMap();
			paramMap.put("id", etlProcess.getId());
			List<EtlProcess> originalName=etlConfigdao.selectEtlProcess(paramMap);
			
			if (etlProcessPo.getAction() == ActionEnum.add.type) {
				if(ProcessNameIfExists>0) {
					logger.warn("{} saveEtlProcessVo name repeat", SERVICE_NAME);
					resultEntity.setStatus(false);
					resultEntity.setException(new Exception("流程名字重复"));
					return resultEntity;
				}
				etlProcess.setId(newProcessId);
				etlConfigCommonService.insertEtlProcess(etlProcess);
			} else {
				if(ProcessNameIfExists>0&&!etlProcess.getProcessCode().equals(originalName.get(0).getProcessCode())) {
					logger.warn("{} saveEtlProcessVo name repeat", SERVICE_NAME);
					resultEntity.setStatus(false);
					resultEntity.setException(new Exception("流程名字重复"));
					return resultEntity;
				}
				etlConfigCommonService.updateEtlProcess(etlProcess);
			}

			List<EtlProcessNodePo> etlProcessNodeVoList = etlProcessPo.getEtlProcessNodeVoList();
			if (etlProcessNodeVoList == null || etlProcessNodeVoList.size() == 0) {
				logger.warn("{} saveEtlProcessVo getEtlProcessNodeVoList is null", SERVICE_NAME);
			} else {
				int k=0;
				for (int i=0;i<etlProcessNodeVoList.size();i++) {
					EtlProcessNodePo etlProcessNodeVo=etlProcessNodeVoList.get(i);
					etlProcessNodeVo.getEtlProcessNode().setProcessId(etlProcess.getId());
					if(etlProcessNodeVo.getAction()== ActionEnum.add.type) {
						etlProcessNodeVo.getEtlProcessNode().setId(Long.valueOf(newProcessId+this.fillZeroBeforeNum(5, (i+1))));
					}
					
					saveEtlProcessNodeVo(etlProcessNodeVo);
					
					Long nodeId = etlProcessNodeVo.getEtlProcessNode().getId();
					List<EtlNodeValuePo> etlNodeValueVoList = etlProcessNodeVo.getEtlNodeValueVoList();
					if (etlNodeValueVoList == null || etlNodeValueVoList.size() == 0) {
						logger.warn("{} saveEtlProcessVo getEtlNodeValueVoList is null", SERVICE_NAME);
					} else {
						for (int j=0;j<etlNodeValueVoList.size();j++) {
							k++;
							EtlNodeValuePo etlNodeValueVo=etlNodeValueVoList.get(j);
							etlNodeValueVo.getEtlNodeValue().setNodeId(nodeId);
							if(etlNodeValueVo.getAction()== ActionEnum.add.type) {
								etlNodeValueVo.getEtlNodeValue().setId(Long.valueOf(newProcessId+this.fillZeroBeforeNum(5, k)));
							}
							
							saveEtlNodeValueVo(etlNodeValueVo);
						}
					}
				}
			}
			EtlTimerJobPo etlTimerJobVo = etlProcessPo.getEtlTimerJobVo();
			if (etlTimerJobVo == null) {
				logger.warn("{} saveEtlProcessVo getEtlTimerJobVo is null", SERVICE_NAME);
			} else {
				etlTimerJobVo.getEtlTimerJob().setProcessId(etlProcess.getId());
				if (etlProcessPo.getAction() == ActionEnum.add.type) {
					etlTimerJobVo.getEtlTimerJob().setId(Long.valueOf(newProcessId+this.fillZeroBeforeNum(5, 1)));
				}
				
				saveEtlTimerJobVo(etlTimerJobVo);
			}
			
			//EtlProcessGroup
			EtlProcessGroups etlProcessGroups=etlProcessPo.getEtlProcessGroups();
			if (etlProcessGroups == null) {
				logger.warn("{} saveEtlProcessVo getEtlProcessGroups is null", SERVICE_NAME);
			} else {
				saveEtlProcessGroupPo(etlProcessGroups.getPrimaryEtlProcessGroup());
				saveEtlProcessGroupPo(etlProcessGroups.getSecondaryEtlProcessGroup());
			}
			
			//EtlProcessGroupMap
			EtlProcessGroupMapPo etlProcessGroupMapPo=etlProcessPo.getEtlProcessGroupMapPo();
			if (etlProcessGroupMapPo == null) {
				logger.warn("{} saveEtlProcessVo getEtlProcessGroupMapPo is null", SERVICE_NAME);
			} else {
				etlProcessGroupMapPo.getEtlProcessGroupMap().setProcessId(etlProcess.getId());
				if (etlProcessGroupMapPo.getEtlProcessGroupMap().getId()==null) {
					etlProcessGroupMapPo.getEtlProcessGroupMap().setId(Long.valueOf(newProcessId+this.fillZeroBeforeNum(5, 1)));
				}
				saveEtlProcessGroupMapPo(etlProcessGroupMapPo);
			}
			
			resultEntity.setData(etlProcess.getId());
		} catch (Exception e) {
			resultEntity.setStatus(false);
			throw e;
		}
		return resultEntity;
	}
	
	// etl_process_group 保存
	public void saveEtlProcessGroupPo(EtlProcessGroupPo etlProcessGroupPo) throws InterruptedException {
		if (etlProcessGroupPo.getAction() == ActionEnum.add.type) {
			Thread.sleep(1);
			etlConfigCommonService.insertEtlProcessGroup(etlProcessGroupPo.getEtlProcessGroup());
		} else {
			
		}
	}
	
	// etl_process_group_map 保存
	public void saveEtlProcessGroupMapPo(EtlProcessGroupMapPo etlProcessGroupMapPo) throws InterruptedException {
		EtlProcessGroupMap etlProcessGroupMap = etlProcessGroupMapPo.getEtlProcessGroupMap();
		if (etlProcessGroupMapPo.getAction() == ActionEnum.add.type) {
			Thread.sleep(1);
			etlConfigCommonService.insertEtlProcessGroupMap(etlProcessGroupMap);
		} else {
			
		}
	}

	// etl_process_node 保存
	public void saveEtlProcessNodeVo(EtlProcessNodePo etlProcessNodeVo) throws InterruptedException {
		EtlProcessNode etlProcessNode = etlProcessNodeVo.getEtlProcessNode();
		if (etlProcessNodeVo.getAction() == ActionEnum.add.type) {
			Thread.sleep(1);
			etlConfigCommonService.insertEtlProcessNode(etlProcessNode);
		}else if(etlProcessNodeVo.getAction() == ActionEnum.del.type) {
			if(Constants.IS_REAL_DEL) {
				etlConfigCommonService.deleteEtlProcessNode(etlProcessNode);
			}else {
				etlConfigCommonService.updateEtlProcessNode(etlProcessNode);
			}
		}
		else if(etlProcessNodeVo.getAction() == ActionEnum.update.type){
			etlConfigCommonService.updateEtlProcessNode(etlProcessNode);
		}
	}

	// etl_node_value 保存
	public void saveEtlNodeValueVo(EtlNodeValuePo etlNodeValueVo) throws InterruptedException {
		EtlNodeValue etlNodeValue = etlNodeValueVo.getEtlNodeValue();
		if (etlNodeValueVo.getAction() == ActionEnum.add.type) {
			Thread.sleep(1);
			etlConfigCommonService.insertEtlNodeValue(etlNodeValue);
		} else if (etlNodeValueVo.getAction() == ActionEnum.update.type){
			etlConfigCommonService.updateEtlNodeValue(etlNodeValue);
		}
	}

	// etl_timer_job 保存
	public void saveEtlTimerJobVo(EtlTimerJobPo etlTimerJobVo) {
		EtlTimerJob etlTimerJob = etlTimerJobVo.getEtlTimerJob();
		if (etlTimerJobVo.getAction() == ActionEnum.add.type) {
			etlConfigCommonService.insertEtlTimerJob(etlTimerJob);
		} else {
			etlConfigCommonService.updateEtlTimerJob(etlTimerJob);
		}
	}

	// 查询etl
	public EtlProcessPo queryEtlProcessVo(Long etlProcessId) throws Exception {
		EtlProcessPo etlProcessVo = new EtlProcessPo();
		// EtlProcess
		Map paramMap = new HashMap();
		paramMap.put("id", etlProcessId);
		/*
		 * if(!("admin").equals(BaseContextHandler.getUsername())) {
		 * paramMap.put("userId", BaseContextHandler.getUsername()); }
		 */
		List<EtlProcess> etlProcessList = etlConfigdao.selectEtlProcess(paramMap);
		etlProcessVo.setEtlProcess(etlProcessList.get(0));
		// EtlProcessNodeVo
		List<EtlProcessNodePo> etlProcessNodeVoList=new ArrayList<EtlProcessNodePo>();
		List<EtlProcessNode> etlProcessNodeList = etlConfigdao.selectEtlProcessNodeByProcessId(etlProcessId);
		for(EtlProcessNode etlProcessNode:etlProcessNodeList) {
			EtlProcessNodePo etlProcessNodeVo=new EtlProcessNodePo();
			etlProcessNodeVo.setAction(ActionEnum.update.type);
			etlProcessNodeVo.setEtlProcessNode(etlProcessNode);
			List<EtlNodeValue> etlNodeValueList=etlConfigdao.selectEtlNodeValueByNodeId(etlProcessNode.getId());
			List<EtlNodeValuePo> etlNodeValueVoList=new ArrayList<EtlNodeValuePo>();
			for(EtlNodeValue etlNodeValue:etlNodeValueList) {
				EtlNodeValuePo etlNodeValueVo=new EtlNodeValuePo();
				etlNodeValueVo.setEtlNodeValue(etlNodeValue);
				etlNodeValueVo.setAction(ActionEnum.update.type);
				etlNodeValueVoList.add(etlNodeValueVo);
			}
			etlProcessNodeVo.setEtlNodeValueVoList(etlNodeValueVoList);
			etlProcessNodeVoList.add(etlProcessNodeVo);
		}
		etlProcessVo.setEtlProcessNodeVoList(etlProcessNodeVoList);
		// EtlTimerJobVo
		List<EtlTimerJob> etlTimerJobList=etlConfigdao.selectEtlTimerJobByProcessId(etlProcessId);
		EtlTimerJobPo etlTimerJobVo=new EtlTimerJobPo();
		etlTimerJobVo.setAction(ActionEnum.update.type);
		etlTimerJobVo.setEtlTimerJob(etlTimerJobList.get(0));
		etlProcessVo.setEtlTimerJobVo(etlTimerJobVo);
		
		//EtlProcessGroupMap
		List<EtlProcessGroupMap> etlProcessGroupMapList=etlConfigdao.selectGroupMapByProcessId(etlProcessId);
		if(etlProcessGroupMapList!=null&&etlProcessGroupMapList.size()>0) {
			EtlProcessGroupMap etlProcessGroupMap=etlConfigdao.selectGroupMapByProcessId(etlProcessId).get(0);
			EtlProcessGroupMapPo etlProcessGroupMapPo=new EtlProcessGroupMapPo();
			etlProcessGroupMapPo.setAction(ActionEnum.update.type);
			etlProcessGroupMapPo.setEtlProcessGroupMap(etlProcessGroupMap);
			etlProcessVo.setEtlProcessGroupMapPo(etlProcessGroupMapPo);
			
			//EtlProcessGroup
			EtlProcessGroup secondaryProcessGroup=etlConfigdao.selectProcessGroupById(etlProcessGroupMap.getGroupId()).get(0);
			EtlProcessGroup primaryProcessGroup=etlConfigdao.selectProcessGroupById(secondaryProcessGroup.getPid()).get(0);
			EtlProcessGroups etlProcessGroups =new EtlProcessGroups();
			EtlProcessGroupPo secondaryProcessGroupPo= new EtlProcessGroupPo();
			secondaryProcessGroupPo.setAction(ActionEnum.update.type);
			secondaryProcessGroupPo.setEtlProcessGroup(secondaryProcessGroup);
			EtlProcessGroupPo primaryProcessGroupPo= new EtlProcessGroupPo();
			primaryProcessGroupPo.setAction(ActionEnum.update.type);
			primaryProcessGroupPo.setEtlProcessGroup(primaryProcessGroup);
			etlProcessGroups.setPrimaryEtlProcessGroup(primaryProcessGroupPo);
			etlProcessGroups.setSecondaryEtlProcessGroup(secondaryProcessGroupPo);
			
			etlProcessVo.setEtlProcessGroups(etlProcessGroups);

		}
		
		
		return etlProcessVo;
	}

	// 删除etl
	public ResultEntity delEtlProcessVo(EtlProcessPo etlProcessVo) throws Exception {
		ResultEntity resultEntity = new ResultEntity();
		resultEntity.setStatus(true);
		try {
			//EtlTimerJob
			etlConfigCommonService.deleteEtlTimerJob(etlProcessVo.getEtlTimerJobVo().getEtlTimerJob());
			//EtlProcessGroupMap
			if(etlProcessVo.getEtlProcessGroupMapPo()!=null) {
				etlConfigCommonService.deleteEtlProcessGroupMap(etlProcessVo.getEtlProcessGroupMapPo().getEtlProcessGroupMap());
			}
			//查找依赖
			Long timerId=etlProcessVo.getEtlTimerJobVo().getEtlTimerJob().getId();
			List<EtlTimerJob> etlTimerJobList=etlConfigdao.selectEtlTimerJobByDependId(timerId);
			for(EtlTimerJob etlTimerJob:etlTimerJobList) {
				String dependTimerJob=etlTimerJob.getDependTimerJob();
				if(dependTimerJob!=null) {
					String[] dependTimerJobArr=dependTimerJob.split(",");
					List<String> dependTimerJobListTmp=Arrays.asList(dependTimerJobArr);
					List<String> dependTimerJobList=new ArrayList<String>(dependTimerJobListTmp);
					dependTimerJobList.remove(timerId.toString());
					dependTimerJob=Joiner.on(",").join(dependTimerJobList);
					etlTimerJob.setDependTimerJob(dependTimerJob);
				}
				
				String exclusionTimerJob=etlTimerJob.getExclusionProcess();
				if(exclusionTimerJob!=null) {
					String[] exclusionTimerJobArr=exclusionTimerJob.split(",");
					List<String> exclusionTimerJobListTmp=Arrays.asList(exclusionTimerJobArr);
					List<String> exclusionTimerJobList=new ArrayList<String>(exclusionTimerJobListTmp);
					exclusionTimerJobList.remove(timerId.toString());
					exclusionTimerJob=Joiner.on(",").join(exclusionTimerJobList);
					etlTimerJob.setExclusionProcess(exclusionTimerJob);
				}
				
				etlConfigCommonService.updateEtlTimerJob(etlTimerJob);
			}
			for(EtlProcessNodePo etlProcessNodeVo:etlProcessVo.getEtlProcessNodeVoList()) {
				//EtlNodeValue
				for(EtlNodeValuePo etlNodeValueVo:etlProcessNodeVo.getEtlNodeValueVoList()) {
					etlConfigCommonService.deleteEtlNodeValue(etlNodeValueVo.getEtlNodeValue());
				}
				//EtlProcessNode
				etlConfigCommonService.deleteEtlProcessNode(etlProcessNodeVo.getEtlProcessNode());
			}
			//EtlProcess
			etlConfigCommonService.deleteEtlProcess(etlProcessVo.getEtlProcess());
		} catch (Exception e) {
			resultEntity.setStatus(false);
			throw e;
		}
		return resultEntity;
	}

	//解锁etl
	public ResultEntity unlockEtlProcess(Long etlProcessId) throws Exception {
		ResultEntity resultEntity = new ResultEntity();
		resultEntity.setStatus(true);
		try {
			EtlTimerJob etlTimerJob=etlConfigdao.selectEtlTimerJobByProcessId(etlProcessId).get(0);
			etlTimerJob.setRunLock(0);
			etlConfigCommonService.updateEtlTimerJob(etlTimerJob);
		}catch (Exception e) {
			resultEntity.setStatus(false);
			throw e;
		}
		return resultEntity;
	}

	//设置流程状态
	public ResultEntity setEtlProcessStatus(Long etlProcessId, String status) throws Exception {
		ResultEntity resultEntity = new ResultEntity();
		resultEntity.setStatus(true);
		try {
			Map paramMap = new HashMap();
			paramMap.put("id", etlProcessId);
			EtlProcess etlProcess = etlConfigdao.selectEtlProcess(paramMap).get(0);
			etlProcess.setIsActive(status);
			etlConfigCommonService.updateEtlProcess(etlProcess);
			
			EtlTimerJob etlTimerJob=etlConfigdao.selectEtlTimerJobByProcessId(etlProcessId).get(0);
			etlTimerJob.setIsActive(status);
			etlConfigCommonService.updateEtlTimerJob(etlTimerJob);
		}catch (Exception e) {
			resultEntity.setStatus(false);
			throw e;
		}
		return resultEntity;
	}
	//选择所有流程
	public EtlOptionVo queryAllOptions() throws Exception {
		EtlOptionVo result=new EtlOptionVo();
		
		//获取用户配置信息
		String username=/*BaseContextHandler.getUsername()*/null;
		List<EtlUserConfig> etlUserConfigList=etlConfigdao.selectUserConfigByUser(username);
		Map<String, EtlUserConfig> etlUserConfigMap = etlUserConfigList.stream().collect(Collectors.toMap(EtlUserConfig::getKey, a -> a,(k1,k2)->k1));
		logger.info("用户参数："+etlUserConfigMap.toString());
		
		//所有流程
		List<Map> allProcess=etlConfigdao.selectAllEtlByUserId(username);
		List<Map> process=new ArrayList<Map>();
		for(Map m:allProcess) {
			Map m_new=new HashMap();
			for(Object key:m.keySet()) {
				m_new.put(key.toString().toLowerCase(), m.get(key));
			}
			process.add(m_new);
		}
		result.setProcess(process);
		//所有分组
		List<Map> allGroup=etlConfigdao.selectAllEtlProcessGroup();
		List<Map> group=new ArrayList<Map>();
		for(Map m:allGroup) {
			Map m_new=new HashMap();
			for(Object key:m.keySet()) {
				m_new.put(key.toString().toLowerCase(), m.get(key));
			}
			group.add(m_new);
		}
		result.setGroup(group);
		//handler
		EtlOptionValue etlOptionValue=new EtlOptionValue();
		etlOptionValue.setOptionCode("1001");
		List<EtlOptionValue> etlOptionValueList=etlConfigdao.selectEtlOptionValue(etlOptionValue);
		List<Map> handler=new ArrayList<Map>();
		for(EtlOptionValue optionValue:etlOptionValueList) {
			Map m_new=new HashMap();
			m_new.put("label",optionValue.getOptionDesc());
			m_new.put("nodeType",Integer.parseInt(optionValue.getOptionValue()));
			handler.add(m_new);
		}
		result.setHandler(handler);
		
		//waitingList
		EtlOptionValue etlOptionValue2=new EtlOptionValue();
		etlOptionValue2.setOptionCode("1001");
		etlOptionValue2.setOptionStatus(1);
		List<EtlOptionValue> etlOptionValueList2=etlConfigdao.selectEtlOptionValue(etlOptionValue2);
		List<Map> waitingList=new ArrayList<Map>();
		for(EtlOptionValue optionValue:etlOptionValueList2) {
			Map m_new=new HashMap();
			m_new.put("label",optionValue.getOptionDesc());
			m_new.put("nodeType",Integer.parseInt(optionValue.getOptionValue()));
			waitingList.add(m_new);
		}
		result.setWaitingList(waitingList);
		
		//user
//		result.setUser(BaseContextHandler.getUsername());
		
		//resource
		result.setCpuLimit(etlUserConfigMap.get("cpuLimit").getValue());
		result.setMemLimit(etlUserConfigMap.get("memLimit").getValue());
		
		return result;
	}
	
	//选择二级分组
	public List<Map> querySecondaryGroup(String primaryCode) throws Exception {
		List<Map> result=new ArrayList<Map>();
		//二级分组
		List<Map> secondaryGroup=etlConfigdao.selectSecondaryEtlProcessGroup(primaryCode);
		for(Map m:secondaryGroup) {
			Map m_new=new HashMap();
			for(Object key:m.keySet()) {
				m_new.put(key.toString().toLowerCase(), m.get(key));
			}
			result.add(m_new);
		}

		return result;
	}

	//选择依赖流程
	/*
	 * public Map<String,List<Map>> queryEtlProcessDepend(Long etlProcessId) throws
	 * Exception { Map<String,List<Map>> result=new HashMap<String,List<Map>>();
	 * //已经依赖流程 List<Map>
	 * selectedProcessList=etlConfigdao.selectEtlDependByProcessId(etlProcessId);
	 * result.put("selectedProcess", selectedProcessList); //所有流程 List<Map>
	 * allProcess=etlConfigdao.selectAllEtlByUserId("caijd"); for(Map
	 * selectedProcess:selectedProcessList) { Long
	 * selectedTimerId=Long.valueOf(selectedProcess.get("ID").toString()); for(int
	 * i=allProcess.size()-1;i>=0;i--) { Map process=allProcess.get(i); Long
	 * timerId=Long.valueOf(process.get("ID").toString());
	 * if(selectedTimerId.longValue()==timerId.longValue()) { allProcess.remove(i);
	 * } } } result.put("unselectedProcess", allProcess); return result; }
	 */

	//选择互斥流程
	/*
	 * public Map queryEtlProcessExclusion(Long etlProcessId) throws Exception {
	 * Map<String,List<Map>> result=new HashMap<String,List<Map>>(); //已经互斥流程
	 * List<Map>
	 * selectedProcessList=etlConfigdao.selectEtlExclusionByProcessId(etlProcessId);
	 * result.put("selectedProcess", selectedProcessList); //所有流程 List<Map>
	 * allProcess=etlConfigdao.selectAllEtlByUserId("caijd"); for(Map
	 * selectedProcess:selectedProcessList) { Long
	 * selectedTimerId=Long.valueOf(selectedProcess.get("ID").toString()); for(int
	 * i=allProcess.size()-1;i>=0;i--) { Map process=allProcess.get(i); Long
	 * timerId=Long.valueOf(process.get("ID").toString());
	 * if(selectedTimerId.longValue()==timerId.longValue()) { allProcess.remove(i);
	 * } } } result.put("unselectedProcess", allProcess); return result; }
	 */

	//查询流程列表
	public PageInfo<EtlProcessListVo> queryEtlProcessVoList(Map map) throws Exception {
		Integer currentPage=(Integer)map.get("pageNum");
		Integer pageSize=(Integer)map.get("pageSize");
		if(currentPage==null)
			currentPage=1;
		if(pageSize==null||pageSize<=0)
			pageSize=20;
		PageHelper.startPage(currentPage,pageSize);
//		if(!BaseContextHandler.getUsername().equals("pm_admin")&&
//				!BaseContextHandler.getUsername().equals("tm_admin")) {
//			map.put("userId", BaseContextHandler.getUsername());
//		}else {
//			map.put("manager",BaseContextHandler.getUsername());
//		}
		List<EtlProcessListVo> res=etlConfigdao.selectEtlProcessListVo(map);
		PageInfo<EtlProcessListVo> pageInfo = new PageInfo(res);
		return pageInfo;
	}
	/*
	public ResultEntity upload(@RequestParam("file") MultipartFile file) {
		ResultEntity result=new ResultEntity();
		result.setStatus(true);
        if (file.isEmpty()) {
        	result.setStatus(false);
        	result.setException(new Exception("上传失败，请选择文件"));
            return result;
        }
        try {
        	ChannelSftp channelSftp=SftpUtil.connect(Constants.TENANT_SERVER_IP, Constants.TENANT_SERVER_PORT,
            		Constants.TENANT_SERVER_USERNAME, Constants.TENANT_SERVER_PASSWORD);
			if(SftpUtil.uploadFile(channelSftp, Constants.TENANT_SERVER_PATH, file.getInputStream(),file.getOriginalFilename())) {
				//上传成功后解压
				CommandUtil commandUtil = new CommandUtil(Constants.TENANT_SERVER_IP,
						Constants.TENANT_SERVER_USERNAME, Constants.TENANT_SERVER_PASSWORD);
				String cmd="cd "+Constants.TENANT_SERVER_PATH+";";
				cmd+="rm -rf tmp;mkdir tmp;";
				cmd+="mv "+file.getOriginalFilename().substring(0, file.getOriginalFilename().length()-4)+" tmp;";
				cmd+="unzip "+file.getOriginalFilename();
				logger.info("command:"+cmd);
				commandUtil.executeSuccess3(cmd, "");
			}else {
				result.setStatus(false);
			}
			channelSftp.disconnect();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        return result;
	}*/

	//查询流程执行列表
	public PageInfo<EtlProcessExecVo> queryEtlProcessExecList(Map map) throws Exception {
		Integer currentPage=(Integer)map.get("pageNum");
		Integer pageSize=(Integer)map.get("pageSize");
		if(currentPage==null)
			currentPage=1;
		if(pageSize==null||pageSize<=0)
			pageSize=20;
		PageHelper.startPage(currentPage,pageSize);
		List<EtlProcessExecVo> res=etlConfigdao.selectEtlProcessExecList(map);
		PageInfo<EtlProcessExecVo> pageInfo = new PageInfo(res);
		return pageInfo;
	}

	//查看调度详情
	public PageInfo<EtlProcessNodeExecPo> queryEtlProcessNodeExecList(Map map)
			throws Exception {
		Integer currentPage=(Integer)map.get("pageNum");
		Integer pageSize=(Integer)map.get("pageSize");
		if(currentPage==null)
			currentPage=1;
		if(pageSize==null||pageSize<=0)
			pageSize=20;
		PageHelper.startPage(currentPage,pageSize);
		List<EtlProcessNodeExecPo> res=etlConfigdao.selectEtlProcessNodeExecList(map);
		for(EtlProcessNodeExecPo etlProcessNodeExecPo:res) {
			String optLog=etlProcessNodeExecPo.getOptLog();
			if(optLog!=null) {
				String[] optLogArr=optLog.split("\\|");
				if(optLogArr[optLogArr.length-1].contains("applicationId")) {
					etlProcessNodeExecPo.setApplicationId(
							optLogArr[optLogArr.length-1].substring(14));
				}
			}
		}
		PageInfo<EtlProcessNodeExecPo> pageInfo = new PageInfo(res);
		return pageInfo;
	}
	//
	public List<Map> queryUserOption() throws Exception {
		List<Map> result=new ArrayList<Map>();
		List<Map> users=etlConfigdao.selectUsers();
		for(Map m:users) {
			Map m_new=new HashMap();
			for(Object key:m.keySet()) {
				m_new.put(key.toString().toLowerCase(), m.get(key));
			}
			result.add(m_new);
		}

		return result;
	}
	//查询用户参数配置
	public List<EtlUserConfig> queryEtlUserConfig() throws Exception {
		List<EtlUserConfig> result=new ArrayList<EtlUserConfig>();
//		result=etlConfigdao.selectUserConfigByUser(BaseContextHandler.getUsername());

		return result;
	}
	// 删除用户参数配置
	public ResultEntity delEtlUserConfig(Long id) throws Exception {
		ResultEntity resultEntity = new ResultEntity();
		resultEntity.setStatus(true);
		try {
			EtlUserConfig etlUserConfig=new EtlUserConfig();
			etlUserConfig.setId(id);
			etlConfigCommonService.deleteEtlUserConfig(etlUserConfig);
		} catch (Exception e) {
			resultEntity.setStatus(false);
			throw e;
		}
		return resultEntity;
	}
	// 保存用户参数配置
	public ResultEntity saveEtlUserConfig(EtlUserConfig etlUserConfig) throws Exception{
		ResultEntity resultEntity = new ResultEntity();
		resultEntity.setStatus(true);
		try {
			Long id=etlUserConfig.getId();
			if(etlUserConfig.getAction()== ActionEnum.add.type) {
				id=IdUtil.nextId();
				etlUserConfig.setId(id);
//				etlUserConfig.setUser(BaseContextHandler.getUsername());
				etlConfigCommonService.insertEtlUserConfig(etlUserConfig);
			}else if(etlUserConfig.getAction()== ActionEnum.update.type) {
				etlConfigCommonService.updateEtlUserConfig(etlUserConfig);
			}
			resultEntity.setData(id);
		}catch(Exception e) {
			resultEntity.setStatus(false);
			throw e;
		}
		return resultEntity;
	}
	/*
	 * 数字前面补0
	 * 
	 */
	public  String fillZeroBeforeNum(int length,int number){
		return String.format("%0"+length+"d", number);
	}
}
