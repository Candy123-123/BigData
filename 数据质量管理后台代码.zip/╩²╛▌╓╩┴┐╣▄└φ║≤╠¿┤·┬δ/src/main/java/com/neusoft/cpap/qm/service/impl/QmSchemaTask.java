package com.neusoft.cpap.qm.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.neusoft.cpap.qm.dao.QmBusinessDao;

@Component
public class QmSchemaTask {
	private static final Logger logger = LoggerFactory.getLogger(QmSchemaTask.class);
	@Autowired
	private QmBusinessDao qmBusinessDao;
	@Scheduled(cron = "*/15 * * * * ?")//每15s执行一次
	public void excute(){
		//定时查询任务状态
		//当任务完成时，计算评估分数更新任务状态
		
	}
	
	/**
	 * 计算评估分数
	 * @return
	 */
	private String calScore(Map param){
		//根据方案ID获取该方案配置的权重信息  字段级规则(key:字段+规则ID value:权重)  表级规则(key:rule_id value:权重)
		Map<String,Integer> fieldWeightMap = new HashMap();//字段级规则
		Map<String,Integer> multiFieldWeightMap = new HashMap();//表级规则
		List<Map> fieldList = qmBusinessDao.queryFieldWeightBySchemaId(param);
		List<Map> multiFieldList = qmBusinessDao.queryMultiFieldWeightBySchemaId(param);
		for(Map map : fieldList){
			String key = map.get("FIELD_CODE").toString()+map.get("RULE_LINK_ID").toString();
			int value = Integer.parseInt(map.get("WEIGHT").toString());
			fieldWeightMap.put(key, value);
		}
		for(Map map : multiFieldList){
			String key = map.get("RULE_LINK_ID").toString();
			int value = Integer.parseInt(map.get("WEIGHT").toString());
			multiFieldWeightMap.put(key, value);
		}
		//根据方案ID获取规则命中正确数和错误数  字段级规则正确命中数(key:字段+规则ID  valie:正确命中数) 表级规则正确命中数(key:rule_id value:正确命中数)
		Map<String,Integer> fieldCorrectMap = new HashMap();
		Map<String,Integer> multiFieldCorrectMap = new HashMap();
		//根据方案ID获取规则命中正确数和错误数  字段级规则错误命中数(key:字段+规则ID  valie:错误命中数) 表级规则错误命中数(key:rule_id value:错误命中数)
		Map<String,Integer> fieldErrorMap = new HashMap();
		Map<String,Integer> multiFieldErrorMap = new HashMap();
		List<Map> fieldHitList = qmBusinessDao.queryFieldHitCnt(param);
		List<Map> multiFieldHitList = qmBusinessDao.queryMultiFieldHitCnt(param);
		for(Map map : fieldHitList){//组装字段级规则命中数Map
			String key = map.get("FIELD").toString()+map.get("RULE_ID").toString();
			int value = Integer.parseInt(map.get("CNT").toString());
			if(map.get("RESULT").toString().equals("1")){
				//正确数
				fieldCorrectMap.put(key, value);
			}else{
				//错误数
				fieldErrorMap.put(key, value);
			}
		}
		for(Map map : multiFieldHitList){//组装表级规则命中数Map
			String key = map.get("RULE_ID").toString();
			int value = Integer.parseInt(map.get("CNT").toString());
			if(map.get("RESULT").toString().equals("1")){
				//正确数
				multiFieldCorrectMap.put(key, value);
			}else{
				//错误数
				multiFieldErrorMap.put(key, value);
			}
		}
		//字段级规则计算
		int filedCorrectScore = 0;//正确得分
		int fieldErrorScore = 0;//错误得分
		for(String key:fieldCorrectMap.keySet()){
			filedCorrectScore = filedCorrectScore+fieldWeightMap.get(key)*fieldCorrectMap.get(key);
		}
		for(String key:fieldErrorMap.keySet()){
			fieldErrorScore = fieldErrorScore+fieldWeightMap.get(key)*fieldErrorMap.get(key);
		}
		//表级规则计算
		int multiFiledCorrectScore = 0;//正确得分
		int multiFieldErrorScore = 0;//错误得分
		for(String key:multiFieldCorrectMap.keySet()){
			multiFiledCorrectScore = multiFiledCorrectScore+multiFieldWeightMap.get(key)*multiFieldCorrectMap.get(key);
		}
		for(String key:multiFieldErrorMap.keySet()){
			multiFieldErrorScore = multiFieldErrorScore+multiFieldWeightMap.get(key)*multiFieldErrorMap.get(key);
		}
		//得分=  正确分数/（正确分数+错误分数）
		float score = (filedCorrectScore+multiFiledCorrectScore)/(filedCorrectScore+multiFiledCorrectScore+fieldErrorScore+multiFieldErrorScore);
		
		return String.format("%.2f", score);
	}
}
