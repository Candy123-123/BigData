package com.neusoft.cpap.qm.etl.handler;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.neusoft.cpap.qm.etl.EtlRequestParam;

@Component
public  abstract class BaseHandler implements Handler{
	
	Handler childHandler = null;

	@Override
	public Handler setNextHandler(Handler handler) {
		this.childHandler = handler;
		return handler;
	}

	@Override
	public void execute(EtlRequestParam etlParam,Map<String,Object> paramMap) {
		this.doExecute(etlParam,paramMap);
		if(this.childHandler != null){
			this.childHandler.execute(etlParam,paramMap);
		}		
	}
	
	public abstract void doExecute(EtlRequestParam etlParam,Map<String,Object> paramMap);

}
