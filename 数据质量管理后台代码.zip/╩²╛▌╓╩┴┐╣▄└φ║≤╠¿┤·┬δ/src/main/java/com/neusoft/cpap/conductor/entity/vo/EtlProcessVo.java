package com.neusoft.cpap.conductor.entity.vo;

import java.util.Date;
import java.util.List;

import com.neusoft.cpap.conductor.entity.BaseVo;


public class EtlProcessVo extends BaseVo{
	private Long id;
	private Long timerId;
	private Long groupMapId;
	private String processCode;
	private String primaryGroup;
	private String secondaryGroup;
	private String sliceType;
	private String runSliceTime;
	private Integer delayMinute;
	private String dependTimerJob;
	private String exclusionProcess;
	private Integer runLock;
	private String isSingleImmed;
	private String processTemplate;
	private String isActive;
	private List<EtlProcessNodeVo> etlProcessNodeVoList;
	public String getProcessCode() {
		return processCode;
	}
	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}
	public String getSliceType() {
		return sliceType;
	}
	public void setSliceType(String sliceType) {
		this.sliceType = sliceType;
	}
	public String getRunSliceTime() {
		return runSliceTime;
	}
	public void setRunSliceTime(String runSliceTime) {
		this.runSliceTime = runSliceTime;
	}
	public Integer getDelayMinute() {
		return delayMinute;
	}
	public void setDelayMinute(Integer delayMinute) {
		this.delayMinute = delayMinute;
	}
	public String getDependTimerJob() {
		return dependTimerJob;
	}
	public void setDependTimerJob(String dependTimerJob) {
		this.dependTimerJob = dependTimerJob;
	}
	public String getExclusionProcess() {
		return exclusionProcess;
	}
	public void setExclusionProcess(String exclusionProcess) {
		this.exclusionProcess = exclusionProcess;
	}
	public Integer getRunLock() {
		return runLock;
	}
	public void setRunLock(Integer runLock) {
		this.runLock = runLock;
	}
	public String getIsSingleImmed() {
		return isSingleImmed;
	}
	public void setIsSingleImmed(String isSingleImmed) {
		this.isSingleImmed = isSingleImmed;
	}
	public List<EtlProcessNodeVo> getEtlProcessNodeVoList() {
		return etlProcessNodeVoList;
	}
	public void setEtlProcessNodeVoList(List<EtlProcessNodeVo> etlProcessNodeVoList) {
		this.etlProcessNodeVoList = etlProcessNodeVoList;
	}
	public String getProcessTemplate() {
		return processTemplate;
	}
	public void setProcessTemplate(String processTemplate) {
		this.processTemplate = processTemplate;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getTimerId() {
		return timerId;
	}
	public void setTimerId(Long timerId) {
		this.timerId = timerId;
	}
	public String getPrimaryGroup() {
		return primaryGroup;
	}
	public void setPrimaryGroup(String primaryGroup) {
		this.primaryGroup = primaryGroup;
	}
	public String getSecondaryGroup() {
		return secondaryGroup;
	}
	public void setSecondaryGroup(String secondaryGroup) {
		this.secondaryGroup = secondaryGroup;
	}
	public Long getGroupMapId() {
		return groupMapId;
	}
	public void setGroupMapId(Long groupMapId) {
		this.groupMapId = groupMapId;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "EtlProcessVo [id=" + id + ", timerId=" + timerId + ", groupMapId=" + groupMapId + ", processCode="
				+ processCode + ", primaryGroup=" + primaryGroup + ", secondaryGroup=" + secondaryGroup + ", sliceType="
				+ sliceType + ", runSliceTime=" + runSliceTime + ", delayMinute=" + delayMinute + ", dependTimerJob="
				+ dependTimerJob + ", exclusionProcess=" + exclusionProcess + ", runLock=" + runLock
				+ ", isSingleImmed=" + isSingleImmed + ", processTemplate=" + processTemplate + ", isActive=" + isActive
				+ ", etlProcessNodeVoList=" + etlProcessNodeVoList + "]";
	}
	
}
