package com.neusoft.cpap.conductor.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.nokia.sai.micro.framework.exception.AppException;

public class SftpUtil {
	private static final Logger logger = LoggerFactory.getLogger(SftpUtil.class);
	/*public static void main(String[] args) {
		//ChannelSftp sftp=connect("10.4.66.227",22,"root","neusoft321");
		//SftpUtil.uploadFile(sftp, "/home/hive/", new File("c:/ConfigMapper.xml"));
		//SftpUtil.uploadFile("10.4.66.227",22,"root","neusoft321", "/home/hive/", "caijingdan", "hellohellohellohellohellohellohellohellohello");
		ChannelSftp sftp=SftpUtil.connect("10.4.66.32", 22, "root", "kvmroot");
		String str=SftpUtil.downloadFile(sftp, "/bighead/app/ferry_new/hiveKey01/config/notebook/hiveKey01_BOOK.xml");
		SftpUtil.disconnect(sftp);
		System.out.println(str);
	}*/
	/**
	 * 获取sftp连接
	 * @param host SFTP服务器地址
	 * @param port SFTP服务器端口
	 * @param username SFTP登录账号
	 * @param password SFTP登录密码
	 * @return
	 */
	public static ChannelSftp connect(String host, int port, String username,
			String password) {
		ChannelSftp sftp = null;
		JSch jsch = new JSch();
        try {
			jsch.getSession(username, host, port);
			Session sshSession = jsch.getSession(username, host, port);
	        sshSession.setPassword(password);
	        Properties sshConfig = new Properties();
	        sshConfig.put("StrictHostKeyChecking", "no");
	        sshSession.setConfig(sshConfig);
	        sshSession.connect();
	        Channel channel = sshSession.openChannel("sftp");
	        channel.connect();
	        sftp = (ChannelSftp) channel;
		} catch (JSchException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		}
        
		return sftp;
	}
	
	public static boolean disconnect(ChannelSftp sftp){
		boolean result=true;
		try {
			sftp.getSession().disconnect();
			sftp.exit();
		} catch (JSchException e) {
			result=false;
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		}
		return result;
	}
	public static String downloadFile(ChannelSftp sftp,String remoteFilePath){
		InputStream in=null;
		StringBuilder sb=new StringBuilder();
		try {
			in=sftp.get(remoteFilePath);
			BufferedReader br=new BufferedReader(new InputStreamReader(sftp.get(remoteFilePath)));
			
			String line=null;
			while((line=br.readLine())!=null){
				sb.append(line+"\n");
			}
			
		} catch (SftpException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		} catch (IOException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		}
		return sb.toString();
	}
	/**
	 * 向SFTP服务器上传文件
	 * @param host SFTP服务器地址
	 * @param port SFTP服务器端口
	 * @param username SFTP登录账号
	 * @param password SFTP登录密码
	 * @param path SFTP服务器保存目录
	 * @param fileName 要上传的文件名字
	 * @param fileContent 要上传的文件内容
	 * @return
	 */
	public static boolean uploadFile(String host, int port, String username,
			String password, String path, String fileName,String fileContent) {
		boolean success = false;
		InputStream input = null;
		ChannelSftp sftp=connect(host,port,username,password);
		try {
			sftp.cd(path);
			input = new ByteArrayInputStream(fileContent.getBytes("utf-8"));
			sftp.put(input, fileName);
			input.close();
			sftp.disconnect();
			success = true;
		} catch (SftpException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		} catch (UnsupportedEncodingException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		} catch (IOException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		} finally {
			if (sftp!=null&&sftp.isConnected()) {
				sftp.disconnect();
			}
		}
		return success;
	}
	/**
	 * 向SFTP服务器上传文件
	 * @param sftp SFTP连接对象
	 * @param path SFTP服务器保存目录
	 * @param file 要上传的本地文件
	 * @return
	 */
	public static boolean uploadFile(ChannelSftp sftp, String path, File file) {
		boolean result = false;
		BufferedInputStream input = null;
		try {
			sftp.cd(path);
			input = new BufferedInputStream(new FileInputStream(file));
			sftp.put(input,file.getName());

			input.close();
			result = true;
		} catch (IOException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		} catch (SftpException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		}
		return result;
	}
	
	public static boolean uploadFile(ChannelSftp sftp, String path, InputStream is,String fileName) {
		boolean result = false;
		BufferedInputStream input = null;
		try {
			sftp.cd(path);
			input = new BufferedInputStream(is);
			sftp.put(input,fileName);

			input.close();
			result = true;
		} catch (IOException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		} catch (SftpException e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
		}
		return result;
	}
	/**
	 * 上传文件夹
	 * @param host SFTP服务器地址
	 * @param port SFTP服务器端口
	 * @param username SFTP登录账号
	 * @param password SFTP登录密码
	 * @param localDirectory 要上传的本地文件夹
	 * @param remoteDirectoryPath SFTP服务器保存目录以"/"结束
	 * @return
	 */
	public static boolean uploadDirectory(String host, int port,
			String username, String password, String localDirectory,
			String remoteDirectoryPath){
		boolean result=false;
		ChannelSftp sftp = connect(host, port, username, password);
		result= transfer(sftp, localDirectory, remoteDirectoryPath);
		disconnect(sftp);
		return result;
	}
	public static boolean transfer(ChannelSftp sftp, String localDir,
			String remotePath) {		
		try {
			//后加：若目标目录不存在，则创建目录
			 if (!isDirExist(sftp,remotePath)) {
				 createDir(sftp,remotePath);
	            }
			sftp.cd(remotePath);
			File src = new File(localDir);
			sftp.mkdir(src.getName());
			remotePath=remotePath+"/"+src.getName()+"/";			
			File[] allFile = src.listFiles();
			for (int i = 0; i < allFile.length; i++) {
				if (!allFile[i].isDirectory()) {
					File file = allFile[i];
					uploadFile(sftp, remotePath, file);
				}
			}
			for (int i = 0; i < allFile.length; i++) {
				if (allFile[i].isDirectory()) {
					// 递归
					transfer(sftp, allFile[i].getPath(),
							remotePath);
				}
			}
		}
		catch (Exception e) {
			//e.printStackTrace();			
			logger.error(e.getMessage(),e);
			return false;
		}
		return true;
	}
	public static boolean removeDirectory(ChannelSftp sftp,String remoteDirectoryPath){
		boolean result=false;
		try {
			sftp.rmdir(remoteDirectoryPath);
		} catch (SftpException e1) {
			e1.printStackTrace();
		}

		return result;
	}
	/**
	  * 判断目录是否存在
	  * zhangym
	  */
	 public static boolean isDirExist(ChannelSftp sftp,String directory) {
	  boolean isDirExistFlag = false;
	  try {
	   SftpATTRS sftpATTRS = sftp.lstat(directory);
	   isDirExistFlag = true;
	   return sftpATTRS.isDir();
	  } catch (Exception e) {
	   if (e.getMessage().toLowerCase().equals("no such file")) {
	    isDirExistFlag = false;
	   }
	  }
	  return isDirExistFlag;
	 }
	 /**
	  * 删除目录下的所有文件 包括目录
	  * zhangym
	  */
	 public static void deleteAllFiles(ChannelSftp sftp,String removeDir)throws AppException {
			try {
				sftp.cd(removeDir);
				List<String> fileNameList = listFiles(sftp,removeDir);				
				for(String fileName:fileNameList){
					if(isDirExist(sftp,removeDir+"/"+fileName)){
						deleteAllFiles(sftp,removeDir+"/"+fileName);
					}else{
						sftp.cd(removeDir);
						sftp.rm(fileName);
					}
				}
				sftp.rmdir(removeDir);	    				    
			} catch (Exception e){
				throw new AppException("SftpUtil deleteAllFiles fail ", e);
			}
		}
	 /**
	  * 创建目录
	  * zhangym
	  */
	 public static boolean createDir(ChannelSftp sftp,String createPath){
 		 String pathArry[] = createPath.split("/");
		 try {
			 String tmpPath = "";
		 if(pathArry!=null && pathArry.length>0){
			 for(String path : pathArry){
				 if(path!=null && !path.equals("")){
					 tmpPath = tmpPath+"/"+path;
					 if(isDirExist(sftp,tmpPath)){	
						 continue;				
					 }else{
						 sftp.mkdir(tmpPath);
					 } 
				 }				 
			 }
		 }
		 } catch (Exception e) {			
				//e.printStackTrace();
			 logger.error("createDir fail,path : "+createPath,e);
				 return false;
			}
		 return true;
	 }
	 /**
	  * 获取目录下所有文件
	  * zhangym
	  */
	 public static List<String> listFiles(ChannelSftp sftp,String directory) throws Exception {

		 Vector fileList;
		 List<String> fileNameList = new ArrayList<String>();

		 fileList = sftp.ls(directory);
		 Iterator it = fileList.iterator();

		 while(it.hasNext())
		 {
		             String fileName = ((LsEntry)it.next()).getFilename();
		             if(".".equals(fileName) || "..".equals(fileName)){
		             continue;
		             }
		             fileNameList.add(fileName);

		 }

		 return fileNameList;
		 }
}
