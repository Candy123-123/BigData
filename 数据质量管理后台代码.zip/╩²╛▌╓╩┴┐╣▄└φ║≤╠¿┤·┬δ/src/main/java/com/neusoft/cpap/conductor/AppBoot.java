package com.neusoft.cpap.conductor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import tk.mybatis.spring.annotation.MapperScan;

import com.neusoft.mid.msf.auth.client.EnableAceAuthClient;
import com.spring4all.swagger.EnableSwagger2Doc;
//@EnableDiscoveryClient
//@EnableCircuitBreaker
@SpringBootApplication
//@EnableFeignClients({"com.neusoft.mid.msf.auth.client.feign"})
@EnableScheduling
//@EnableAceAuthClient
@EnableTransactionManagement
@MapperScan("com.neusoft.cpap.conductor.dao")
@EnableSwagger2Doc
@ServletComponentScan("com.neusoft.cpap.conductor.config.filter")
//@EnableSSO
public class AppBoot 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(AppBoot.class,args);
    	//new SpringApplicationBuilder(UntrustBootstrap.class).run(args);
    }
}
  
 