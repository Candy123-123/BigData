package com.neusoft.cpap.conductor.model;






import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="ETL_TIMER_JOB")
public class EtlTimerJob {
	
	@Id
	private Long id;
	private Long processId;
	private String sliceType;
	private Integer delayMinute;
	private Date runSliceTime;
	private String dependTimerJob;
	private String exclusionProcess;
	private String isActive;
	private Integer runLock;
	private String isSingleTimer;
	private String isSingleImmed;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getProcessId() {
		return processId;
	}
	public void setProcessId(Long processId) {
		this.processId = processId;
	}
	public String getSliceType() {
		return sliceType;
	}
	public void setSliceType(String sliceType) {
		this.sliceType = sliceType;
	}
	public Integer getDelayMinute() {
		return delayMinute;
	}
	public void setDelayMinute(Integer delayMinute) {
		this.delayMinute = delayMinute;
	}		
	public Date getRunSliceTime() {
		return runSliceTime;
	}
	public void setRunSliceTime(Date runSliceTime) {
		this.runSliceTime = runSliceTime;
	}
	public String getDependTimerJob() {
		return dependTimerJob;
	}
	public void setDependTimerJob(String dependTimerJob) {
		this.dependTimerJob = dependTimerJob;
	}
	public String getExclusionProcess() {
		return exclusionProcess;
	}
	public void setExclusionProcess(String exclusionProcess) {
		this.exclusionProcess = exclusionProcess;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public Integer getRunLock() {
		return runLock;
	}
	public void setRunLock(Integer runLock) {
		this.runLock = runLock;
	}
	public String getIsSingleTimer() {
		return isSingleTimer;
	}
	public void setIsSingleTimer(String isSingleTimer) {
		this.isSingleTimer = isSingleTimer;
	}
	public String getIsSingleImmed() {
		return isSingleImmed;
	}
	public void setIsSingleImmed(String isSingleImmed) {
		this.isSingleImmed = isSingleImmed;
	}
	@Override
	public String toString() {
		return "EtlTimerJob [id=" + id + ", processId=" + processId
				+ ", sliceType=" + sliceType + ", delayMinute=" + delayMinute
				+ ", runSliceTime=" + runSliceTime + ", dependTimerJob="
				+ dependTimerJob + ", exclusionProcess=" + exclusionProcess
				+ ", isActive=" + isActive + ", runLock=" + runLock
				+ ", isSingleTimer=" + isSingleTimer + ", isSingleImmed="
				+ isSingleImmed + "]";
	}
}
