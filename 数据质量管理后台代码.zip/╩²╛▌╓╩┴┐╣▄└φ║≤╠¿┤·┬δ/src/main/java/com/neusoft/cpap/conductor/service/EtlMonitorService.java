package com.neusoft.cpap.conductor.service;

public interface EtlMonitorService {
	public String getSparkLogUrl(String applicationId) throws Exception;
	public String getYarnLog(String applicationId) throws Exception;
	public String getClientLog(Long oid) throws Exception;
}
