package com.neusoft.cpap.conductor.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.neusoft.cpap.conductor.service.EtlMonitorService;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;

@RestController
@RequestMapping("/monitor")
public class EtlMonitorController {
	private static final Logger logger = LoggerFactory.getLogger(EtlMonitorController.class);
	private static final String SERVICE_NAME = "etl.controller.EtlMonitorController";
	@Autowired
	private EtlMonitorService etlMonitorService;
	
	@RequestMapping("/queryWorkList")
	//@IgnoreUserToken
	public String queryWorkList() {
		//logger.info("RestService was called [" + SERVICE_NAME+ ".queryWorkList],param = "+param);
		Map result=new HashMap();
		result.put("userId", "xxxxxxx");
		result.put("userType", "1");
		result.put("workType", "1|2");
		result.put("status", "6|7|9");
		result.put("limited", "1");
		
		return JSON.toJSONString(result);
	}
	//获取spark日志url
	@RequestMapping(value = "/getSparkLogUrl")
	public ResultEntity<String> getSparkLogUrl(@RequestBody Map map)throws Exception{
		logger.info("RestService was called [" + SERVICE_NAME+ ".getSparkLogUrl],map = "+map);
		String applicationId=(String)map.get("applicationId");
		return new ResultEntity<String>(etlMonitorService.getSparkLogUrl(applicationId)); 
	}
	//查询yarn日志
	@RequestMapping(value = "/getYarnLog")
	public ResultEntity getYarnLog(@RequestBody Map map)throws Exception{
		logger.info("RestService was called [" + SERVICE_NAME+ ".getYarnLog],map = "+map);	
		String applicationId=(String)map.get("applicationId");
		return new ResultEntity(etlMonitorService.getYarnLog(applicationId)); 
	}
	//查询客户端日志
	@RequestMapping(value = "/getClientLog")
	public ResultEntity getClientLog(@RequestBody Map map)throws Exception{
		logger.info("RestService was called [" + SERVICE_NAME+ ".getClientLog],map = "+map);
		String oid=(String)map.get("oid");
		return new ResultEntity(etlMonitorService.getClientLog(Long.valueOf(oid))); 
	}
}
