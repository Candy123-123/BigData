package com.neusoft.cpap.conductor.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageInfo;
import com.neusoft.cpap.conductor.entity.EtlProcessNodeExecPo;
import com.neusoft.cpap.conductor.entity.EtlProcessPo;
import com.neusoft.cpap.conductor.entity.vo.EtlOptionVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessExecVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessListVo;
import com.neusoft.cpap.conductor.model.EtlUserConfig;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;

public interface EtlConfigService {
	public PageInfo<EtlProcessListVo> queryEtlProcessVoList(Map map) throws Exception;

	public PageInfo<EtlProcessExecVo> queryEtlProcessExecList(Map map) throws Exception;
	
	public PageInfo<EtlProcessNodeExecPo> queryEtlProcessNodeExecList(Map map) throws Exception;

	public ResultEntity saveEtlProcessPo(EtlProcessPo etlProcessPo) throws Exception;

	public EtlProcessPo queryEtlProcessVo(Long etlProcessId) throws Exception;

	public ResultEntity delEtlProcessVo(EtlProcessPo etlProcessVo) throws Exception;

	public ResultEntity unlockEtlProcess(Long etlProcessId) throws Exception;

	public ResultEntity setEtlProcessStatus(Long etlProcessId, String status) throws Exception;

	public EtlOptionVo queryAllOptions() throws Exception;
	
	public List<Map> querySecondaryGroup(String primaryCode) throws Exception;
	
	//public Map queryEtlProcessDepend(Long etlProcessId) throws Exception;

	//public Map queryEtlProcessExclusion(Long etlProcessId) throws Exception;

	//public ResultEntity upload(MultipartFile file);
	
	public List<Map> queryUserOption() throws Exception;
	
	public List<EtlUserConfig> queryEtlUserConfig() throws Exception;
	public ResultEntity delEtlUserConfig(Long id) throws Exception;
	public ResultEntity saveEtlUserConfig(EtlUserConfig etlUserConfig) throws Exception;
}
