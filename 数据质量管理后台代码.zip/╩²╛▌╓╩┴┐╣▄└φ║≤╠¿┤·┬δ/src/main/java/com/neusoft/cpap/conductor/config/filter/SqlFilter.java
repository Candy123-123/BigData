package com.neusoft.cpap.conductor.config.filter;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SqlFilter implements Filter{

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		
	}
			public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)throws ServletException, IOException {
				HttpServletRequest request = (HttpServletRequest)servletRequest;
				HttpServletResponse response = (HttpServletResponse)servletResponse;
				String currentURL = request.getRequestURI();
				String ctxPath = request.getContextPath();
				//除掉项目名称时访问页面当前路径
				String targetURL = currentURL.substring(ctxPath.length());
				String sql = "";
//				if(targetURL.equals("")
//				   ){
					 //获得所有请求参数名
			        Enumeration params = request.getParameterNames();
			        while (params.hasMoreElements()) {
			            //得到参数名
			            String name = params.nextElement().toString();
			            //得到参数对应值
			            String[] value = request.getParameterValues(name);
			            for (int i = 0; i < value.length; i++) {
			                sql = sql + value[i];
			            }
//			        }
				}
				 //有sql关键字，跳转到error.html
		        if (sqlValidate(sql)) {
		            throw new IOException("请求参数中含有非法字符!");
		            //String ip = req.getRemoteAddr();
		        } else {
		        	filterChain.doFilter(request, response);
		        }
			}
			 //效验
		    public static boolean sqlValidate(String str) {
		        str = str.toLowerCase();//统一转为小写
		        String badStr = " and|and |exec | exec|execute | execute|insert | insert|select |delete | update|update |count | count|drop |chr | chr|mid | mid|master | master|truncate |" +
		                " char| char|declare | declare|sitename | sitename|net user|xp_cmdshell | xp_cmdshell|or | or| like|like |" +
		                "grant | grant|use | use|union | union|order | order|by | by|--| having|having | trim|trim ";//过滤掉的sql关键字，可以手动添加
		        String[] badStrs = badStr.split("\\|");
		        for (int i = 0; i < badStrs.length; i++) {
		            //循环检测，判断在请求参数当中是否包含SQL关键字
		            if (str.indexOf(badStrs[i]) >= 0) {
		            	System.out.println(badStrs[i]);
		            	System.out.println(str);
		                return true;
		            }
		        }
		        return false;
		    }

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

}
