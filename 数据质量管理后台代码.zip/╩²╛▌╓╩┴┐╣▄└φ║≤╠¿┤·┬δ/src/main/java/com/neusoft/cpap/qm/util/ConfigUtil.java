package com.neusoft.cpap.qm.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.neusoft.cpap.qm.etl.Node;
//import com.neusoft.mid.commons.exception.Xml2ObjectException;
import com.neusoft.cpap.qm.etl.Process;
public class ConfigUtil {
	
	public static Map<String, Object> workMap = null;
	private static final Logger logger = LoggerFactory.getLogger(ConfigUtil.class);
	
	public static Map<String, Object> loadProperty(String prop) throws IOException {
		Properties properties = new Properties();
		InputStream stream;
		stream = new FileInputStream(prop);
		properties.load(stream);
		Map conf = new HashMap<String, Object>();
		conf.putAll(properties);
		return conf;
	}
	
	public static List<Process> loadProcessXML(String prop) throws IOException {
		File file = new File(prop);
		Map<String, Class<?>> aliasMap = new HashMap<String, Class<?>>();
		aliasMap.put("etlProcess", List.class);
		aliasMap.put("process", Process.class);		
		aliasMap.put("processNode", List.class);
		aliasMap.put("node", Node.class);
		List<Process> processList = null;
		try {
			processList = XmlUtil.<List<Process>> xmlToObject(file, aliasMap);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return processList;
	}
	
	/*
	public static void getWorkProperty(){
		String path = System.getProperty("user.dir")
				+ "/config/work-order.properties";
		try {
			workMap = loadProperty(path);
		} catch (IOException e) {
			logger.error("load work-order error",e);
		}
	}*/
}
