package com.neusoft.cpap.conductor.dao.mapper;

import com.neusoft.cpap.conductor.model.EtlProcessGroup;

import tk.mybatis.mapper.common.BaseMapper;

public interface EtlProcessGroupMapper extends BaseMapper<EtlProcessGroup>{

}
