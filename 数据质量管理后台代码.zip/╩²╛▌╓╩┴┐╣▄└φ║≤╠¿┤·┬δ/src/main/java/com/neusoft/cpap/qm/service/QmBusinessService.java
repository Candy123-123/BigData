package com.neusoft.cpap.qm.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.neusoft.cpap.qm.vo.BaseTaskResult;
import com.neusoft.cpap.qm.vo.FieldRuleVo;
import com.neusoft.cpap.qm.vo.GroupVo;
import com.neusoft.cpap.qm.vo.SchemaBasicVo;
import com.neusoft.cpap.qm.vo.SchemaTaskVo;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;

public interface QmBusinessService {
	public ResultEntity queryGroupList(Map map);
	public ResultEntity addGroupList(GroupVo groupVo);
	public ResultEntity delGroupList(String id);
	public PageInfo<SchemaBasicVo> querySchemaListList(Map map);
	public ResultEntity addSchemaListList(SchemaBasicVo schemaBasicVo);
	public ResultEntity delSchemaListList(String id);
	public ResultEntity modSchemaListList(SchemaBasicVo schemaBasicVo);
	public PageInfo<SchemaTaskVo> querySchemaTaskList(Map map);
	public PageInfo<SchemaTaskVo> queryAllTaskBySchemaId(Map map);
	public ResultEntity querySchemaTaskReportSummary(Map map);
	public ResultEntity querySchemaTaskReportDimention(Map map);
	public ResultEntity queryHasDataSource(Map map);
	public ResultEntity queryQualitySummary(Map map);
	public ResultEntity queryScoreTrend(Map map);
	public ResultEntity queryScoreRank(Map map);
	public JSONObject setSchemaCycle(Map map);
	public ResultEntity querySchemaComboxByType(Map map);
	public ResultEntity queryFieldStat(Map map);
	public ResultEntity queryFieldAndRuleStat(Map map);
	public ResultEntity exportReport(Map map,HttpServletRequest request,HttpServletResponse res);
	public SchemaBasicVo querySchemaDetail(Map map);
	ResultEntity queryScheme(Map map);
	PageInfo<BaseTaskResult> queryLinkRatio(Map<String, Object> map);
	ResultEntity queryStatis(Map map);
	public ResultEntity startOrStopSchema(Map map);
	ResultEntity queryTimeDimension(Map map);
	ResultEntity queryDimension(Map map);
	ResultEntity queryHourFieldStat(Map map);
	ResultEntity queryHourFieldAndRuleStat(Map map);
	ResultEntity queryNoFieldStat(Map map);
	ResultEntity queryNoFieldAndRuleStat(Map map);
	public JSONArray changeStandard2BasicRule(String ori_basic_info, String field_name);
}
