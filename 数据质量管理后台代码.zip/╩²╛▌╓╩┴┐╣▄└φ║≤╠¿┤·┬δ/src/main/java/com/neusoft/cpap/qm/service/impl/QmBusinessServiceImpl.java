package com.neusoft.cpap.qm.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.cpap.conductor.util.CommandUtil;
import com.neusoft.cpap.qm.common.GlobalConstants;
import com.neusoft.cpap.qm.dao.QmBusinessDao;
import com.neusoft.cpap.qm.etl.EtlService;
import com.neusoft.cpap.qm.etl.ReturnEntity;
import com.neusoft.cpap.qm.service.QmBusinessService;
import com.neusoft.cpap.qm.util.ExportExcel;
import com.neusoft.cpap.qm.vo.BaseTaskResult;
import com.neusoft.cpap.qm.vo.ComboxVo;
import com.neusoft.cpap.qm.vo.ExportDimFieldStatVo;
import com.neusoft.cpap.qm.vo.ExportFieldStatVo;
import com.neusoft.cpap.qm.vo.FieldRuleVo;
import com.neusoft.cpap.qm.vo.GroupVo;
import com.neusoft.cpap.qm.vo.SchemaBasicVo;
import com.neusoft.cpap.qm.vo.SchemaTaskVo;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;

@Service
@Transactional
public class QmBusinessServiceImpl implements QmBusinessService {

	@Autowired
	private QmBusinessDao qmBusinessDao;
	@Autowired
	private EtlService etlService;

	@Override
	public ResultEntity queryGroupList(Map map) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		List<Map> allList = qmBusinessDao.queryGroupList(map);
		List<Map> nodeList = new ArrayList();
		// 查询一级节点
		if (null != allList && allList.size() > 0) {
			for (Map temp : allList) {
				if (temp.get("LEVEL").toString().equals("1")) {
					nodeList.add(temp);
				}
			}
		}
		// 根据一级节点查找子节点
		JSONArray resultArray = new JSONArray();
		resultArray = getChildInfo(nodeList, allList);
		result.setData(resultArray);
		return result;
	}

	private JSONArray getChildInfo(List<Map> nodeList, List<Map> allList) {
		JSONArray array = new JSONArray();
		for (Map temp : nodeList) {
			// 判断该节点是否有子节点
			List childList = getChildNode(temp, allList);
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("id", temp.get("GROUP_ID"));
			jsonObject.put("label", temp.get("GROUP_NAME"));
			if (null != childList && childList.size() > 0) {
				jsonObject.put("children", getChildInfo(childList, allList));
			}
			array.add(jsonObject);
		}
		return array;
	}

	private List<Map> getChildNode(Map map, List<Map> allList) {
		List<Map> childNodes = new ArrayList();
		for (Map temp : allList) {
			if (temp.get("PARENT_GROUP_ID").toString().equals(map.get("GROUP_ID").toString())) {
				childNodes.add(temp);
			}
		}
		return childNodes;
	}

	@Override
	public ResultEntity addGroupList(GroupVo groupVo) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String group_id = sdf.format(new Date()) + CommandUtil.fillZeroBeforeNum(4);
		groupVo.setGroup_id(group_id);
		qmBusinessDao.addGroupList(groupVo);
		return result;
	}

	@Override
	public ResultEntity delGroupList(String id) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();

		// 分组下有方案配置不允许删除
		int cnt = qmBusinessDao.chechHasSchemaByGroup(id);
		if (cnt > 0) {
			result.setStatus(false);
			result.setData("分组下存在方案，请先删除方案");
			;
		} else {
			result.setStatus(true);
			qmBusinessDao.delGroupList(id);
		}
		return result;
	}

	@Override
	public PageInfo<SchemaBasicVo> querySchemaListList(Map map) {
		// TODO Auto-generated method stub
		List<JSONObject> resultList = new ArrayList<JSONObject>();
		Integer currentPage=(Integer)map.get("current") == null? 1 :(Integer)map.get("current");
		Integer pageSize=(Integer)map.get("size") == null? 20:(Integer)map.get("size");
		PageHelper.startPage(currentPage,pageSize);
		List<SchemaBasicVo> baseList=qmBusinessDao.querySchemaListList(map);
//		for(SchemaBasicVo vo : baseList){
//			//根据方案id查询字段级规则
//			List<FieldRuleVo> basic_rules = qmBusinessDao.querySchemaFieldRule(vo.getId());
//			vo.setValidationRules(basic_rules);
//			//根据方案id查询表级级规则
//			List<FieldRuleVo> multi_rules = qmBusinessDao.querySchemaMultiFieldRule(vo.getId());
//			vo.setTableRules(multi_rules);
//		}

		PageInfo<SchemaBasicVo> pageInfo = new PageInfo(baseList);
		return pageInfo;
	}

	@Override
	public SchemaBasicVo querySchemaDetail(Map map) {
		List<SchemaBasicVo> baseList = qmBusinessDao.querySchemaListList(map);
		SchemaBasicVo vo = baseList.get(0);
		vo.setFilterCondition(JSONArray.parseArray(vo.getSearch_condition()));
		// 根据方案id查询字段级规则
		List<FieldRuleVo> basic_rules = qmBusinessDao.querySchemaFieldRule(vo.getId());
		for (FieldRuleVo temp : basic_rules) {
			temp.setBoundRule(JSONArray.parseArray(new String(temp.getBoundRules())));
		}
		vo.setValidationRules(basic_rules);
		// 根据方案id查询表级级规则
		List<FieldRuleVo> multi_rules = qmBusinessDao.querySchemaMultiFieldRule(vo.getId());
		for (FieldRuleVo temp : multi_rules) {
			temp.setFields(temp.getField().split(","));
		}
		vo.setTableRules(multi_rules);
		return vo;
	}

	@Override
	public ResultEntity addSchemaListList(SchemaBasicVo schemaBasicVo) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		// QM_数据源id_时间戳_4位序列
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String schema_id = "QM_" + schemaBasicVo.getDataSource() + sdf.format(new Date())
				+ CommandUtil.fillZeroBeforeNum(4);
		schemaBasicVo.setId(schema_id);
		// 添加基础信息
		schemaBasicVo.setSearch_condition(schemaBasicVo.getFilterCondition().toString());
		schemaBasicVo.setStat_dimention(schemaBasicVo.getStatistical().toString());
		qmBusinessDao.addSchemaListList(schemaBasicVo);
		// 添加字段级规则
		List<FieldRuleVo> fieldRuleList = schemaBasicVo.getValidationRules();
		for (FieldRuleVo vo : fieldRuleList) {
			vo.setSchema_id(schema_id);
			vo.setBoundRules(vo.getBoundRule().toString().getBytes());
			if (vo.getRuleType() == 1) {// 规则类型1 标准规则 2添加的规则
				vo.setId("s" + vo.getId());// 标准规则需要加前缀s，后台要求
			} else {
				vo.setId("mis" + sdf.format(new Date()) + CommandUtil.fillZeroBeforeNum(4));
			}
			qmBusinessDao.addSchemaFieldRule(vo);
		}

		// 添加表级规则
		List<FieldRuleVo> tableRuleList = schemaBasicVo.getTableRules();
		if (null != tableRuleList && tableRuleList.size() > 0) {
			for (FieldRuleVo vo : tableRuleList) {
				vo.setSchema_id(schema_id);
				vo.setField(String.join(",", vo.getFields()));
				vo.setFieldName(vo.getFieldsName());
				qmBusinessDao.addSchemaMultiFieldRule(vo);
			}
		}
		return result;
	}

	@Override
	public ResultEntity delSchemaListList(String id) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		// 删除方案基础配置
		qmBusinessDao.delSchemaListList(id);
		// 删除方案对应的字段级关联配置
		qmBusinessDao.delFieldRuleLinkByShcemaId(id);
		// 删除方案对应的表级规则关联配置
		qmBusinessDao.delMultiFieldLinkByShcemaId(id);

		return result;
	}

	@Override
	public ResultEntity modSchemaListList(SchemaBasicVo schemaBasicVo) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		// 更新基础信息
		schemaBasicVo.setSearch_condition(schemaBasicVo.getFilterCondition().toString());
		schemaBasicVo.setStat_dimention(schemaBasicVo.getStatistical().toString());
		qmBusinessDao.modSchemaListList(schemaBasicVo);
		// 删除方案对应的字段级关联配置
		qmBusinessDao.delFieldRuleLinkByShcemaId(schemaBasicVo.getId());
		// 删除方案对应的表级规则关联配置
		qmBusinessDao.delMultiFieldLinkByShcemaId(schemaBasicVo.getId());
		// 添加字段级规则
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		if (null != schemaBasicVo.getValidationRules() && schemaBasicVo.getValidationRules().size() > 0) {
			for (FieldRuleVo vo : schemaBasicVo.getValidationRules()) {
				vo.setSchema_id(schemaBasicVo.getId());
				vo.setBoundRules(vo.getBoundRule().toString().getBytes());
				if (!vo.getId().startsWith("s") && !vo.getId().startsWith("mis")) {// 规则类型1 标准规则 2添加的规则
					vo.setId("mis" + sdf.format(new Date()) + CommandUtil.fillZeroBeforeNum(4));
				}
				qmBusinessDao.addSchemaFieldRule(vo);
			}
		}
		// 添加表级规则
		if (null != schemaBasicVo.getTableRules() && schemaBasicVo.getTableRules().size() > 0) {
			for (FieldRuleVo vo : schemaBasicVo.getTableRules()) {
				vo.setSchema_id(schemaBasicVo.getId());
				vo.setField("[" + String.join(",", vo.getFields()) + "]");
				vo.setFieldName(vo.getFieldsName());
				qmBusinessDao.addSchemaMultiFieldRule(vo);
			}
		}
		return result;
	}

	@Override
	public PageInfo<SchemaTaskVo> querySchemaTaskList(Map map) {
		// TODO Auto-generated method stub
		Integer currentPage = (Integer) map.get("pageNum") == null ? 1 : (Integer) map.get("pageNum");
		Integer pageSize = (Integer) map.get("pageSize") == null ? 20 : (Integer) map.get("pageSize");
		PageHelper.startPage(currentPage, pageSize);
		List<SchemaTaskVo> res = qmBusinessDao.querySchemaTaskList(map);
		PageInfo<SchemaTaskVo> pageInfo = new PageInfo(res);
		return pageInfo;
	}

	@Override
	public PageInfo<SchemaTaskVo> queryAllTaskBySchemaId(Map map) {
		Integer currentPage = (Integer) map.get("pageNum") == null ? 1 : (Integer) map.get("pageNum");
		Integer pageSize = (Integer) map.get("pageSize") == null ? 20 : (Integer) map.get("pageSize");
		PageHelper.startPage(currentPage, pageSize);
		List<SchemaTaskVo> res = qmBusinessDao.queryAllTaskBySchemaId(map);
		PageInfo<SchemaTaskVo> pageInfo = new PageInfo(res);
		return pageInfo;
	}

	@Override
	public ResultEntity querySchemaTaskReportSummary(Map map) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		JSONObject dataJson = new JSONObject();
		// 数据汇总
		Map data = new HashMap();
		data = qmBusinessDao.querySchemaTaskReportSummary(map);
		dataJson.put("schema_name", data.get("SCHEMA_NAME"));
		dataJson.put("source_name", data.get("SOURCE_NAME"));// 数据源名称
		dataJson.put("rule_msg_cnt", data.get("RULE_MSG_CNT"));// 规则错误总量
		dataJson.put("msg_total_cnt", data.get("MSG_TOTAL_CNT"));// 核查数据总量
		dataJson.put("error_msg_cnt", data.get("ERROR_MSG_CNT"));// 问题数据总量
		dataJson.put("correct_per", data.get("CORRECT_PER") + "%");// 正确率
		// 各个规则及对应的错误数
//		List<Map> list = qmBusinessDao.queryRulesErrorMsgCnt(map);
//		String[] rule_names = new String[list.size()];
//		Integer[] rule_msg_cnts = new Integer[list.size()];
//		for (int m = 0; m < list.size(); m++) {
//			Map temp = list.get(m);
//			rule_names[m] = temp.get("RULE_NAME").toString();// 规则名称
//			rule_msg_cnts[m] = Integer.parseInt(temp.get("RULE_MSG_CNT").toString());// 规则命中数
//		}
//		dataJson.put("rule_name", rule_names);
//		dataJson.put("rule_msg_cnt", rule_msg_cnts);
		result.setData(dataJson);
		return result;
	}

	@Override
	public ResultEntity querySchemaTaskReportDimention(Map map) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		JSONObject dataJson = new JSONObject();
		// 根据维度分别进行统计
		Map infoMap = qmBusinessDao.querySchemaTaskDimention(map);
		String source_id = infoMap.get("SOURCE_ID").toString();

		if (null != infoMap.get("STAT_DIMENTION")) {
			String dimention = infoMap.get("STAT_DIMENTION").toString();
			String[] dimentions = dimention.split(",");
			Map[] enumMap = new HashMap[dimentions.length];
			enumMap = makeEnumMap(source_id, dimentions);
			// 获取统计维度数据
			List<Map> tempList = qmBusinessDao.statSchemaTaskErrorMsgByDimention(map);
			dataJson.put("length", tempList.size());
			String[] stat_dimention = new String[tempList.size()];
			Integer[] msg_total_cnt = new Integer[tempList.size()];
			Integer[] correct_msg_cnt = new Integer[tempList.size()];
			JSONArray array = new JSONArray();
			// 转义
			for (int m = 0; m < tempList.size(); m++) {
				Map temp = tempList.get(m);
				JSONObject obj = new JSONObject();
				String[] stats = temp.get("STAT_DIMENTION").toString().split(",");
				StringBuffer statName = new StringBuffer();
				for (int i = 0; i < stats.length; i++) {
					if (i != stats.length - 1) {
						statName.append(enumMap[i].get(stats[i])).append(",");
					} else {
						statName.append(enumMap[i].get(stats[i]));
					}
				}
				stat_dimention[m] = statName.toString();
				msg_total_cnt[m] = Integer.parseInt(temp.get("MSG_TOTAL_CNT").toString());
				correct_msg_cnt[m] = Integer.parseInt(temp.get("CORRECT_MSG_CNT").toString());
			}
			dataJson.put("stat_dimention", stat_dimention);// 统计维度
			dataJson.put("msg_total_cnt", msg_total_cnt);// 消息总量
			dataJson.put("correct_msg_cnt", correct_msg_cnt);// 正确量
		} else {
			// 没有维度统计
			dataJson.put("length", 0);
			dataJson.put("stat_dimention", "");// 统计维度
			dataJson.put("msg_total_cnt", 0);// 消息总量
			dataJson.put("correct_msg_cnt", 0);// 正确量
		}
		result.setData(dataJson);
		return result;
	}

	@Override
	public ResultEntity queryHasDataSource(Map map) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		List list = qmBusinessDao.queryHasDataSource(map);
		result.setData(list);
		return result;
	}

	@Override
	public ResultEntity queryQualitySummary(Map map) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		// 查询选中的数据源对应的方案
		List schemaList = qmBusinessDao.querySchemaIdByDataSource(map);
		// 查询方案对应的数据汇总
		map.put("schemaList", schemaList);
		Map resultMap = qmBusinessDao.queryQualitySummary(map);
		// 查询方案对应规则总数
		int rule_cnt = qmBusinessDao.queryTotalRulesBySchemaId(map);
		resultMap.put("rule_cnt", rule_cnt);
		int sum_total_msg_cnt = Integer.parseInt(resultMap.get("sum_error_msg_cnt").toString())
				+ Integer.parseInt(resultMap.get("sum_correct_msg_cnt").toString());
		resultMap.put("sum_total_msg_cnt", sum_total_msg_cnt);
		result.setData(resultMap);
		return result;
	}

	@Override
	public ResultEntity queryScoreTrend(Map map) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		List makeDataList = new ArrayList();
		Map trendMap = new HashMap();
		result.setStatus(true);
		try {
			String[] dates = makeDates(map);
			// 查询选中的数据源对应的方案
			List schemaList = qmBusinessDao.querySchemaIdByDataSource(map);
			for (int i = 0; i < schemaList.size(); i++) {
				Map temp = (Map) schemaList.get(i);
				List scoreList = qmBusinessDao.queryScoreTrendBySchemaId(temp);
				Map resultMap = new HashMap();
				for (int m = 0; m < scoreList.size(); m++) {
					Map scoreMap = (Map) scoreList.get(m);
					resultMap.put(scoreMap.get("day_time"), scoreMap.get("avg_score"));
				}
				int[] datas = new int[dates.length];
				for (int n = 0; n < dates.length; n++) {
					String day = dates[n];
					if (null != resultMap.get(day)) {
						datas[n] = Integer.parseInt(resultMap.get(day).toString());
					} else {
						datas[n] = 0;
					}
				}
				Map midMap = new HashMap();
				midMap.put("name", temp.get("NAME"));// 方案名称
				midMap.put("data", datas);// 按天对应的统计数据
				makeDataList.add(midMap);
			}
			trendMap.put("xAxis", dates);
			trendMap.put("series", makeDataList);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		result.setData(trendMap);
		return result;
	}

	private String[] makeDates(Map map) throws ParseException {
		SimpleDateFormat day_sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat out_sdf = new SimpleDateFormat("yyyy-MM-dd");
		String start_time = map.get("start_time").toString();
		String end_time = map.get("end_time").toString();
		Calendar start_date = Calendar.getInstance();
		Calendar end_date = Calendar.getInstance();
		start_date.setTime(day_sdf.parse(start_time));
		end_date.setTime(day_sdf.parse(end_time));
		StringBuffer dayBuff = new StringBuffer();
		dayBuff.append(out_sdf.format(start_date.getTime())).append(",");
		while (!end_date.equals(start_date)) {
			start_date.add(Calendar.DAY_OF_MONTH, 1);
			dayBuff.append(out_sdf.format(start_date.getTime())).append(",");
		}
		String[] days = dayBuff.substring(0, dayBuff.length() - 1).toString().split(",");
		return days;
	}

	@Override
	public ResultEntity queryScoreRank(Map map) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		List list = new ArrayList();
		// 查询选中的数据源对应的方案
		List schemaList = qmBusinessDao.querySchemaIdByDataSource(map);
		Map sourceMap = new HashMap();
		for (int m = 0; m < schemaList.size(); m++) {
			Map temp = (Map) schemaList.get(m);
			sourceMap.put(temp.get("SCHEMA_ID"), temp.get("NAME"));
		}
		map.put("schemaList", schemaList);
		List rankList = qmBusinessDao.queryScoreRank(map);
		for (int i = 0; i < rankList.size(); i++) {
			Map temp = (Map) rankList.get(i);
			temp.put("name", sourceMap.get(temp.get("SCHEMA_ID")));
			float currnet_score = Float.parseFloat(temp.get("SCORE").toString());
			float last_score = Float.parseFloat(temp.get("LAST_SCORE").toString());
			float percent = (currnet_score - last_score) / last_score * 100;
			temp.put("score", currnet_score);
			temp.put("percent", String.format("%.2f", percent));
			temp.put("rules", temp.get("RULE_CNT"));
			list.add(temp);
		}
		result.setData(list);
		return result;
	}

	@Override
	public JSONObject setSchemaCycle(Map map) {
		// TODO Auto-generated method stub
		JSONObject info = new JSONObject();
		String schema_id = map.get("schema_id").toString();// 方案ID
		String name = map.get("name").toString();// 方案名称
		String unit = "";
		if(map.get("radio").toString().equals("N")){// 执行方式
			unit = "N";
		}else{
			unit = map.get("unit").toString();// 调度周期类型
		}
		int sample_rate = map.get("sample_rate") == null ? 0 : Integer.parseInt(map.get("sample_rate").toString());// 采样比例（分钟）
		String sample_time = map.get("sample_time").toString();// 采样时间
		info.put("schemaId", schema_id);// 方案id
		info.put("schemaName", name);// 调度周期类型
		// 查询评估方案基础信息
		List basicInfo = qmBusinessDao.querySchemaBasicInfo(map);
		Map basicMap = (Map) basicInfo.get(0);
		String search_condition = basicMap.get("SEARCH_CONDITION").toString();// 统计维度
		String stat_dimention = basicMap.get("STAT_DIMENTION").toString();// 筛选条件
		String source_id = basicMap.get("SOURCE_ID").toString(); // 数据源
		Map sourceInfo = qmBusinessDao.queryDataSourceInfoById(source_id);
		JSONArray condtionArray = JSONArray.parseArray(search_condition);
		StringBuffer where_buf = new StringBuffer();
		String where = "";
		if(Integer.parseInt(sourceInfo.get("TYPE").toString())==2){//数据库类型的
			for(int m=0;m<condtionArray.size();m++){
				JSONObject con = (JSONObject) condtionArray.get(m);
				if(con.get("value").toString().contains(",")){
					String []values = con.get("value").toString().split(",");
					StringBuffer inValues = new StringBuffer();
					for(String v : values){
						inValues.append("'").append(v.trim()).append(",");
					}
					where_buf.append(con.get("field")).append(" in( ").append(inValues).append(") and ");
				}else{
					where_buf.append(con.get("field")).append(" = ").append(con.get("value")).append(" and ");
				}
			}
			where = where_buf.substring(0, where_buf.length()-5);//去掉最后得and
		}else{
			//es类型 {"query":{"match_all":{}}}
			JSONArray must = new JSONArray();
			for(int m=0;m<condtionArray.size();m++){
				JSONObject con = (JSONObject) condtionArray.get(m);
				String []values = con.get("value").toString().split(",");
				JSONObject bool = new JSONObject();
				JSONArray shouldArray = new  JSONArray();
				for(String val : values){
					JSONObject tempTerm = new JSONObject();
					JSONObject terms = new JSONObject();
					terms.put(con.get("field").toString(), "["+val+"]");
					terms.put("boost", 1.0);
					tempTerm.put("terms", terms);
					shouldArray.add(tempTerm);
				}
				bool.put("should", shouldArray);
				bool.put("disable_coord", false);
				bool.put("adjust_pure_negative", true);
				bool.put("boost", 1.0);
				JSONObject tempBool = new JSONObject();
				tempBool.put("bool", bool);
				must.add(bool);
			}
			JSONObject tempMust = new JSONObject();
			tempMust.put("must", must);
			JSONObject bool = new JSONObject();
			bool.put("bool", tempMust);
			bool.put("disable_coord", false);
			bool.put("adjust_pure_negative", true);
			bool.put("boost", 1.0);
			where = bool.toString();
		}
		info.put("statDimentions", search_condition.split(","));
		info.put("condition", where);
		info.put("sample", sample_rate); // 采样比例
		info.put("type", sourceInfo.get("TYPE"));// 数据源类型
		info.put("storeId", source_id); // 元数据的存储表id
		info.put("table", sourceInfo.get("CODE"));
		info.put("timeColumn", sourceInfo.get("TIMECOLUMN"));// 时间戳字段
		info.put("slicetime", sourceInfo.get("PARTITIONFIELD"));// 时间片字段

		// 查询方案绑定的规则
		List<FieldRuleVo> ruleList = qmBusinessDao.querySchemaFieldRule(schema_id);
		// 拆解及组装字段级规则
		Map ruleMap = new HashMap();
		Map ruleParamMap = new HashMap();
		List<Map> mapList = (List<Map>) qmBusinessDao.queryBasicRuleMap();
		for (Map temp : mapList) {
			ruleMap.put(temp.get("CODE"), temp.get("FUNC_NAME"));
			ruleParamMap.put(temp.get("CODE"), temp.get("PARAM_TYPE"));
		}

		JSONArray fieldRules = makeFiledInfo(ruleList, ruleMap, ruleParamMap);
		info.put("fieldRules", fieldRules);
		// 拆解及组装表级规则
		List<FieldRuleVo> mulRuleList = qmBusinessDao.querySchemaMultiFieldRule(schema_id);
		JSONArray tableRules = makeMulFiledInfo(mulRuleList, ruleMap);
		info.put("tableRules", tableRules);
		// 更新方案
		qmBusinessDao.updateSchemaInfo(map);
		// 调用ferrybuilder
		RestTemplate restTemplate = new RestTemplate();
		ResultEntity<ReturnEntity> fb_result = restTemplate.postForObject(
				GlobalConstants.FERRYBUILDER_URL + "/DataQualityController/querySourceBindStandarRule", info,
				ResultEntity.class);
		if (fb_result.getStatus() == true) {
			ReturnEntity fb_entity = fb_result.getData();
			// 与ETL通信
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("etlName", schema_id);
			paramMap.put("taskType", unit.equals("N") ? 1 : 0);// 0：周期执行,1:立即执行
			paramMap.put("sliceType", unit);
			paramMap.put("delayMinute", sourceInfo.get("DELAYTIME"));// 延迟时间 分钟
			paramMap.put("isActive", "1");// 0=禁用 1=启用
			paramMap.put("isTimerJobActive", "1");// 0=禁用 1=启用
			paramMap.put("userId", "");
			paramMap.put("etlFristGroup", "");
			paramMap.put("etlSecondaryGroup", "");
			paramMap.put("hostname", fb_entity.getHostname());
			paramMap.put("username", fb_entity.getUsername());
			paramMap.put("password", fb_entity.getPassword());
			paramMap.put("shellFile", fb_entity.getShellFile());
			paramMap.put("yarnAddress", fb_entity.getYarnAddress());
			if (unit.equals("D")) {
				paramMap.put("ferryTimeFormat", "{startDate:yyyyMMdd}");
			} else if (unit.equals("M")) {
				paramMap.put("ferryTimeFormat", "{startDate:yyyyMM}");
			}
			try {
				etlService.createWorkEtl(paramMap, "qmSchemaTask");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return info;
	}

	/**
	 * 拆解及组装字段级规则
	 * 
	 * @param ruleList
	 * @return
	 */
	public JSONArray makeFiledInfo(List<FieldRuleVo> ruleList, Map ruleMap, Map ruleParamMap) {
		JSONArray fieldRules = new JSONArray();
		for (FieldRuleVo vo : ruleList) {
			JSONObject rule = new JSONObject();
			rule.put("id", vo.getId());// 规则ID
			rule.put("column", vo.getField());// 指定字段名
			JSONArray baseRules = new JSONArray();
			JSONArray boundRule = vo.getBoundRule();// 规则配置详细参数
			for (int i = 0; i < boundRule.size(); i++) {
				JSONObject baseRule = new JSONObject();
				JSONObject obj = (JSONObject) boundRule.get(i);
				baseRule.put("code", ruleMap.get(obj.get("ruleValue")));//// 基础规则code，固定，函数名
				baseRule.put("range", obj.get("s_e_pos").toString()); // 分段规则的范围，如果是0代表不分段
				String[] paramTypes = ruleParamMap.get(obj.get("ruleValue")).toString().split(",");
				JSONArray params = new JSONArray();
				boolean flag = false;
				StringBuffer caseWhen = new StringBuffer();
				if (null != obj.getJSONArray("params") && obj.getJSONArray("params").size() > 0) {
					JSONArray uiParams = obj.getJSONArray("params");
					for (int m = 0; m < uiParams.size(); m++) {
						JSONObject uiParam = (JSONObject) uiParams.get(m);
						if (null != uiParam.get("when")) {
							// case when a=1 and b=1 then 0 when a=2 and b=2 then 0 else 1 end
							flag = true;
							StringBuffer where = new StringBuffer();
							JSONArray whenArray = uiParam.getJSONArray("when");
							JSONArray thenArray = uiParam.getJSONArray("then");
							for (int n = 0; n < whenArray.size(); n++) {
								JSONObject whenO = (JSONObject) whenArray.get(n);
								where.append(whenO.get("field")).append(whenO.get("operator"))
										.append(whenO.get("value")).append(" ").append("and ");
							}
							for (int n = 0; n < thenArray.size(); n++) {
								JSONObject caseO = (JSONObject) thenArray.get(n);
								if (n != thenArray.size() - 1) {
									where.append(caseO.get("field")).append(caseO.get("operator"))
											.append(caseO.get("value")).append(" ").append("and ");
								} else {
									where.append(caseO.get("field")).append(caseO.get("operator"))
											.append(caseO.get("value")).append(" ");
								}
							}
							if (caseWhen.length() == 0) {
								caseWhen.append("case when " + where.toString() + "then 0 ");
							} else {
								caseWhen.append(" when " + where.toString() + "then 0 ");
							}

						} else {
							JSONObject p = new JSONObject();
							p.put("type", paramTypes[m]);
							p.put("name", uiParam.get("value").toString().replace("[", "").replace("]", ""));
							params.add(p);
						}
					}
				}
				if (flag) {
					String[] p = { caseWhen.toString() + " else 1 end" };
					baseRule.put("params", p);
				}
				baseRule.put("params", params);
				baseRules.add(baseRule);
			}
			rule.put("baseRules", baseRules);
			fieldRules.add(rule);
		}
		return fieldRules;
	}

	/**
	 * 拆解及组装表级规则
	 * 
	 * @param ruleList
	 * @return
	 */
	public JSONArray makeMulFiledInfo(List<FieldRuleVo> ruleList, Map ruleMap) {
		JSONArray tableRules = new JSONArray();
		for (FieldRuleVo vo : ruleList) {
			JSONObject obj = new JSONObject();
			obj.put("id", vo.getId());
			obj.put("code", ruleMap.get(vo.getId()));
			String[] params = vo.getField().toString().replace("[", "").replace("]", "").split(",");
			obj.put("params", params);
			tableRules.add(obj);
		}
		return tableRules;
	}

	@Override
	public ResultEntity querySchemaComboxByType(Map map) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		// 根据类型查询哪个下拉列表值
		String type = map.get("type").toString();
		List<ComboxVo> list = new ArrayList<ComboxVo>();
		if (type.equals("querySources")) {
			// 查询数据源
			list = qmBusinessDao.querySchemaComboxSource();
			result.setData(list);
		} else if (type.equals("queryBasicRules")) {
			// 获取基础规则
			List<Map> basicList = qmBusinessDao.queryBasicRules();
			JSONArray result_json = new JSONArray();
			for (Map temp : basicList) {
				JSONObject vo = new JSONObject();
				vo.put("label", temp.get("NAME").toString());
				vo.put("value", temp.get("CODE").toString());
				if (temp.get("CODE").toString().equals("200015")) {
					vo.put("ruleType", 2);
				} else {
					vo.put("ruleType", 1);
				}
				if (null != temp.get("PARAM_UI_TYPE")) {
					String[] param_ui_type = temp.get("PARAM_UI_TYPE").toString().split(",");
					String[] param_name = temp.get("PARAM_NAME").toString().split(",");
					JSONArray array = new JSONArray();
					for (int m = 0; m < param_ui_type.length; m++) {
						JSONObject t = new JSONObject();
						t.put("label", param_name[m]);
						t.put("type", param_ui_type[m]);
						t.put("value", "");
						t.put("text", "");
						array.add(t);
					}
					vo.put("enumList", array);
				} else {
					vo.put("enumList", new JSONArray());
				}
				result_json.add(vo);
			}
			list = qmBusinessDao.queryMultiRules();
			JSONObject obj = new JSONObject();
			obj.put("basic_rules", result_json);
			obj.put("table_rules", list);
			result.setData(obj);
		} else if (type.equals("queryOperators")) {
			// 获取所有的操作符
			list = qmBusinessDao.queryOperators();
			result.setData(list);
		} else if (type.equals("querySourceFields")) {
			// 查询数据源对应的字段、标准规则
			JSONObject resultJson = new JSONObject();
			List<ComboxVo> allFields = new ArrayList<ComboxVo>();// 所有字段 结构：字段code，字段name
			List<ComboxVo> enumFields = new ArrayList<ComboxVo>();// 枚举字段 结构： 字段code，字段name,枚举值list(枚举值，枚举名称)
			JSONArray fieldBindRule = new JSONArray();
			JSONObject fieldRule = null;
			RestTemplate restTemplate = new RestTemplate();
			Map param = new HashMap();
			param.put("source_id", map.get("dataSource").toString());
			String result_s = restTemplate.postForObject(
					GlobalConstants.METADATA_URL + "/DataQualityController/querySourceBindStandarRule", param,
					String.class);
			JSONObject result_obj = (JSONObject) JSONObject.parse(result_s);
			JSONArray array = (JSONArray) result_obj.get("data");
			if (null != array) {
				for (int i = 0; i < array.size(); i++) {
					JSONObject obj = (JSONObject) array.get(i);
					ComboxVo vo = new ComboxVo();
					vo.setValue(obj.get("field_code").toString());// 字段code
					vo.setLabel(obj.get("field_name").toString());// 字段name
					allFields.add(vo);
					if (null != obj.get("enumType") && obj.get("enumType").toString().equals("0")) {
						// 字段是否是枚举类型 ：0枚举，1非枚举，
						JSONArray enumArray = JSONArray.parseArray(obj.get("enumList").toString());
						List<ComboxVo> enumList = new ArrayList<ComboxVo>();
						if (null != enumArray && enumArray.size() > 0) {
							for (int m = 0; m < enumArray.size(); m++) {
								ComboxVo temp = new ComboxVo();
								JSONObject e_obj = (JSONObject) enumArray.get(m);
								temp.setValue(e_obj.get("value").toString());
								temp.setLabel(e_obj.get("name").toString());
								enumList.add(temp);
							}
						}
						vo.setEnumList(enumList);
						enumFields.add(vo);
					}
					// 字段与规则绑定
					fieldRule = new JSONObject();
					JSONArray boundRule = new JSONArray();
					if (null != obj.get("rule_link_id")) {
						fieldRule.put("id", obj.get("rule_link_id") == null ? "" : obj.get("rule_link_id").toString());
						fieldRule.put("ruleName",
								obj.get("rule_link_name") == null ? "" : obj.get("rule_link_name").toString());
						fieldRule.put("field", obj.get("field_code") == null ? "" : obj.get("field_code").toString());
						fieldRule.put("fieldName",
								obj.get("field_name") == null ? "" : obj.get("field_name").toString());
						fieldRule.put("ruleType", 1);
						// 将标准规则拆解成基础规则
						if (null != obj.get("basic_info")) {
							String ori_basic_info = obj.get("basic_info").toString();
							boundRule = changeStandard2BasicRule(ori_basic_info, obj.get("field_name").toString());
						}
						fieldRule.put("boundRule", boundRule);
						fieldBindRule.add(fieldRule);
					}
				}
			}
			resultJson.put("allFields", allFields);// 所有的字段
			resultJson.put("enumFields", enumFields);// 枚举值的字段
			resultJson.put("fieldBindRule", fieldBindRule);
			result.setData(resultJson);
			List<Map> basicList = qmBusinessDao.queryBasicRules();
			// 拼接规则与对应的下拉列表
			JSONObject ruleSel = new JSONObject();
			for (Map temp : basicList) {
				if (temp.get("CODE").equals("200006")) {// 枚举值校验
					JSONArray enumArray = new JSONArray();
					for (ComboxVo vo : enumFields) {
						JSONObject o = new JSONObject();
						o.put("label", vo.getLabel());
						o.put("value", vo.getValue());
						enumArray.add(o);
						List<ComboxVo> valueList = vo.getEnumList();
						ruleSel.put(vo.getValue(), valueList);
					}
					ruleSel.put("200006", enumArray);
				}
				if (temp.get("CODE").equals("200001")) {// 类型校验 ;1:整型;2:浮点型;3:字符串;4:日期型
					JSONArray typeArray = new JSONArray();
					JSONObject o = new JSONObject();
					o.put("label", "整型");
					o.put("value", 1);
					typeArray.add(o);
					o = new JSONObject();
					o.put("label", "浮点型");
					o.put("value", 2);
					typeArray.add(o);
					o = new JSONObject();
					o.put("label", "字符串");
					o.put("value", 3);
					typeArray.add(o);
					o = new JSONObject();
					o.put("label", "日期型");
					o.put("value", 4);
					typeArray.add(o);
					ruleSel.put("200001", typeArray);
				}
				if (temp.get("CODE").equals("200005")) {// 日期格式
					List<ComboxVo> timeList = qmBusinessDao.queryDateFormat();
					ruleSel.put("200005", timeList);
				}
			}
			resultJson.put("ruleSel", ruleSel);
			result.setData(resultJson);
		}
		return result;
	}

	/**
	 * 将标准规则拆解成基础规则
	 * 
	 * @param ori_basic_info
	 * @return
	 */
	public JSONArray changeStandard2BasicRule(String ori_basic_info, String field_name) {
		JSONArray boundRule = new JSONArray();
		JSONObject temp = new JSONObject();
		JSONObject obj = (JSONObject) JSONObject.parse(ori_basic_info);
		Map paramMap = null;
		String[] paramNames = null;
		String[] paramUiType = null;
		int data_type = Integer.parseInt(obj.get("data_type").toString());// 数据类型；1=整型 2=浮点 3=字符串 4=日期 5=二进制
		// 根据基础规则ID查询基础规则对应的参数信息
		paramMap = qmBusinessDao.queryBasicInfoByCode("200001");
		temp.put("ruleLabel", paramMap.get("NAME"));// 规则名称
		temp.put("ruleValue", "200001");// 规则ID 类型校验
		temp.put("s_e_pos", "");// 开始、结束位置
		temp.put("ruleType", 1);// 规则类型
		paramNames = paramMap.get("PARAM_NAME").toString().split(",");// 参数名字
		paramUiType = paramMap.get("PARAM_UI_TYPE").toString().split(",");// 参数对应的页面类型
		JSONArray params = new JSONArray();
		for (int i = 0; i < paramNames.length; i++) {
			JSONObject o = new JSONObject();
			o.put("label", paramNames[i]);
			o.put("type", paramUiType[i]);
			if (i == 0) {
				o.put("value", field_name);
				o.put("text", field_name);
			} else {
				o.put("value", data_type);
				o.put("text", data_type);
			}
			params.add(o);
		}
		temp.put("params", params);
		boundRule.add(temp);
		int nullable = Integer.parseInt(obj.get("nullable").toString());// 能否为空；0=是 1=否
		if (nullable == 1) {
			temp = new JSONObject();
			temp.put("ruleLabel", "字段必填");// 规则名称
			temp.put("ruleValue", "200002");// 规则ID 类型校验
			temp.put("s_e_pos", "");// 开始、结束位置
			temp.put("ruleType", 1);// 规则类型
			temp.put("params", "");
			boundRule.add(temp);
		}
		if (null != obj.get("data_length") && !obj.get("data_length").equals("null")) {
			// 长度校验
			makeBasicRule("200004", obj.get("data_length").toString(), boundRule, "");
		}
		if (null != obj.get("data_precision") && !obj.get("data_precision").equals("null")) {
			// 精度校验
			int data_precision = Integer.parseInt(obj.get("data_precision").toString());
			int data_length = Integer.parseInt(obj.get("data_length").toString());
			paramMap = qmBusinessDao.queryBasicInfoByCode("200003");
			temp = new JSONObject();
			temp.put("ruleLabel", paramMap.get("NAME"));// 规则名称
			temp.put("ruleValue", "200003");// 规则ID
			temp.put("s_e_pos", "");// 开始、结束位置
			temp.put("ruleType", 1);// 规则类型
			paramNames = paramMap.get("PARAM_NAME").toString().split(",");// 参数名字
			paramUiType = paramMap.get("PARAM_UI_TYPE").toString().split(",");// 参数对应的页面类型
			params = new JSONArray();
			for (int i = 0; i < paramNames.length; i++) {
				JSONObject o = new JSONObject();
				o.put("label", paramNames[i]);
				o.put("type", paramUiType[i]);
				if (i == 0) {
					o.put("value", data_length);
					o.put("text", data_length);
				} else {
					o.put("value", data_precision);
					o.put("text", data_precision);
				}

				params.add(o);
			}
			temp.put("params", params);
			boundRule.add(temp);
		}
		if (null != obj.get("min_length") && !obj.get("min_length").equals("null")
				|| null != obj.get("max_length") && !obj.get("max_length").equals("null")) {
			// 长度校验
			paramMap = qmBusinessDao.queryBasicInfoByCode("200004");
			temp = new JSONObject();
			temp.put("ruleLabel", paramMap.get("NAME"));// 规则名称
			temp.put("ruleValue", "200004");// 规则ID
			temp.put("s_e_pos", "");// 开始、结束位置
			temp.put("ruleType", 1);// 规则类型
			paramNames = paramMap.get("PARAM_NAME").toString().split(",");// 参数名字
			paramUiType = paramMap.get("PARAM_UI_TYPE").toString().split(",");// 参数对应的页面类型
			params = new JSONArray();
			for (int i = 0; i < paramNames.length; i++) {
				JSONObject o = new JSONObject();
				o.put("label", paramNames[i]);
				o.put("type", paramUiType[i]);
				if (i == 0) {
					if (null != obj.get("min_length") && !obj.get("min_length").equals("null")) {
						o.put("value",
								obj.get("min_length") == null ? 0 : Integer.parseInt(obj.get("min_length").toString()));
						o.put("text",
								obj.get("min_length") == null ? 0 : Integer.parseInt(obj.get("min_length").toString()));
					} else {
						o.put("value",
								obj.get("max_length") == null ? 0 : Integer.parseInt(obj.get("max_length").toString()));
						o.put("text",
								obj.get("max_length") == null ? 0 : Integer.parseInt(obj.get("max_length").toString()));
					}
				}
				if (i == 1) {
					if (null != obj.get("max_length") && !obj.get("max_length").equals("null")) {
						o.put("value", Integer.parseInt(obj.get("max_length").toString()));
						o.put("text", Integer.parseInt(obj.get("max_length").toString()));
					} else {
						o.put("value", "");
						o.put("text", "");
					}
				}
				params.add(o);
			}
			temp.put("params", params);
			boundRule.add(temp);
		}
		if (null != obj.get("time_format") && !obj.get("time_format").equals("null")) {
			// 日期格式校验
			makeBasicRule("200005", obj.get("time_format").toString(), boundRule, "");
		}
		// 拆解值域部分
		if (null != obj.get("range_segment")) {
			JSONArray range_segments = JSONArray.parseArray(obj.get("range_segment").toString());
			for (int m = 0; m < range_segments.size(); m++) {
				JSONObject segment = (JSONObject) range_segments.get(m);
				int start_pos = Integer.parseInt(segment.get("start_pos").toString());
				int end_pos = Integer.parseInt(segment.get("end_pos").toString());
				int type = Integer.parseInt(segment.get("type").toString());
				// type 规则类别；0=枚举类型；1=数字范围；2=日期时间；3=特殊字符；4=校验码；5=值域规则；6=字母数字组合；7=正则表达式
				temp = new JSONObject();
				JSONObject segmentParams = (JSONObject) segment.get("params");
				if (null != segmentParams.get("exclude_nums") && !segmentParams.get("exclude_nums").equals("null")) {// 不包含的数值
					makeBasicRule("200007", segmentParams.get("exclude_nums").toString(), boundRule,
							start_pos + "," + end_pos);
				}
				if (null != segmentParams.get("time_format") && !segmentParams.get("time_format").equals("null")) {// 时间格式
					makeBasicRule("200005", segmentParams.get("time_format").toString(), boundRule,
							start_pos + "," + end_pos);
				}
				if (null != segmentParams.get("special_char") && !segmentParams.get("special_char").equals("null")) {// 特殊字符
					makeBasicRule("200011", segmentParams.get("special_char").toString(), boundRule,
							start_pos + "," + end_pos);
				}
				if (null != segmentParams.get("min_num") && !segmentParams.get("min_num").equals("null")
						|| null != segmentParams.get("max_num") && !segmentParams.get("max_num").equals("null")) {// 数字范围
					paramMap = qmBusinessDao.queryBasicInfoByCode("200012");
					temp = new JSONObject();
					temp.put("ruleLabel", paramMap.get("NAME"));// 规则名称
					temp.put("ruleValue", "200012");// 规则ID
					temp.put("s_e_pos", start_pos + "," + end_pos);// 开始、结束位置
					temp.put("ruleType", 1);// 规则类型
					paramNames = paramMap.get("PARAM_NAME").toString().split(",");// 参数名字
					paramUiType = paramMap.get("PARAM_UI_TYPE").toString().split(",");// 参数对应的页面类型
					params = new JSONArray();
					for (int i = 0; i < paramNames.length; i++) {
						JSONObject o = new JSONObject();
						o.put("label", paramNames[i]);
						o.put("type", paramUiType[i]);
						if (i == 0) {
							o.put("value", segmentParams.get("min_num") == null ? 0 : segmentParams.get("min_num"));
							o.put("text",
									"最小值" + segmentParams.get("min_num") == null ? 0 : segmentParams.get("min_num"));
						} else {
							o.put("value", segmentParams.get("max_num") == null ? 0 : segmentParams.get("max_num"));
							o.put("text",
									"最大值" + segmentParams.get("max_num") == null ? 0 : segmentParams.get("max_num"));
						}

						params.add(o);
					}
					temp.put("params", params);
					boundRule.add(temp);
				}
				if (null != segmentParams.get("regular_exp") && !segmentParams.get("regular_exp").equals("null")) {// 正则表达式
					makeBasicRule("200013", segmentParams.get("regular_exp").toString(), boundRule,
							start_pos + "," + end_pos);
				}
				if (null != segmentParams.get("enum_value") && !segmentParams.get("enum_value").equals("null")) {// 枚举值；以/分割
					makeBasicRule("200009", segmentParams.get("enum_value").toString(), boundRule,
							start_pos + "," + end_pos);
				}
				if (null != segmentParams.get("contain_type") && !segmentParams.get("contain_type").equals("null")) {// 字母数字组合校验
					// 字母数字包含类型；0=数字；1=大写字母；2=小写字母
					paramMap = qmBusinessDao.queryBasicInfoByCode("200014");
					temp = new JSONObject();
					temp.put("ruleLabel", paramMap.get("NAME"));// 规则名称
					temp.put("ruleValue", "200014");// 规则ID
					temp.put("s_e_pos", start_pos + "," + end_pos);// 开始、结束位置
					temp.put("ruleType", 1);// 规则类型
					paramNames = paramMap.get("PARAM_NAME").toString().split(",");// 参数名字
					paramUiType = paramMap.get("PARAM_UI_TYPE").toString().split(",");// 参数对应的页面类型
					params = new JSONArray();
					for (int i = 0; i < paramNames.length; i++) {
						JSONObject o = new JSONObject();
						o.put("label", paramNames[i]);
						o.put("type", paramUiType[i]);
						if (i == 0) {
							o.put("value", segmentParams.get("contain_type"));
							String text = segmentParams.get("contain_type").toString().replace("0", "数字")
									.replace("1", "大写字母").replace("2", "小写字母");
							o.put("text", text);
						} else if (i == 1) {// 范围；0=包含；1=不包含
							o.put("value",
									segmentParams.get("range_type") == null ? "" : segmentParams.get("range_type"));
							if (null != segmentParams.get("range_type")
									&& !segmentParams.get("range_type").equals("null")) {
								o.put("text", segmentParams.get("range_type").equals("0") ? "包含" : "不包含");
							} else {
								o.put("text", "无");
							}
						} else {
							o.put("value", segmentParams.get("range_character") == null ? ""
									: segmentParams.get("range_character"));
							if (null != segmentParams.get("range_character")
									&& !segmentParams.get("range_character").equals("null")) {
								o.put("text", segmentParams.get("range_character") == null ? ""
										: segmentParams.get("range_character"));
							} else {
								o.put("text", "无");
							}
						}
						params.add(o);
					}
					temp.put("params", params);
					boundRule.add(temp);
				}
			}
		}
		return boundRule;
	}

	private void makeBasicRule(String basicRuleId, String basicRuleValue, JSONArray boundRule, String s_e_pos) {
		Map paramMap = qmBusinessDao.queryBasicInfoByCode(basicRuleId);
		JSONObject temp = new JSONObject();
		temp.put("ruleLabel", paramMap.get("NAME"));// 规则名称
		temp.put("ruleValue", "200003");// 规则ID
		temp.put("s_e_pos", s_e_pos);// 开始、结束位置
		temp.put("ruleType", 1);// 规则类型
		String[] paramNames = paramMap.get("PARAM_NAME").toString().split(",");// 参数名字
		String[] paramUiType = paramMap.get("PARAM_UI_TYPE").toString().split(",");// 参数对应的页面类型
		JSONArray params = new JSONArray();
		for (int i = 0; i < paramNames.length; i++) {
			JSONObject o = new JSONObject();
			o.put("label", paramNames[i]);
			o.put("type", paramUiType[i]);
			o.put("value", basicRuleValue);
			o.put("text", basicRuleValue);
			params.add(o);
		}
		temp.put("params", params);
		boundRule.add(temp);
	}

	/**
	 * 获取字段对应的枚举值
	 * 
	 * @param source_id
	 * @param dimentions
	 * @return
	 */
	private Map[] makeEnumMap(String source_id, String[] dimentions) {
		RestTemplate restTemplate = new RestTemplate();
		Map[] enumMap = new HashMap[dimentions.length];
		for(int i = 0; i < dimentions.length; i++){
			enumMap[i] = new HashMap<String,String>();
			}
		// 获取统计维度对应的枚举值
		for (int m = 0; m < dimentions.length; m++) {
			Map param = new HashMap();
			String dim = dimentions[m];
			param.put("field_code", dim);
			param.put("source_id", source_id);
			// 根据数据源+字段查询 字段对应枚举值
			String result_s = restTemplate.postForObject(
					GlobalConstants.METADATA_URL + "/DataQualityController/queryEnumBySourceAndField", param,
					String.class);
			JSONObject obj = (JSONObject) JSONObject.parse(result_s);
			JSONArray array = JSONArray.parseArray(obj.get("data").toString());
			for (int n = 0; n < array.size(); n++) {
				JSONObject t = (JSONObject) array.get(n);
				enumMap[m].put(t.get("value"), t.get("name"));
			}
		}
		return enumMap;
	}

	@Override
	public ResultEntity exportReport(Map map,HttpServletRequest request,HttpServletResponse res) {
		// TODO Auto-generated method stub
		// 字段级统计
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		List<ExportDimFieldStatVo> exportDimFieldList = new ArrayList<ExportDimFieldStatVo>();// 带维度的字段统计
		List<ExportDimFieldStatVo> exportDimFieldAndRuleList = new ArrayList<ExportDimFieldStatVo>();// 带维度的字段规则统计
		List<ExportFieldStatVo> exportFieldList = new ArrayList<ExportFieldStatVo>();// 带维度的字段统计
		List<ExportFieldStatVo> exportFieldAndRuleList = new ArrayList<ExportFieldStatVo>();// 带维度的字段规则统计
		Map infoMap = qmBusinessDao.querySchemaTaskDimention(map);
		List<Map> fieldList = new ArrayList<Map>();
		List<Map> fieldAndRuleList = new ArrayList<Map>();
		String type = "0";// 是否有维度 0：没有维度，1：有维度
		Map[] enumMap = null;
		if (null != infoMap.get("STAT_DIMENTION")) {
			// 按维度统计
			fieldList = qmBusinessDao.queryDimFieldStat(map);
			fieldAndRuleList = qmBusinessDao.queryDimFieldAndRuleStat(map);
			type = "1";
			String[] dimentions = infoMap.get("STAT_DIMENTION").toString().split(",");
			enumMap = new HashMap[dimentions.length];
			enumMap = makeEnumMap(infoMap.get("SOURCE_ID").toString(), dimentions);
		} else {
			fieldList = qmBusinessDao.queryFieldStat(map);
			fieldAndRuleList = qmBusinessDao.queryFieldAndRuleStat(map);
		}
		if (type.equals("1")) {// 有维度
			// 字段级统计
			for (Map temp : fieldList) {
				ExportDimFieldStatVo vo = new ExportDimFieldStatVo();
				String[] stats = temp.get("STAT_DIMENTION").toString().split(",");
				StringBuffer statName = new StringBuffer();
				for (int i = 0; i < stats.length; i++) {
					if (i != stats.length - 1) {
						statName.append(enumMap[i].get(stats[i])).append(",");
					} else {
						statName.append(enumMap[i].get(stats[i]));
					}
				}
				vo.setStat_dimention(statName.toString());
				vo.setField_name(temp.get("FIELD_NAME").toString());
				vo.setRule_name(temp.get("RULE_NAME").toString());
				vo.setError_msg_cnt(Integer.parseInt(temp.get("CNT").toString()));
				exportDimFieldList.add(vo);
			}
			// 字段规则统计
			for (Map temp : fieldAndRuleList) {
				ExportDimFieldStatVo vo = new ExportDimFieldStatVo();
				String[] stats = temp.get("STAT_DIMENTION").toString().split(",");
				StringBuffer statName = new StringBuffer();
				for (int i = 0; i < stats.length; i++) {
					if (i != stats.length - 1) {
						statName.append(enumMap[i].get(stats[i])).append(",");
					} else {
						statName.append(enumMap[i].get(stats[i]));
					}
				}
				vo.setStat_dimention(statName.toString());
				vo.setField_name(temp.get("FIELD_NAME").toString());
				vo.setRule_name(temp.get("RULE_NAME").toString());
				vo.setError_msg_cnt(Integer.parseInt(temp.get("CNT").toString()));
				exportDimFieldAndRuleList.add(vo);
			}
		} else {
			// 字段级统计
			for (Map temp : fieldList) {
				ExportFieldStatVo vo = new ExportFieldStatVo();
				vo.setField_name(temp.get("FIELD_NAME").toString());
				vo.setRule_name(temp.get("RULE_NAME").toString());
				vo.setError_msg_cnt(Integer.parseInt(temp.get("CNT").toString()));
				exportFieldList.add(vo);
			}
			// 字段规则统计
			for (Map temp : fieldAndRuleList) {
				ExportFieldStatVo vo = new ExportFieldStatVo();
				vo.setField_name(temp.get("FIELD_NAME").toString());
				vo.setRule_name(temp.get("RULE_NAME").toString());
				vo.setError_msg_cnt(Integer.parseInt(temp.get("CNT").toString()));
				exportFieldAndRuleList.add(vo);
			}
		}
		try {
			XSSFWorkbook workbook = new XSSFWorkbook();
			if (type.equals("1")) {
				XSSFSheet sheet = workbook.createSheet("字段");
				ExportExcel.exportExcel(workbook, sheet, exportDimFieldList, ExportDimFieldStatVo.class);
				XSSFSheet sheet2 = workbook.createSheet("规则");
				ExportExcel.exportExcel(workbook, sheet2, exportDimFieldAndRuleList, ExportDimFieldStatVo.class);
			} else {
				XSSFSheet sheet = workbook.createSheet("字段");
				ExportExcel.exportExcel(workbook, sheet, exportFieldList, ExportFieldStatVo.class);
				XSSFSheet sheet2 = workbook.createSheet("规则");
				ExportExcel.exportExcel(workbook, sheet2, exportFieldAndRuleList, ExportFieldStatVo.class);
			}
			String file_path = "";
			String fileName = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".xlsx";
			try {
				res.setContentType("application/octet-stream");// 返回一个二进制流
				res.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "utf-8"));
				res.addHeader("Access-Control-Expose-Headers","Content-Disposition");
				System.out.println(res.getHeader("Content-Disposition"));
				res.flushBuffer();
				workbook.write(res.getOutputStream());
				workbook.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			//workbook.write(new FileOutputStream(new File("E:\\text.xlsx")));
		} catch (NoSuchFieldException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		return null;
	}

	public static void main(String[] args) {
		List<ExportFieldStatVo> exportFieldAndRuleList = new ArrayList<ExportFieldStatVo>();
		ExportFieldStatVo vo = new ExportFieldStatVo();
		vo.setField_name("f1");
		vo.setRule_name("r1");
		vo.setError_msg_cnt(10);
		exportFieldAndRuleList.add(vo);
		vo = new ExportFieldStatVo();
		vo.setField_name("f2");
		vo.setRule_name("r3");
		vo.setError_msg_cnt(20);
		exportFieldAndRuleList.add(vo);
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("字段");
		XSSFSheet sheet2 = workbook.createSheet("规则");
		try {
			ExportExcel.exportExcel(workbook, sheet, exportFieldAndRuleList, ExportFieldStatVo.class);
			vo = new ExportFieldStatVo();
			vo.setField_name("fddd");
			vo.setRule_name("sss");
			vo.setError_msg_cnt(240);
			exportFieldAndRuleList.add(vo);
			ExportExcel.exportExcel(workbook, sheet2, exportFieldAndRuleList, ExportFieldStatVo.class);
			workbook.write(new FileOutputStream(new File("E:\\text.xlsx")));
			System.out.println("成功");
		} catch (NoSuchFieldException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public ResultEntity queryScheme(Map map) {
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		List list = qmBusinessDao.queryScheme(map);
		result.setData(list);
		return result;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public PageInfo<BaseTaskResult> queryLinkRatio(Map<String, Object> map) {
		// TODO Auto-generated method stub
		Integer currentPage = (Integer) map.get("pageNum") == null ? 1 : (Integer) map.get("pageNum");
		Integer pageSize = (Integer) map.get("pageSize") == null ? 20 : (Integer) map.get("pageSize");
		PageHelper.startPage(currentPage, pageSize);
		List<BaseTaskResult> res = qmBusinessDao.queryLinkRatio(map);
		PageInfo<BaseTaskResult> pageInfo = new PageInfo(res);
		return pageInfo;
	}

	@SuppressWarnings({ "rawtypes", "unchecked", "null" })
	@Override
	public ResultEntity queryStatis(Map map) {
		ResultEntity resultEntity = new ResultEntity();
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		List<BaseTaskResult> res = qmBusinessDao.queryStatis(map);
		List<String> nameArray = new ArrayList<String>();
		List<String> timeArray = new ArrayList<String>();
		List<String> codeArray = new ArrayList<String>();

		Map infoMap = qmBusinessDao.querySchemaTaskDimention(map);
		Map[] enumMap = null;
		if (null != infoMap.get("STAT_DIMENTION")) {
			String[] dimentions = infoMap.get("STAT_DIMENTION").toString().split(",");
			enumMap = new HashMap[dimentions.length];
			enumMap = makeEnumMap(infoMap.get("SOURCE_ID").toString(), dimentions);
		}
		for (int i = 0; i < res.size(); i++) {
			if (res.get(i).getStat_dimention() != null) {
				String[] stats = res.get(i).getStat_dimention().split(",");
				StringBuffer statName = new StringBuffer();
				StringBuffer statCode = new StringBuffer();
				for (int j = 0; j < stats.length; j++) {
					if (j != stats.length - 1) {
						statName.append(enumMap[j].get(stats[j])).append(",");
						statCode.append(stats[j]).append(",");
					} else {
						statName.append(enumMap[j].get(stats[j]));
						statCode.append(stats[j]);
					}
				}
				if (!nameArray.contains(statName.toString()) && !"null".equals(statName.toString())) {
					nameArray.add(statName.toString());
					codeArray.add(statCode.toString());
				}
			}
			if (!timeArray.contains(res.get(i).getCreate_time()) && res.get(i).getCreate_time() != null) {
				timeArray.add(res.get(i).getCreate_time());
			}
		}
		if (nameArray.size() == 0) {
			nameArray.add("正确率趋势");
			List<String> data = new ArrayList<String>();
			JSONObject json = new JSONObject();
			for (int j = 0; j < timeArray.size(); j++) {
				for (int k = 0; k < res.size(); k++) {
					if (timeArray.get(j).equals(res.get(k).getCreate_time())) {
						data.add(res.get(k).getPrecent());
						break;
					} else if (k == (res.size() - 1)) {
						data.add("0");
						break;
					}
				}
			}
			json.put("name", nameArray.get(0));
			json.put("type", "line");
			json.put("data", data);
			jsonArray.add(json);
		} else {
			for (int i = 0; i < codeArray.size(); i++) {
				JSONObject json = new JSONObject();
				List<String> data = new ArrayList<String>();
				for (int j = 0; j < timeArray.size(); j++) {
					for (int k = 0; k < res.size(); k++) {
						if (codeArray.get(i).equals(res.get(k).getStat_dimention())
								&& timeArray.get(j).equals(res.get(k).getCreate_time())) {
							data.add(res.get(k).getPrecent());
							break;
						} else if (k == (res.size() - 1)) {
							data.add("0");
							break;
						}
					}
				}
				json.put("name", nameArray.get(i));
				json.put("type", "line");
				json.put("data", data);
				jsonArray.add(json);
			}
		}
		jsonObject.put("name", nameArray);
		jsonObject.put("time", timeArray);
		jsonObject.put("series", jsonArray);
		resultEntity.setStatus(true);
		resultEntity.setData(jsonObject);
		return resultEntity;
	}
	@Override
	public ResultEntity startOrStopSchema(Map map) {
		// TODO Auto-generated method stub
		String startOrStop = map.get("startOrStop").toString();
		ResultEntity result = new ResultEntity();
		RestTemplate restTemplate = new RestTemplate();
		Map param = new HashMap();
		param.put("processName", map.get("schemaId").toString());
		if(startOrStop.equals("stop")){//暂停   //4：暂停，5：启动
			String result_s = restTemplate.postForObject(GlobalConstants.ETL_URL + "/etl/app/controller/etlproController/updateEtlProcessActivePause", param, String.class);
			map.put("status", 4);
		}else if(startOrStop.equals("start")){//启动
			String result_s = restTemplate.postForObject(GlobalConstants.ETL_URL + "/etl/app/controller/etlproController/updateEtlProAndTimeJobIsActiveByProCode", param, String.class);
			map.put("status", 5);
		}
		qmBusinessDao.updateTaskInfo(map);
		result.setStatus(true);
		return result;
	}

	// 维度
	@Override
	public ResultEntity queryDimension(Map map) {
		ResultEntity result = new ResultEntity();
		JSONObject jsonObject = new JSONObject();
		result.setStatus(true);

		Map infoMap = qmBusinessDao.querySchemaTaskDimention(map);
		List<BaseTaskResult> list = new ArrayList<BaseTaskResult>();
		String type = "0";// 是否有维度 0：没有维度，1：有维度
		Map[] enumMap = null;
		if (null != infoMap.get("STAT_DIMENTION")) {
			// 按维度统计
			list = qmBusinessDao.statSchemaTaskErrorMsgByDimention(map);
			type = "1";
			String[] dimentions = infoMap.get("STAT_DIMENTION").toString().split(",");
			enumMap = new HashMap[dimentions.length];
			enumMap = makeEnumMap(infoMap.get("SOURCE_ID").toString(), dimentions);
		}
		JSONArray array = new JSONArray();
		List<String> amount = new ArrayList<String>();// 总数
		List<String> correct = new ArrayList<String>();
		List<String> ratio = new ArrayList<String>();// 正确率
		List<String> stat_dimention = new ArrayList<String>(); // X轴维度
		for (BaseTaskResult entity : list) {
			JSONObject o = new JSONObject();
			if (type.equals("1")) {
				String[] stats = entity.getStat_dimention().split(",");
				StringBuffer statName = new StringBuffer();
				for (int i = 0; i < stats.length; i++) {
					if (i != stats.length - 1) {
						statName.append(enumMap[i].get(stats[i])).append(",");
					} else {
						statName.append(enumMap[i].get(stats[i]));
					}
				}
				stat_dimention.add(statName.toString());
				// stat_dimention.add(entity.getStat_dimention());
			} else {
				stat_dimention.add("无维度");
			}
			correct.add(entity.getCorrect_msg_cnt());
			amount.add(entity.getAmount());
			ratio.add(entity.getRatio());
		}
		jsonObject.put("enumMap", enumMap);
		jsonObject.put("amount", amount);
		jsonObject.put("correct", correct);
		jsonObject.put("ratio", ratio);
		jsonObject.put("stat_dimention", stat_dimention);
		result.setData(jsonObject);
		return result;
	}

	// 小时维度
	@Override
	public ResultEntity queryTimeDimension(Map map) {
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		JSONObject jsonObject = new JSONObject();
		List<String> amount = new ArrayList<String>();// 总数
		List<String> correct = new ArrayList<String>();// 正确数
		List<String> ratio = new ArrayList<String>();// 正确率
		List<String> hour_dimention = new ArrayList<String>();// X轴时间维度
		List<BaseTaskResult> list = qmBusinessDao.queryTimeDimension(map);
		for (BaseTaskResult entity : list) {
			correct.add(entity.getCorrect_msg_cnt());
			amount.add(entity.getAmount());
			ratio.add(entity.getRatio());
			hour_dimention.add(entity.getHour_dimention());
		}
		if (hour_dimention.size() != 0) {
			jsonObject.put("amount", amount);
			jsonObject.put("correct", correct);
			jsonObject.put("ratio", ratio);
			jsonObject.put("hour_dimention", hour_dimention);
		} else {
			jsonObject.put("amount", "0");
			jsonObject.put("correct", "0");
			jsonObject.put("ratio", "0");
			jsonObject.put("hour_dimention", "0");
		}
		result.setData(jsonObject);
		return result;
	}

	@Override
	public ResultEntity queryFieldStat(Map map) {
		// TODO Auto-generated method stub
		// 查看是否有统计维度
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		JSONObject obj = new JSONObject();
		Map infoMap = qmBusinessDao.querySchemaTaskDimention(map);
		List<Map> list = new ArrayList<Map>();
		String type = "0";// 是否有维度 0：没有维度，1：有维度
		Map[] enumMap = null;
		if (null != infoMap.get("STAT_DIMENTION")) {
			list = qmBusinessDao.queryDimFieldStat(map);
			type = "1";
			String[] dimentions = infoMap.get("STAT_DIMENTION").toString().split(",");
			enumMap = new HashMap[dimentions.length];
			enumMap = makeEnumMap(infoMap.get("SOURCE_ID").toString(), dimentions);
		} else {
			list = qmBusinessDao.queryFieldStat(map);
		}
		obj.put("type", type);
		JSONArray array = new JSONArray();
		for (Map temp : list) {
			JSONObject o = new JSONObject();
			if (type.equals("1")) {
				String[] stats = temp.get("STAT_DIMENTION").toString().split(",");
				StringBuffer statName = new StringBuffer();
				JSONObject[] jsonObject = new JSONObject[10];
				for (int i = 0; i < stats.length; i++) {
					if (i != stats.length - 1) {
						statName.append(enumMap[i].get(stats[i])).append(",");
					} else {
						statName.append(enumMap[i].get(stats[i]));
					}
				}

//				String[] statAll = temp.get("stat_dimention").toString().split(",");
//				StringBuffer statName_ = new StringBuffer();
//				
//				for(int j=0;j<statAll.length;j++) {
//					
//				}
//				
//				for (int j = 0;j<enumMap.length;j++) {
//					Set<Entry<String, String>> entrys = enumMap[j].entrySet();
//					for(Entry<String, String> entry:entrys){
//						
//						System.out.println("key值："+entry.getKey()+" value值："+entry.getValue());
//						}
//				}

//				List<Object> keyList = new ArrayList<>();
//			    for(Object key: map.keySet()){
//			        if(map.get(key).equals(value)){
//			            keyList.add(key);
//			        }
//			    }
//			    return keyList;

				o.put("stat_dimention", statName.toString());// 统计维度
				// o.put("stat_dimention", temp.get("STAT_DIMENTION").toString());// 统计维度
			}
			o.put("field_name", temp.get("FIELD_NAME"));// 字段
			o.put("rule_name", temp.get("RULE_NAME"));// 规则名称
			o.put("cnt", temp.get("CNT"));// 数值
			array.add(o);
		}
		obj.put("list", array);
		result.setData(obj);
		return result;
	}

	@Override
	public ResultEntity queryFieldAndRuleStat(Map map) {
		// TODO Auto-generated method stub
		// 查看是否有统计维度
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		JSONObject obj = new JSONObject();
		Map infoMap = qmBusinessDao.querySchemaTaskDimention(map);
		List<Map> list = new ArrayList<Map>();
		String type = "0";// 是否有维度 0：没有维度，1：有维度
		Map[] enumMap = null;
		if (null != infoMap.get("STAT_DIMENTION")) {
			// 按维度统计
			list = qmBusinessDao.queryDimFieldAndRuleStat(map);
			type = "1";
			String[] dimentions = infoMap.get("STAT_DIMENTION").toString().split(",");
			enumMap = new HashMap[dimentions.length];
			enumMap = makeEnumMap(infoMap.get("SOURCE_ID").toString(), dimentions);
		} else {
			list = qmBusinessDao.queryFieldAndRuleStat(map);
		}
		obj.put("type", type);
		JSONArray array = new JSONArray();
		for (Map temp : list) {
			JSONObject o = new JSONObject();
			if (type.equals("1")) {
				String[] stats = temp.get("STAT_DIMENTION").toString().split(",");
				StringBuffer statName = new StringBuffer();
				for (int i = 0; i < stats.length; i++) {
					if (i != stats.length - 1) {
						statName.append(enumMap[i].get(stats[i])).append(",");
					} else {
						statName.append(enumMap[i].get(stats[i]));
					}
				}
				o.put("stat_dimention", statName.toString());// 统计维度
				// o.put("stat_dimention", temp.get("STAT_DIMENTION").toString());// 统计维度
			}
			o.put("field_name", temp.get("FIELD_NAME"));// 字段
			o.put("rule_name", temp.get("RULE_NAME"));// 规则名称
			o.put("cnt", temp.get("CNT"));// 数值
			array.add(o);
		}
		obj.put("list", array);
		result.setData(obj);
		return result;
	}

	@Override
	public ResultEntity queryHourFieldStat(Map map) {
		// TODO Auto-generated method stub
		// 查看是否有统计维度
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		JSONObject obj = new JSONObject();
		Map infoMap = qmBusinessDao.querySchemaTaskDimention(map);
		List<Map> list = new ArrayList<Map>();
		String type = "0";// 是否有维度 0：没有维度，1：有维度
		Map[] enumMap = null;
		// if(null != infoMap.get("STAT_DIMENTION")){
		// 按维度统计
		list = qmBusinessDao.queryHourFieldStat(map);
		type = "1";
//			String []dimentions = infoMap.get("STAT_DIMENTION").toString().split(",");
//			enumMap = new HashMap[dimentions.length];
//			enumMap = makeEnumMap(infoMap.get("SOURCE_ID").toString(),dimentions);
		// }else{
		// list = qmBusinessDao.queryFieldStat(map);
		// }
		obj.put("type", type);
		JSONArray array = new JSONArray();
		for (Map temp : list) {
			JSONObject o = new JSONObject();
			if (type.equals("1")) {
//				String[] stats = temp.get("STAT_DIMENTION").toString().split(",");
//				StringBuffer statName = new StringBuffer();
//				for(int i=0;i<stats.length;i++){
//					if(i != stats.length-1){
//						statName.append(enumMap[i].get(stats[i])).append(",");
//					}else{
//						statName.append(enumMap[i].get(stats[i]));
//					}
//				}
//				o.put("stat_dimention", statName.toString());//统计维度
				o.put("hour_dimention", temp.get("HOUR_DIMENTION"));// 统计维度
			}
			o.put("field_name", temp.get("FIELD_NAME"));// 字段
			o.put("rule_name", temp.get("RULE_NAME"));// 规则名称
			o.put("cnt", temp.get("CNT"));// 数值
			array.add(o);
		}
		obj.put("list", array);
		result.setData(obj);
		return result;
	}

	@Override
	public ResultEntity queryHourFieldAndRuleStat(Map map) {
		// TODO Auto-generated method stub
		// 查看是否有统计维度
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		JSONObject obj = new JSONObject();
		Map infoMap = qmBusinessDao.querySchemaTaskDimention(map);
		List<Map> list = new ArrayList<Map>();
		String type = "0";// 是否有维度 0：没有维度，1：有维度
		Map[] enumMap = null;
		// if(null != infoMap.get("STAT_DIMENTION")){
		// 按维度统计
		list = qmBusinessDao.queryHourFieldAndRuleStat(map);
		type = "1";
//			String []dimentions = infoMap.get("STAT_DIMENTION").toString().split(",");
//			enumMap = new HashMap[dimentions.length];
//			enumMap = makeEnumMap(infoMap.get("SOURCE_ID").toString(),dimentions);
//		}else{
//			list = qmBusinessDao.queryFieldAndRuleStat(map);
//		}
		obj.put("type", type);
		JSONArray array = new JSONArray();
		for (Map temp : list) {
			JSONObject o = new JSONObject();
			if (type.equals("1")) {
				// String[] stats = temp.get("STAT_DIMENTION").toString().split(",");
				StringBuffer statName = new StringBuffer();
//				for(int i=0;i<stats.length;i++){
//					if(i != stats.length-1){
//						statName.append(enumMap[i].get(stats[i])).append(",");
//					}else{
//						statName.append(enumMap[i].get(stats[i]));
//					}
//				}
				o.put("hour_dimention", temp.get("HOUR_DIMENTION").toString());// 统计维度
			}
			o.put("field_name", temp.get("FIELD_NAME"));// 字段
			o.put("rule_name", temp.get("RULE_NAME"));// 规则名称
			o.put("cnt", temp.get("CNT"));// 数值
			array.add(o);
		}
		obj.put("list", array);
		result.setData(obj);
		return result;
	}

	@Override
	public ResultEntity queryNoFieldStat(Map map) {
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		List<Map> list = new ArrayList<Map>();
		JSONObject obj = new JSONObject();
		String type = "0";// 是否有维度 0：没有维度，1：有维度
		Map[] enumMap = null;
		list = qmBusinessDao.queryFieldStat(map);
		JSONArray array = new JSONArray();
		for (Map temp : list) {
			JSONObject o = new JSONObject();
			o.put("field_name", temp.get("FIELD_NAME"));// 字段
			o.put("rule_name", temp.get("RULE_NAME"));// 规则名称
			o.put("cnt", temp.get("CNT"));// 数值
			array.add(o);
		}
		obj.put("list", array);
		result.setData(obj);
		return result;
	}

	@Override
	public ResultEntity queryNoFieldAndRuleStat(Map map) {
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		JSONObject obj = new JSONObject();
		List<Map> list = new ArrayList<Map>();
		list = qmBusinessDao.queryFieldAndRuleStat(map);
		JSONArray array = new JSONArray();
		for (Map temp : list) {
			JSONObject o = new JSONObject();
			o.put("field_name", temp.get("FIELD_NAME"));// 字段
			o.put("rule_name", temp.get("RULE_NAME"));// 规则名称
			o.put("cnt", temp.get("CNT"));// 数值
			array.add(o);
		}
		obj.put("list", array);
		result.setData(obj);
		return result;
	}

}
