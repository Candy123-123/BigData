package com.neusoft.cpap.qm.config.jwt;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import com.neusoft.mid.msf.auth.common.constatns.CommonConstants;

import lombok.Data;
@Configuration
@Data
public class UserAuthConfig {
	@Value("${jwt.tokenHeader}")
    private String tokenHeader;
    private byte[] pubKeyByte;
	@Value("${jwt.tokenType}")
    private String tokenType;//token类型,jwt:原生jwt;midJwt:自研jwt(采用aes加密算法)
	@Value("${jwt.secret}")
    private String pubKey;

}

/*
 * package com.neusoft.mid.dataShare.config;
 * 
 * import org.springframework.beans.factory.annotation.Value; import
 * org.springframework.context.annotation.Configuration;
 * 
 * import javax.servlet.http.HttpServletRequest;
 * 
 *//**
	 * Created by ace on 2017/9/15.
	 *//*
		 * public class UserAuthConfig {
		 * 
		 * @Value("${auth.user.token-header}") private String tokenHeader;
		 * 
		 * private byte[] pubKeyByte;
		 * 
		 * public String getTokenHeader() { return tokenHeader; }
		 * 
		 * public void setTokenHeader(String tokenHeader) { this.tokenHeader =
		 * tokenHeader; }
		 * 
		 * public String getToken(HttpServletRequest request){ return
		 * request.getHeader(this.getTokenHeader()); }
		 * 
		 * public byte[] getPubKeyByte() { return pubKeyByte; }
		 * 
		 * public void setPubKeyByte(byte[] pubKeyByte) { this.pubKeyByte = pubKeyByte;
		 * } }
		 */