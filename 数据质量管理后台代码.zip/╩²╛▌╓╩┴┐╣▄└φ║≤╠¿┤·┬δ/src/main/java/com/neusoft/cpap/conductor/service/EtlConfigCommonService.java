package com.neusoft.cpap.conductor.service;

import com.neusoft.cpap.conductor.model.EtlNodeValue;
import com.neusoft.cpap.conductor.model.EtlProcess;
import com.neusoft.cpap.conductor.model.EtlProcessGroup;
import com.neusoft.cpap.conductor.model.EtlProcessGroupMap;
import com.neusoft.cpap.conductor.model.EtlProcessNode;
import com.neusoft.cpap.conductor.model.EtlSession;
import com.neusoft.cpap.conductor.model.EtlTimerJob;
import com.neusoft.cpap.conductor.model.EtlUserConfig;

public interface EtlConfigCommonService {
	
	// etl_process
	public int insertEtlProcess(EtlProcess etlProcess);

	// etl_process
	public int updateEtlProcess(EtlProcess etlProcess);
	
	// etl_process
	public int deleteEtlProcess(EtlProcess etlProcess);

	// etl_process_node
	public int insertEtlProcessNode(EtlProcessNode etlProcessNode);

	// etl_process_node
	public int updateEtlProcessNode(EtlProcessNode etlProcessNode);
	
	// etl_process_node
	public int deleteEtlProcessNode(EtlProcessNode etlProcessNode);

	// etl_node_value
	public int insertEtlNodeValue(EtlNodeValue etlNodeValue);

	// etl_node_value
	public int updateEtlNodeValue(EtlNodeValue etlNodeValue);
	
	// etl_node_value
	public int deleteEtlNodeValue(EtlNodeValue etlNodeValue);

	// etl_timer_job
	public int insertEtlTimerJob(EtlTimerJob etlTimerJob);

	// etl_timer_job
	public int updateEtlTimerJob(EtlTimerJob etlTimerJob);
	
	// etl_timer_job
	public int deleteEtlTimerJob(EtlTimerJob etlTimerJob);
	
	// etl_process_group_map
	public int insertEtlProcessGroupMap(EtlProcessGroupMap etlProcessGroupMap);

	// etl_process_group_map
	public int updateEtlProcessGroupMap(EtlProcessGroupMap etlProcessGroupMap);
	
	// etl_process_group_map
	public int deleteEtlProcessGroupMap(EtlProcessGroupMap etlProcessGroupMap);
	
	// etl_user_config
	public int insertEtlUserConfig(EtlUserConfig etlUserConfig);

	// etl_user_config
	public int updateEtlUserConfig(EtlUserConfig etlUserConfig);
	
	// etl_user_config
	public int deleteEtlUserConfig(EtlUserConfig etlUserConfig);
	
	// etl_session
	public int insertEtlSession(EtlSession etlSession);

	// etl_session
	public int updateEtlSession(EtlSession etlSession);
	
	// etl_process_group
	public int insertEtlProcessGroup(EtlProcessGroup etlProcessGroup);
	public int updateEtlProcessGroup(EtlProcessGroup etlProcessGroup);
}
