package com.neusoft.cpap.conductor.dao.mapper;

import com.neusoft.cpap.conductor.model.EtlProcess;

import tk.mybatis.mapper.common.BaseMapper;

public interface EtlProcessMapper extends BaseMapper<EtlProcess>{

}
