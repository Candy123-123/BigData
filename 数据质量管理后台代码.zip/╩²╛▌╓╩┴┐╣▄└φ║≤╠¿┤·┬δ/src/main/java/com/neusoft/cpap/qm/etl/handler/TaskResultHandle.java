package com.neusoft.cpap.qm.etl.handler;

import java.util.HashMap;
import java.util.Map;

import com.neusoft.cpap.qm.common.GlobalConstants;
import com.neusoft.cpap.qm.etl.EtlRequestParam;

public class TaskResultHandle extends BaseHandler{
	private String nodeType;
	@Override
	public void doExecute(EtlRequestParam etlParam, Map<String, Object> paramMap) {
		// TODO Auto-generated method stub
		etlParam.getNodeType().add(nodeType);
		Map<String,Object> ferryMap = new HashMap<String,Object>();
		ferryMap.put("oraTableName",GlobalConstants.oraResultTableName);
		ferryMap.put("columns",GlobalConstants.resultColumns);
		ferryMap.put("hiveTableName",GlobalConstants.hiveResultTableName);
		ferryMap.put("queueName",GlobalConstants.queueResultName);
		ferryMap.put("timeFormat",paramMap.get("ferryTimeFormat"));
		ferryMap.put("oraUrl",GlobalConstants.oraUrl);
		ferryMap.put("oraUser",GlobalConstants.oraUser);
		ferryMap.put("oraPassword",GlobalConstants.oraPassword);
		ferryMap.put("paralle",GlobalConstants.paralle);
		etlParam.getNodeValue().add(ferryMap);
	}

}
