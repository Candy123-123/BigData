package com.neusoft.cpap.conductor.dao.mapper;

import com.neusoft.cpap.conductor.model.EtlSession;

import tk.mybatis.mapper.common.BaseMapper;

public interface EtlSessionMapper extends BaseMapper<EtlSession>{

}
