package com.neusoft.cpap.conductor.entity;

import java.util.List;

import com.neusoft.cpap.conductor.model.EtlProcess;


public class EtlProcessPo extends BaseVo{


	private EtlProcess etlProcess;
	private List<EtlProcessNodePo> etlProcessNodeVoList;
	private EtlTimerJobPo etlTimerJobVo;
	private EtlProcessGroupMapPo etlProcessGroupMapPo;
	private EtlProcessGroups etlProcessGroups;
	
	public EtlProcess getEtlProcess() {
		return etlProcess;
	}
	public void setEtlProcess(EtlProcess etlProcess) {
		this.etlProcess = etlProcess;
	}
	public List<EtlProcessNodePo> getEtlProcessNodeVoList() {
		return etlProcessNodeVoList;
	}
	public void setEtlProcessNodeVoList(
			List<EtlProcessNodePo> etlProcessNodeVoList) {
		this.etlProcessNodeVoList = etlProcessNodeVoList;
	}
	public EtlTimerJobPo getEtlTimerJobVo() {
		return etlTimerJobVo;
	}
	public void setEtlTimerJobVo(EtlTimerJobPo etlTimerJobVo) {
		this.etlTimerJobVo = etlTimerJobVo;
	}

	public EtlProcessGroupMapPo getEtlProcessGroupMapPo() {
		return etlProcessGroupMapPo;
	}
	public void setEtlProcessGroupMapPo(EtlProcessGroupMapPo etlProcessGroupMapPo) {
		this.etlProcessGroupMapPo = etlProcessGroupMapPo;
	}
	public EtlProcessGroups getEtlProcessGroups() {
		return etlProcessGroups;
	}
	public void setEtlProcessGroups(EtlProcessGroups etlProcessGroups) {
		this.etlProcessGroups = etlProcessGroups;
	}
	@Override
	public String toString() {
		return "EtlProcessPo [etlProcess=" + etlProcess + ", etlProcessNodeVoList=" + etlProcessNodeVoList
				+ ", etlTimerJobVo=" + etlTimerJobVo + ", etlProcessGroupMapPo=" + etlProcessGroupMapPo
				+ ", etlProcessGroups=" + etlProcessGroups + "]";
	}
	
	
	
}
