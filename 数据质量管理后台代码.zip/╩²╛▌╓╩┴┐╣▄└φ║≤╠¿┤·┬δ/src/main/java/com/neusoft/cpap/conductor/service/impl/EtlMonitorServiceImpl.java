package com.neusoft.cpap.conductor.service.impl;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neusoft.cpap.conductor.common.Constants;
import com.neusoft.cpap.conductor.dao.EtlConfigDao;
import com.neusoft.cpap.conductor.model.EtlUserConfig;
import com.neusoft.cpap.conductor.service.EtlConfigCommonService;
import com.neusoft.cpap.conductor.service.EtlMonitorService;
import com.neusoft.cpap.conductor.util.CommandUtil;
//import com.neusoft.mid.msf.common.context.BaseContextHandler;


@Service
@Transactional
public class EtlMonitorServiceImpl implements EtlMonitorService {
	private static final Logger logger = LoggerFactory.getLogger(EtlMonitorServiceImpl.class);
	private static final String SERVICE_NAME = "etl.service.EtlMonitorServiceImpl";

	@Autowired
	private EtlConfigCommonService etlConfigCommonService;

	@Autowired
	private EtlConfigDao etlConfigdao;

	@Override
	public String getSparkLogUrl(String applicationId) throws Exception {
		String url="";
		//String ip=Constants.SPARK_HISTORY_IP;
		String username=/*BaseContextHandler.getUsername()*/null;

		//获取用户配置信息
		List<EtlUserConfig> etlUserConfigList=etlConfigdao.selectUserConfigByUser(username);
		Map<String, EtlUserConfig> etlUserConfigMap = etlUserConfigList.stream().collect(Collectors.toMap(EtlUserConfig::getKey, a -> a,(k1,k2)->k1));
		String ip=etlUserConfigMap.get("sparkHistoryIp").getValue();
		int port=Integer.parseInt(etlUserConfigMap.get("sparkHistoryPort").getValue());
		url=ip+":"+port+"/history/"+applicationId+"/1/jobs/";

		return url;
	}

	@Override
	public String getYarnLog(String applicationId) throws Exception {
		String result="";
		//获取用户配置信息
		List<EtlUserConfig> etlUserConfigList=etlConfigdao.selectUserConfigByUser(/*BaseContextHandler.getUsername()*/null);
		Map<String, EtlUserConfig> etlUserConfigMap = etlUserConfigList.stream().collect(Collectors.toMap(EtlUserConfig::getKey, a -> a,(k1,k2)->k1));
		String ip=etlUserConfigMap.get("hostname").getValue();
		Integer port=22;
		String username=etlUserConfigMap.get("username").getValue();
		String password=etlUserConfigMap.get("password").getValue();
		CommandUtil commandUtil = new CommandUtil(ip,
				port,username, password);
		String cmd="yarn logs --applicationId "+applicationId;
		logger.info("command:"+cmd);
		result=commandUtil.executeSuccess3(cmd, "");
		return result;
	}

	@Override
	public String getClientLog(Long oid) throws Exception {
		List<String> result=etlConfigdao.selectClientLog(oid);
		if(result==null||result.size()==0) {
			return "";
		}else {
			return result.get(0);
		}
	}
}
