package com.neusoft.cpap.qm.vo;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "QM_SAMPLE_RATIO_TAB")
public class QmSampleRatioTab {

	@Id
	private Long id;
	private Long source_id;
	private String name;
	private Integer ratio;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSource_id() {
		return source_id;
	}
	public void setSource_id(Long source_id) {
		this.source_id = source_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getRatio() {
		return ratio;
	}
	public void setRatio(Integer ratio) {
		this.ratio = ratio;
	}
	
}
