package com.neusoft.cpap.conductor.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.neusoft.cpap.conductor.dao.mapper.EtlNodeValueMapper;
import com.neusoft.cpap.conductor.dao.mapper.EtlProcessGroupMapMapper;
import com.neusoft.cpap.conductor.dao.mapper.EtlProcessGroupMapper;
import com.neusoft.cpap.conductor.dao.mapper.EtlProcessMapper;
import com.neusoft.cpap.conductor.dao.mapper.EtlProcessNodeMapper;
import com.neusoft.cpap.conductor.dao.mapper.EtlSessionMapper;
import com.neusoft.cpap.conductor.dao.mapper.EtlTimerJobMapper;
import com.neusoft.cpap.conductor.dao.mapper.EtlUserConfigMapper;
import com.neusoft.cpap.conductor.model.EtlNodeValue;
import com.neusoft.cpap.conductor.model.EtlProcess;
import com.neusoft.cpap.conductor.model.EtlProcessGroup;
import com.neusoft.cpap.conductor.model.EtlProcessGroupMap;
import com.neusoft.cpap.conductor.model.EtlProcessNode;
import com.neusoft.cpap.conductor.model.EtlSession;
import com.neusoft.cpap.conductor.model.EtlTimerJob;
import com.neusoft.cpap.conductor.model.EtlUserConfig;
import com.neusoft.cpap.conductor.service.EtlConfigCommonService;
import com.nokia.sai.micro.framework.util.IdUtil;

@Service
@Transactional
public class EtlConfigCommonServiceImpl implements EtlConfigCommonService{

	@Autowired
	private EtlProcessMapper etlProcessMapper;
	@Autowired
	private EtlProcessNodeMapper etlProcessNodeMapper;
	@Autowired
	private EtlNodeValueMapper etlNodeValueMapper;
	@Autowired
	private EtlTimerJobMapper etlTimerJobMapper;
	@Autowired
	private EtlProcessGroupMapMapper etlProcessGroupMapMapper;
	@Autowired
	private EtlUserConfigMapper etlUserConfigMapper;
	@Autowired
	private EtlSessionMapper etlSessionMapper;
	@Autowired
	private EtlProcessGroupMapper etlProcessGroupMapper;

	
	// etl_process
	public int insertEtlProcess(EtlProcess etlProcess){
		//etlProcess.setId(IdUtil.nextId());
		return etlProcessMapper.insertSelective(etlProcess);
	}

	// etl_process
	public int updateEtlProcess(EtlProcess etlProcess){
		return etlProcessMapper.updateByPrimaryKeySelective(etlProcess);
	}

	// etl_process_node
	public int insertEtlProcessNode(EtlProcessNode etlProcessNode){
		//etlProcessNode.setId(IdUtil.nextId());
		return etlProcessNodeMapper.insertSelective(etlProcessNode);
	}

	// etl_process_node
	public int updateEtlProcessNode(EtlProcessNode etlProcessNode){
		return etlProcessNodeMapper.updateByPrimaryKeySelective(etlProcessNode);
	}

	// etl_node_value
	public int insertEtlNodeValue(EtlNodeValue etlNodeValue){
		//etlNodeValue.setId(IdUtil.nextId());
		return etlNodeValueMapper.insertSelective(etlNodeValue);
	}

	// etl_node_value
	public int updateEtlNodeValue(EtlNodeValue etlNodeValue){
		return etlNodeValueMapper.updateByPrimaryKeySelective(etlNodeValue);
	}

	// etl_timer_job
	public int insertEtlTimerJob(EtlTimerJob etlTimerJob){
		//etlTimerJob.setId(IdUtil.nextId());
		return etlTimerJobMapper.insertSelective(etlTimerJob);
	}

	// etl_timer_job
	public int updateEtlTimerJob(EtlTimerJob etlTimerJob){
		return etlTimerJobMapper.updateByPrimaryKeySelective(etlTimerJob);
	}
	
	//etl_timer_job
	/*
	 * public int deleteEtlTimerJob(EtlTimerJob etlTimerJob) { return
	 * etlTimerJobMapper.delete(etlTimerJob); }
	 */
	public int deleteEtlTimerJob(EtlTimerJob etlTimerJob) {
		return etlTimerJobMapper.deleteByPrimaryKey(etlTimerJob);
	}
	
	@Override
	/*
	 * public int deleteEtlNodeValue(EtlNodeValue etlNodeValue) { return
	 * etlNodeValueMapper.delete(etlNodeValue); }
	 */
	public int deleteEtlNodeValue(EtlNodeValue etlNodeValue) {
		return etlNodeValueMapper.deleteByPrimaryKey(etlNodeValue);
	}

	@Override
	/*
	 * public int deleteEtlProcessNode(EtlProcessNode etlProcessNode) { return
	 * etlProcessNodeMapper.delete(etlProcessNode); }
	 */
	public int deleteEtlProcessNode(EtlProcessNode etlProcessNode) {
		return etlProcessNodeMapper.deleteByPrimaryKey(etlProcessNode);
	}

	@Override
	/*
	 * public int deleteEtlProcess(EtlProcess etlProcess) { return
	 * etlProcessMapper.delete(etlProcess); }
	 */
	public int deleteEtlProcess(EtlProcess etlProcess) {
		return etlProcessMapper.deleteByPrimaryKey(etlProcess);
	}

	// etl_process_group_map
	public int insertEtlProcessGroupMap(EtlProcessGroupMap etlProcessGroupMap) {
		return etlProcessGroupMapMapper.insertSelective(etlProcessGroupMap);
	}

	// etl_process_group_map
	public int updateEtlProcessGroupMap(EtlProcessGroupMap etlProcessGroupMap) {
		return etlProcessGroupMapMapper.updateByPrimaryKeySelective(etlProcessGroupMap);
	}

	// etl_process_group_map
	/*
	 * public int deleteEtlProcessGroupMap(EtlProcessGroupMap etlProcessGroupMap) {
	 * return etlProcessGroupMapMapper.delete(etlProcessGroupMap); }
	 */
	public int deleteEtlProcessGroupMap(EtlProcessGroupMap etlProcessGroupMap) {
		return etlProcessGroupMapMapper.deleteByPrimaryKey(etlProcessGroupMap);
	}

	@Override
	public int insertEtlUserConfig(EtlUserConfig etlUserConfig) {
		//etlUserConfig.setId(IdUtil.nextId());
		return etlUserConfigMapper.insertSelective(etlUserConfig);
	}

	@Override
	public int updateEtlUserConfig(EtlUserConfig etlUserConfig) {
		return etlUserConfigMapper.updateByPrimaryKeySelective(etlUserConfig);
	}

	@Override
	public int deleteEtlUserConfig(EtlUserConfig etlUserConfig) {
		return etlUserConfigMapper.deleteByPrimaryKey(etlUserConfig);
	}

	@Override
	public int insertEtlSession(EtlSession etlSession) {
		return etlSessionMapper.insertSelective(etlSession);
	}

	@Override
	public int updateEtlSession(EtlSession etlSession) {
		return etlSessionMapper.updateByPrimaryKeySelective(etlSession);
	}
	
	// etl_process_group
	public int insertEtlProcessGroup(EtlProcessGroup etlProcessGroup) {
		if(etlProcessGroup.getId()==null) {
			etlProcessGroup.setId(IdUtil.nextId());
		}
		
		return etlProcessGroupMapper.insertSelective(etlProcessGroup);
	}

	// etl_process_group
	public int updateEtlProcessGroup(EtlProcessGroup etlProcessGroup) {
		return etlProcessGroupMapper.updateByPrimaryKeySelective(etlProcessGroup);
	}

}
