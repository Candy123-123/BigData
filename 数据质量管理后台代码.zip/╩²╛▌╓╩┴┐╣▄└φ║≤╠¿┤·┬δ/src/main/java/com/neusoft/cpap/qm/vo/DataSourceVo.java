package com.neusoft.cpap.qm.vo;

import lombok.Data;

@Data
public class DataSourceVo {
	private String id;//数据源ID
	private String name;//数据源名称
	private String desc_info;//数据源描述
	private String code;//code值
	private Integer type;//类型
	private String partitiontimeformate;//partitiontimeformate
	private String partitionfield;//partitionfield
}
