package com.neusoft.cpap.qm.config.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import com.neusoft.mid.msf.auth.common.constatns.CommonConstants;
import com.neusoft.mid.msf.auth.common.util.jwt.AesJwtHelper;
import com.neusoft.mid.msf.auth.common.util.jwt.IJWTInfo;
import com.neusoft.mid.msf.auth.common.util.jwt.JWTHelper;

/**
 * Created by ace on 2017/9/15.
 */
@Configuration
public class UserAuthUtil {
    @Autowired
    private UserAuthConfig userAuthConfig;

    public IJWTInfo getInfoFromToken(String token) throws Exception {
        IJWTInfo jwtInfo = null;
        if (CommonConstants.TOKEN_TYPE_JWT.equalsIgnoreCase(userAuthConfig.getTokenType())) {
            jwtInfo = JWTHelper.getInfoFromToken(token, userAuthConfig.getPubKeyByte());
        } else if (CommonConstants.TOKEN_TYPE_MID_JWT.equalsIgnoreCase(userAuthConfig.getTokenType())) {
            jwtInfo = AesJwtHelper.getInfoFromToken(token, userAuthConfig.getPubKey());
        }
        return jwtInfo;
    }
}

