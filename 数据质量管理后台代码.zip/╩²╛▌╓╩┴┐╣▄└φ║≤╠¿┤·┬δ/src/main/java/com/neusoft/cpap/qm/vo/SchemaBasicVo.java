package com.neusoft.cpap.qm.vo;

import java.util.List;

import lombok.Data;

import com.alibaba.fastjson.JSONArray;

/**
 * 评估方案基础信息表
 * @author tengh
 *
 */
@Data
public class SchemaBasicVo {
	private String id;//方案ID
	private String name;//名称
	private String descInfo;//描述
	private String dataSource;//数据源id
	private String dataSourceName;//数据源名称
	private String error_key_field;//错误关键字段
	private String status;//最新状态0：未执行，1：执行中，2：执行成功，3：执行失败，4：暂停，5：启动
	private String unit;//执行周期：F：15分钟，H：小时，D:天 ，M：月
	private String groupId;//属于哪个分组
	private JSONArray filterCondition;//筛选条件，多个条件,分隔
	private String statistical;//统计维度，多个条件,分隔
	private String statisticalName;
	private String search_condition;
	private String stat_dimention;
	private List<FieldRuleVo> validationRules;//字段级规则
	private List<FieldRuleVo> tableRules;//表级规则
	private String timesamp;//时间
}
