package com.neusoft.cpap.qm.dao.mapper;

import java.util.List;

import com.neusoft.cpap.qm.vo.QmSampleRatioTab;
import com.nokia.sai.micro.framework.dao.mapper.BaseMapper;

public interface SampleRatioMapper extends BaseMapper<QmSampleRatioTab>{

}
