package com.neusoft.cpap.conductor.config.interceptor;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.neusoft.cpap.conductor.config.jwt.UserAuthConfig;
import com.neusoft.cpap.conductor.config.jwt.UserAuthUtil;
import com.neusoft.mid.msf.auth.client.annotation.IgnoreUserToken;
import com.neusoft.mid.msf.auth.common.util.jwt.IJWTInfo;
import com.neusoft.mid.msf.common.context.BaseContextHandler;

import io.jsonwebtoken.SignatureException;

/**
 * Created by ace on 2017/9/10.
 */
public class UserAuthRestInterceptor extends HandlerInterceptorAdapter {
	private Logger logger = LoggerFactory.getLogger(UserAuthRestInterceptor.class);

	@Autowired
	private UserAuthUtil userAuthUtil;

	@Autowired
	private UserAuthConfig userAuthConfig;

	/*
	 * @Autowired private EtlConfigDao etlConfigDao;
	 * 
	 * @Autowired private EtlConfigCommonService etlConfigCommonService;
	 */

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		if (handler instanceof HandlerMethod) {
			HandlerMethod handlerMethod = (HandlerMethod) handler;
			// 配置该注解，说明不进行用户拦截
			IgnoreUserToken annotation = handlerMethod.getBeanType().getAnnotation(IgnoreUserToken.class);
			if (annotation == null) {
				annotation = handlerMethod.getMethodAnnotation(IgnoreUserToken.class);
			}
			if (annotation != null) {
				return super.preHandle(request, response, handler);
			}
			String token = request.getHeader(userAuthConfig.getTokenHeader());
			logger.debug(token);
			/*
			 * if (StringUtils.isEmpty(token)) { if (request.getCookies() != null) { for
			 * (Cookie cookie : request.getCookies()) { if
			 * (cookie.getName().equals(userAuthConfig.getTokenHeader())) { token =
			 * cookie.getValue(); } } } }
			 */
			try {
				IJWTInfo infoFromToken = userAuthUtil.getInfoFromToken(token);
				BaseContextHandler.setUsername(infoFromToken.getUniqueName());
				BaseContextHandler.setName(infoFromToken.getName());
				BaseContextHandler.setUserID(infoFromToken.getId());
			} catch (SignatureException e) {
				logger.error(e.getMessage(), e);
				response.setHeader("error", "parse token error");
				return false;
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				response.setHeader("error", "others");
				return false;
			}

			/*
			 * //自定义会话处理 List<EtlSession> etlSessionList
			 * =etlConfigDao.selectEtlSession(token); //查看和上次访问时间间隔是否超时
			 * if(etlSessionList!=null&&etlSessionList.size()>0) { EtlSession
			 * etlSession=etlSessionList.get(0); Date
			 * lastVisitTime=etlSession.getUpdateTime(); Date nowTime=new Date();
			 * if((nowTime.getTime()-lastVisitTime.getTime())>Constants.TIMEOUT) {
			 * response.setHeader("error", "sessionTimeout"); ResultEntity resultEntity=new
			 * ResultEntity(); returnJson(response,JSON.toJSONString(resultEntity)); return
			 * false; }else { etlSession.setUpdateTime(nowTime);
			 * etlConfigCommonService.updateEtlSession(etlSession); }
			 * 
			 * }//第一次访问 else { EtlSession etlSession =new EtlSession();
			 * etlSession.setToken(token); Date date=new Date();
			 * etlSession.setCreateTime(date); etlSession.setUpdateTime(date);
			 * etlConfigCommonService.insertEtlSession(etlSession); }
			 */
			return super.preHandle(request, response, handler);
		} else {
			return super.preHandle(request, response, handler);
		}
	}

	private void returnJson(HttpServletResponse response, String json) throws Exception {
		PrintWriter writer = null;
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=utf-8");
		try {
			writer = response.getWriter();
			writer.print(json);

		} catch (IOException e) {
			logger.error("response error", e);
		} finally {
			if (writer != null)
				writer.close();
		}
	}

}
