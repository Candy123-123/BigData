package com.neusoft.cpap.conductor.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageInfo;
import com.neusoft.cpap.conductor.entity.EtlProcessNodeExecPo;
import com.neusoft.cpap.conductor.entity.EtlProcessPo;
import com.neusoft.cpap.conductor.entity.vo.EtlOptionVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessExecVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessListVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessVo;
import com.neusoft.cpap.conductor.model.EtlUserConfig;
import com.neusoft.cpap.conductor.service.ConvertService;
import com.neusoft.cpap.conductor.service.EtlConfigService;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;
//@CrossOrigin(allowCredentials = "true", allowedHeaders = "*")
@RestController
@RequestMapping("/config")
public class EtlConfigController {
	private static final Logger logger = LoggerFactory.getLogger(EtlConfigController.class);
	private static final String SERVICE_NAME = "etl.controller.EtlConfigController";
	/*
	 * @Autowired private UserAuthUtil userAuthUtil;
	 * 
	 * @Autowired private UserAuthConfig userAuthConfig;
	 */
	@Autowired
	private EtlConfigService etlConfigservice;
	@Autowired
	private ConvertService convertService;
	@RequestMapping("/test")
	public String test() {
		return "test";
	}
	//会话超时测试
	@RequestMapping(value = "/sessionTest")
	//@IgnoreUserToken
	public void sessionTest(HttpServletResponse response)throws Exception{
		logger.info("RestService was called [" + SERVICE_NAME+ ".sessionTest");	
		//response.sendRedirect("https://10.10.105.43:8888/cpap-web/do.action");
		response.addHeader("REDIRECT", "REDIRECT");//重定向标识
        response.addHeader("CONTEXTPATH", "https://10.10.105.43:8888/cpap-web/do.action");//重定向地址 
	}
	//查询流程列表
	@RequestMapping(value = "/queryEtlProcessVoList")
	//@IgnoreUserToken
	public ResultEntity<PageInfo<EtlProcessListVo>> queryEtlProcessVoList(HttpServletRequest request,@RequestBody Map map)throws Exception{
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryEtlProcessVoList],map = "+JSON.toJSONString(map));	
		/*
		 * IJWTInfo infoFromToken=null; String token=null; token =
		 * request.getHeader(userAuthConfig.getTokenHeader()); infoFromToken =
		 * userAuthUtil.getInfoFromToken(token);
		 */
		return new ResultEntity<PageInfo<EtlProcessListVo>>(etlConfigservice.queryEtlProcessVoList(map)); 
	}
	//查询流程执行列表
	@RequestMapping(value = "/queryEtlProcessExecList")
	public ResultEntity<PageInfo<EtlProcessExecVo>> queryEtlProcessExecList(@RequestBody Map map)throws Exception{
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryEtlProcessExecList],map = "+JSON.toJSONString(map));
		return new ResultEntity<PageInfo<EtlProcessExecVo>>(etlConfigservice.queryEtlProcessExecList(map)); 
	}
	//查看调度详情
	@RequestMapping(value = "/queryEtlProcessNodeExecList")
	public ResultEntity<PageInfo<EtlProcessNodeExecPo>> queryEtlProcessNodeExecList(@RequestBody Map map)throws Exception{
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryEtlProcessExecList],map = "+JSON.toJSONString(map));
		return new ResultEntity<PageInfo<EtlProcessNodeExecPo>>(etlConfigservice.queryEtlProcessNodeExecList(map)); 
	}
	//查询etl流程
	@RequestMapping(value = "/queryEtlProcessVo")
	public ResultEntity<EtlProcessVo> queryEtlProcessVo(@RequestBody Map map)throws Exception{
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryEtlProcessVo],map = "+JSON.toJSONString(map));
		String processId=(String)map.get("processId");
		ResultEntity result=new ResultEntity();
		result.setStatus(true);
		try {
			EtlProcessPo etlProcessPo=etlConfigservice.queryEtlProcessVo(Long.valueOf(processId));
			EtlProcessVo etlProcessVo=convertService.convertPo2Vo(etlProcessPo);
			result.setData(etlProcessVo);
		}catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception(processId+"查询失败"));
			throw e;
		}
		
		System.out.println("查询流程："+result.getData());
		
		return result; 
	}
		
	//保存etl流程（包括新增和修改）
	@RequestMapping(value = "/saveEtlProcessVo")
	public ResultEntity saveEtlProcessVo(@RequestBody EtlProcessVo etlProcessVo) throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".saveEtlProcessVo],etlProcessVo = "+JSON.toJSONString(etlProcessVo));	
		ResultEntity saveResult=etlConfigservice.saveEtlProcessPo(convertService.convertVo2Po(etlProcessVo));
		if(saveResult.getStatus()) {
			EtlProcessPo etlProcessPo=etlConfigservice.queryEtlProcessVo(Long.valueOf(saveResult.getData().toString()));
			saveResult.setData(convertService.convertPo2Vo(etlProcessPo));
		}
		return saveResult;
	}
	
	//删除etl流程
	@RequestMapping(value = "/delEtlProcessVo")
	public ResultEntity delEtlProcessVo(@RequestBody Map map) throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".delEtlProcessVo],etlProcessIdList = "+JSON.toJSONString(map));	
		ResultEntity resultEntity=new ResultEntity();
		resultEntity.setStatus(true);
		List<String> etlProcessIdList=(List<String>)map.get("processId");
		for(String etlProcessId:etlProcessIdList) {
			try {
				etlConfigservice.delEtlProcessVo(etlConfigservice.queryEtlProcessVo(Long.valueOf(etlProcessId)));
			}catch(Exception e) {
				resultEntity.setStatus(false);
				resultEntity.setException(new Exception(etlProcessId+"删除失败"));;
				throw e;
			}
			
		}
		return resultEntity;  
	}
	//解锁流程
	@RequestMapping(value = "/unlockEtlProcess")
	public ResultEntity unlockEtlProcess(@RequestBody Map map) throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".unlockEtlProcess],map = "+JSON.toJSONString(map));	
		String etlProcessId=(String)map.get("processId");
		return etlConfigservice.unlockEtlProcess(Long.valueOf(etlProcessId));  
	}
	//开启流程
	@RequestMapping(value = "/enableEtlProcess")
	public ResultEntity enableEtlProcess(@RequestBody Map map) throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".enableEtlProcess],map = "+JSON.toJSONString(map));
		String etlProcessId=(String)map.get("processId");
		return etlConfigservice.setEtlProcessStatus(Long.valueOf(etlProcessId),"1");  
	}
	//禁用流程
	@RequestMapping(value = "/disableEtlProcess")
	public ResultEntity disableEtlProcess(@RequestBody Map map) throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".disableEtlProcess],map = "+JSON.toJSONString(map));
		String etlProcessId=(String)map.get("processId");
		return etlConfigservice.setEtlProcessStatus(Long.valueOf(etlProcessId),"0");  
	}
	//查询所有选项
	@RequestMapping(value = "/queryAllOptions")
	public ResultEntity<EtlOptionVo> queryAllOptions() throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryAllOptions]");
		return new ResultEntity<EtlOptionVo>(etlConfigservice.queryAllOptions());  
	}
	//查询二级分组选项
	@RequestMapping(value = "/querySecondaryGroup")
	public ResultEntity<List<Map>> querySecondaryGroup(@RequestBody Map map) throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySecondaryGroup],primaryCode = "+map);
		return new ResultEntity<List<Map>>(etlConfigservice.querySecondaryGroup(map.get("primaryCode").toString()));  
	}
	//选择依赖流程
	/*
	 * @RequestMapping(value = "/queryEtlProcessDepend")
	 * 
	 * @CrossOrigin(allowCredentials = "true", allowedHeaders = "*") public
	 * ResultEntity<Map> queryEtlProcessDepend(@RequestBody Long etlProcessId)
	 * throws Exception { logger.info("RestService was called [" + SERVICE_NAME+
	 * ".queryEtlProcessDepend],etlProcessId = "+JSON.toJSONString(etlProcessId));
	 * return new
	 * ResultEntity<Map>(etlConfigservice.queryEtlProcessDepend(etlProcessId)); }
	 */
	//选择互斥流程
	/*
	 * @RequestMapping(value = "/queryEtlProcessExclusion")
	 * 
	 * @CrossOrigin(allowCredentials = "true", allowedHeaders = "*") public
	 * ResultEntity<Map> queryEtlProcessExclusion(@RequestBody Long etlProcessId)
	 * throws Exception { logger.info("RestService was called [" + SERVICE_NAME+
	 * ".queryEtlProcessExclusion],etlProcessId = "+JSON.toJSONString(etlProcessId))
	 * ; return new
	 * ResultEntity<Map>(etlConfigservice.queryEtlProcessExclusion(etlProcessId)); }
	 */
	//程序包上传
	/*
	 * @RequestMapping("/upload")
	 * 
	 * @CrossOrigin(allowCredentials = "true", allowedHeaders = "*") public
	 * ResultEntity upload(@RequestParam("file") MultipartFile file) throws
	 * Exception { logger.info("RestService was called [" + SERVICE_NAME+
	 * ".upload],file = "+file.getName()); return etlConfigservice.upload(file); }
	 */
	//选择用户
	/*
	 * @RequestMapping(value = "/queryUserOption")
	 * 
	 * @CrossOrigin(allowCredentials = "true", allowedHeaders = "*") public
	 * ResultEntity<List<Map>> queryUserOption() throws Exception {
	 * logger.info("RestService was called [" + SERVICE_NAME+ ".queryUserOption]");
	 * return new ResultEntity<List<Map>>(etlConfigservice.queryUserOption()); }
	 */
	
	//查询用户参数配置
	@RequestMapping(value = "/queryEtlUserConfig")
	public ResultEntity<List<EtlUserConfig>> queryEtlUserConfig() throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryEtlUserConfig");
		//String user=(String)map.get("user");
		return new ResultEntity<List<EtlUserConfig>>(etlConfigservice.queryEtlUserConfig());  
	}
	//删除用户参数配置
	@RequestMapping(value = "/delEtlUserConfig")
	public ResultEntity delEtlUserConfig(@RequestBody Map map) throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".delEtlUserConfig],map = "+JSON.toJSONString(map));
		ResultEntity resultEntity=new ResultEntity();
		resultEntity.setStatus(true);
		List<String> idList=(List<String>)map.get("id");
		for(String id:idList) {
			try {
				etlConfigservice.delEtlUserConfig(Long.valueOf(id));
			}catch(Exception e) {
				resultEntity.setStatus(false);
				resultEntity.setException(new Exception(id+"删除失败"));;
				throw e;
			}
			
		}
		return resultEntity;  
	}
	//保存用户参数配置
	@RequestMapping(value = "/saveEtlUserConfig")
	public ResultEntity saveEtlUserConfig(@RequestBody EtlUserConfig etlUserConfig) throws Exception {
		logger.info("RestService was called [" + SERVICE_NAME+ ".saveEtlUserConfig],etlUserConfig = "+JSON.toJSONString(etlUserConfig));	
		return new ResultEntity(etlConfigservice.saveEtlUserConfig(etlUserConfig));
	}
	
}
