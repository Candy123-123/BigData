package com.neusoft.cpap.conductor.common;

public enum ActionEnum {
	update(0),
	add(1),
	del(2),
	none(3);
	
	public  int type;
	
	private ActionEnum(int type){
		this.type =type;
	}

}
