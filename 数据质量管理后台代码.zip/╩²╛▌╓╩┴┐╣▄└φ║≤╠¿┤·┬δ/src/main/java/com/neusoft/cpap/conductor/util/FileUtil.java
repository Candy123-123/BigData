package com.neusoft.cpap.conductor.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.nokia.sai.micro.framework.exception.AppException;

public class FileUtil {
	private static final Logger logger = LoggerFactory.getLogger(FileUtil.class);
	/**
	 * 
	 * @return
	 */
	public static String getAppDirectory() {
		File f = new File(".");
		String path = f.getAbsolutePath();
		// logger.debug("path = "+path);
		return path.substring(0, path.length() - 1);
	}

	static public void deletePath(String path) throws AppException, FileNotFoundException {
		File item = new File(path);
		if (item.exists() && item.isDirectory()) {// 判断是文件还是目录
			if (item.listFiles().length == 0) {// 若目录下没有文件则直接删除
				item.delete();
			} else {// 若有则把文件放进数组，并判断是否有下级目录
				File delFile[] = item.listFiles();
				int i = item.listFiles().length;
				for (int j = 0; j < i; j++) {
					if (delFile[j].isDirectory()) {
						deletePath(delFile[j].getAbsolutePath());// 递归调用del方法并取得子目录路径
					}
					delFile[j].delete();// 删除文件
				}
				item.delete();//最后删除目录，后添加
			}
		}else {
			throw new FileNotFoundException(path);
		}
	}

	/**
	 * 
	 * @return
	 */
	public static String getClasspath() {
		String path = FileUtil.class.getResource("/").getPath();
		// logger.debug("path = "+path);
		return path;
	}

	/**
	 * 
	 * @param file
	 * @return
	 */
	public static ByteBuffer readFile(File file) throws Exception {
		ByteBuffer mBuf = null;
		FileChannel fiChannel = null;
		try {
			fiChannel = new FileInputStream(file).getChannel();
			mBuf = ByteBuffer.allocate((int) fiChannel.size());
			fiChannel.read(mBuf);
			mBuf.flip();
		} catch (Exception e) {
			new Exception("readFile:" + file + " fail:", e);
		} finally {
			if (file != null) {
				file = null;
			}
			if (fiChannel != null) {
				fiChannel.close();
				fiChannel = null;
			}
		}
		return mBuf;
	}

	/**
	 * 
	 * @param src
	 * @param filename
	 * @throws Exception
	 */
	public static void saveFile(ByteBuffer src, File file) throws Exception {
		FileChannel foChannel = null;
		try {
			foChannel = new FileOutputStream(file).getChannel();
			foChannel.write(src);
			// foChannel.close();
			// foChannel = null;
		} catch (Exception e) {
			throw new Exception("saveFile:" + file + " fail", e);
		} finally {
			if (src != null) {
				src.clear();
				src = null;
			}
			if (foChannel != null) {
				foChannel.close();
				foChannel = null;
			}
		}
	}

	/**
	 * 
	 * @param src
	 * @param filename
	 * @throws Exception
	 */
	public static void saveFile(ByteBuffer src, String filename)
			throws Exception {
		FileChannel foChannel = null;
		try {
			foChannel = new FileOutputStream(filename).getChannel();
			foChannel.write(src);
			// foChannel.close();
			// foChannel = null;
		} catch (Exception e) {
			throw new Exception("", e);
		} finally {
			if (src != null) {
				src.clear();
				src = null;
			}
			if (foChannel != null) {
				foChannel.close();
				foChannel = null;
			}
		}
	}

	static public File createPathByCheck(String path) throws AppException {
		path = formatPath(path);
		File res = new File(path);
		if (!res.exists()) {
			try {
				res.mkdirs();
				logger.info("=== create path:" + path);
			} catch (Exception e) {
				throw new AppException("Can't not create path:" + path, e);
			}
		} else if (!res.isDirectory()) {
			throw new AppException("Is not file path:" + path);
		}

		return res;
	}

	static public String formatPath(String path) throws AppException {
		if (path == null) {
			throw new AppException("formatPath path is null!!!");
		}
		if (!path.endsWith("/")) {
			path = path + "/";
		}
		return path;
	}

	public static ByteBuffer getByteBuffer(String str) {

		return ByteBuffer.wrap(str.getBytes());

	}

	public static String getString(ByteBuffer buffer) throws AppException {

		Charset charset = null;

		CharsetDecoder decoder = null;

		CharBuffer charBuffer = null;
		String result = null;
		try {

			charset = Charset.forName("UTF-8");
			decoder = charset.newDecoder();

			// 用这个的话，只能输出来一次结果，第二次显示为空

			// charBuffer = decoder.decode(buffer);

			charBuffer = decoder.decode(buffer.asReadOnlyBuffer());

			result = charBuffer.toString();

		} catch (Exception e) {

			throw new AppException("bytebuffer to string error:", e);

		}
		return result;
	}

	/**
	 * 复制整个文件夹内容
	 * 
	 * @param oldPath
	 *            String 原文件路径
	 * @param newPath
	 *            String 复制后路径
	 * @throws AppException
	 */
	public static void copyFolder(String oldPath, String newPath)
			throws AppException {

		try {
			(new File(newPath)).mkdirs(); // 如果文件夹不存在 则建立新文件夹
			File a = new File(oldPath);
			String[] file = a.list();
			File temp = null;
			for (int i = 0; i < file.length; i++) {
				if (oldPath.endsWith(File.separator)) {
					temp = new File(oldPath + file[i]);
				} else {
					temp = new File(oldPath + File.separator + file[i]);
				}

				if (temp.isFile()) {
					FileInputStream input = new FileInputStream(temp);
					FileOutputStream output = new FileOutputStream(newPath
							+ "/" + (temp.getName()).toString());
					byte[] b = new byte[1024 * 5];
					int len;
					while ((len = input.read(b)) != -1) {
						output.write(b, 0, len);
					}
					output.flush();
					output.close();
					input.close();
				}
				if (temp.isDirectory()) {// 如果是子文件夹
					copyFolder(oldPath + "/" + file[i], newPath + "/" + file[i]);
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
			throw new AppException("copyFolder fail :", e);
		}

	}
	

	public static Date getDiffDate(Date date,String sliceType,int diff){
		Date resDate=new Date();
		long l=date.getTime();
		if(sliceType=="H"){
			l=l+diff*60*60*1000;
		}
		resDate.setTime(l);
		return resDate;
	}
	/**
	  * 判断目录是否存在
	  * zhangym
	  */
	public static Boolean isDirExist(String path){
		File file = new File(path);
		 if(!file.exists() && !file.isDirectory()){
			 return false;
		 }else{
			 return true;
		 }
	}
	
	public static File multipartFileToFile(MultipartFile file) throws Exception {
		 
        File toFile = null;
        if (file.equals("") || file.getSize() <= 0) {
            file = null;
        } else {
            InputStream ins = null;
            ins = file.getInputStream();
            toFile = new File(file.getOriginalFilename());
            inputStreamToFile(ins, toFile);
            ins.close();
        }
        return toFile;
    }
 
    //获取流文件
    private static void inputStreamToFile(InputStream ins, File file) {
        try {
            OutputStream os = new FileOutputStream(file);
            int bytesRead = 0;
            byte[] buffer = new byte[8192];
            while ((bytesRead = ins.read(buffer, 0, 8192)) != -1) {
                os.write(buffer, 0, bytesRead);
            }
            os.close();
            ins.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 
    /**
     * 删除本地临时文件
     * @param file
     */
    public static void delteTempFile(File file) {
	    if (file != null) {
	        File del = new File(file.toURI());
	        del.delete();
	    }
    }
}
