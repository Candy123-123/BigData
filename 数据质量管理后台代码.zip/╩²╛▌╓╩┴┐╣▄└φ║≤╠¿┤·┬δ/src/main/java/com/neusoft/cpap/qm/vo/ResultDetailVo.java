package com.neusoft.cpap.qm.vo;

import lombok.Data;

/**
 * 评估结果详情
 * @author tengh
 *
 */
@Data
public class ResultDetailVo {
	private String task_id;//任务ID
	private String rule_type;//规则类型：1标准规则、2基础规则、3表级规则
	private String rule_id;//规则ID
	private String error_info;//错误信息
	private String error_sample;//错误实例
	private String timestamp;//时间戳
	private String result ;//执行结果0：正确  1：错误
	private String msg_idx;//消息ID
}
