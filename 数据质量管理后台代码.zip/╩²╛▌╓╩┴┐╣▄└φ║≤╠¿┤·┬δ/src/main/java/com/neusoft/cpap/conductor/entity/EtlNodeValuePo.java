package com.neusoft.cpap.conductor.entity;

import com.neusoft.cpap.conductor.model.EtlNodeValue;

public class EtlNodeValuePo extends BaseVo{

	private EtlNodeValue etlNodeValue;

	public EtlNodeValue getEtlNodeValue() {
		return etlNodeValue;
	}

	public void setEtlNodeValue(EtlNodeValue etlNodeValue) {
		this.etlNodeValue = etlNodeValue;
	}

	@Override
	public String toString() {
		return "EtlNodeValueVo [etlNodeValue=" + etlNodeValue + "]";
	}
	
}
