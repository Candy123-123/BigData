package com.neusoft.cpap.conductor.entity;

import java.util.List;

import com.neusoft.cpap.conductor.model.EtlProcess;
import com.neusoft.cpap.conductor.model.EtlProcessNode;

public class EtlProcessAndNodePo {
	private EtlProcess etlProcess;
	private List<EtlProcessNode> etlProcessNode;
	public EtlProcess getEtlProcess() {
		return etlProcess;
	}
	public void setEtlProcess(EtlProcess etlProcess) {
		this.etlProcess = etlProcess;
	}
	public List<EtlProcessNode> getEtlProcessNode() {
		return etlProcessNode;
	}
	public void setEtlProcessNode(List<EtlProcessNode> etlProcessNode) {
		this.etlProcessNode = etlProcessNode;
	}
}
