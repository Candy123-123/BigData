package com.neusoft.cpap.qm.etl.handler;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.neusoft.cpap.qm.etl.EtlRequestParam;

@Component
public interface Handler {
	
	Handler setNextHandler(Handler  handler);
	
	void execute(EtlRequestParam etlParam,Map<String,Object> paramMap);

}
