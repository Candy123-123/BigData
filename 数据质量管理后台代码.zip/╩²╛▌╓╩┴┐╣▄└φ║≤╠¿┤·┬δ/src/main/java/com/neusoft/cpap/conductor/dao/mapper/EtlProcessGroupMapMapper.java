package com.neusoft.cpap.conductor.dao.mapper;

import com.neusoft.cpap.conductor.model.EtlProcessGroupMap;

import tk.mybatis.mapper.common.BaseMapper;

public interface EtlProcessGroupMapMapper extends BaseMapper<EtlProcessGroupMap>{

}
