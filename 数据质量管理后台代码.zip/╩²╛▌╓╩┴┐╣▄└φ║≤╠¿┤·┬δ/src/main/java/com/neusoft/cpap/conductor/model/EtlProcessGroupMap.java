package com.neusoft.cpap.conductor.model;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="ETL_PROCESS_GROUP_MAP")
public class EtlProcessGroupMap {
    @Id
	private Long id;
    private Long groupId;
	private Long processId;
	private Integer type;
	private Integer status;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public Long getProcessId() {
		return processId;
	}
	public void setProcessId(Long processId) {
		this.processId = processId;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	
	
}
