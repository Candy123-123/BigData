package com.neusoft.cpap.qm.vo;

import lombok.Data;

/**
 * 评估方案任务表
 * @author tengh
 *
 */
@Data
public class SchemaTaskVo {
	private String schema_id;//方案ID
	private String task_id;//任务ID
	private String task_name;//名称
	private String create_time;//任务执行开始时间
	private String finish_time;//任务结束时间
	private String score;//评估分数
	private String correct_msg_cnt;//正确消息条数
	private String error_msg_cnt;//错误消息条数
	private String msg_total_cnt;//消息总条数
	private String correct_cnt;//正确规则数
	private String error_cnt;//错误规则数
	private String stat_demantion;//统计维度
	private String stat_value;//统计值
	private String result_info;//评估结果信息
	private String unit;
	private String unit_desc;//执行粒度
	private String time_consume;//耗时
	
	private String name;//方案名称
	private String status;//任务状态
	private String ratio;//正确率
	private String slice_time;//时间片主键
	
}
