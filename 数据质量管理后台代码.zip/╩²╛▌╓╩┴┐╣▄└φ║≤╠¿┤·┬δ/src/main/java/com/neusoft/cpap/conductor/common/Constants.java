package com.neusoft.cpap.conductor.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Constants {
	public static boolean IS_REAL_DEL;
	public static String FB_REST_URL;
	public static String SPARK_HOME;
	public static Long TIMEOUT;

	@Value("${conductor.isRealDel}")
	public void setIS_REAL_DEL(boolean iS_REAL_DEL) {
		IS_REAL_DEL = iS_REAL_DEL;
	}
	@Value("${conductor.fbRestUrl}")
	public void setFB_REST_URL(String fB_REST_URL) {
		FB_REST_URL = fB_REST_URL;
	}
	@Value("${conductor.sparkHome}")
	public void setSPARK_HOME(String sPARK_HOME) {
		SPARK_HOME = sPARK_HOME;
	}
	@Value("${conductor.timeout}")
	public void setTIMEOUT(Long tIMEOUT) {
		TIMEOUT = tIMEOUT;
	}
	
}
