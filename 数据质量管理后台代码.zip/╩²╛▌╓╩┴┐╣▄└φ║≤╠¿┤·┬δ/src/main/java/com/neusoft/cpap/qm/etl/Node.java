package com.neusoft.cpap.qm.etl;

import org.springframework.stereotype.Component;

@Component
public class Node {
	
	private String nodeType;
	private String nodeValue;
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getNodeValue() {
		return nodeValue;
	}
	public void setNodeValue(String nodeValue) {
		this.nodeValue = nodeValue;
	}
	@Override
	public String toString() {
		return "Node [nodeType=" + nodeType + ", nodeValue=" + nodeValue + "]";
	}
	
	

}
