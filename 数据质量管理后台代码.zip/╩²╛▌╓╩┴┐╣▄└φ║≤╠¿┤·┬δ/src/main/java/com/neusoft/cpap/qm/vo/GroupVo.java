package com.neusoft.cpap.qm.vo;

import lombok.Data;

@Data
public class GroupVo {
	private String group_id;//组ID
	private String group_name;//组名称
	private String parent_group_id;//父类组ID
}
