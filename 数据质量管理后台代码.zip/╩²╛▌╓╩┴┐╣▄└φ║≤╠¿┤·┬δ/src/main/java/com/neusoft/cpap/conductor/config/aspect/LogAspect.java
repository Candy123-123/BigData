package com.neusoft.cpap.conductor.config.aspect;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.nokia.sai.micro.framework.client.entity.ResultEntity;

@Aspect
@Component
public class LogAspect {
	private static Logger logger=LoggerFactory.getLogger(LogAspect.class);
	@Pointcut("execution(public * com.neusoft.cpap.conductor.controller.*Controller.*(..))")
    public void declearJoinPointExpression(){}
	@Around("declearJoinPointExpression()")
	 public Object logAspect(ProceedingJoinPoint  point)throws Throwable{
		Object result = null;
		HttpServletRequest request =((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session =request.getSession();
		String operationStr="";
		String user=null;
		/*
		 * if(session!=null){ user=(String) session.getAttribute("userName"); }
		 * if(user==null){ user=BaseContextHandler.getUsername(); } if(user!=null){
		 * operationStr=user+" "; }
		 */
		//请求路径
		String reStr=request.getRequestURI();
        logger.info(operationStr+reStr+" start.");
        try {
            //前置通知
            //执行目标方法
            result = point.proceed();
            if(result instanceof ResultEntity){
            	ResultEntity<?> res = (ResultEntity<?>)result;
            	if(res!=null && res.getException()!=null){
            		//throw new Exception(res.getException());
            		logger.error(operationStr+reStr+" failed.",res.getException());
            		System.err.println(operationStr+reStr+" failed."+res.getException());
            	}
            }
            //返回通知
        } catch (Throwable e) {
            //异常通知
        	logger.error(operationStr+reStr+" failed.",e);
            throw new Exception(e);
        }finally{
        	//后置通知
        	logger.info(operationStr+reStr+" end.");
        }
        return result;
    }
}
