package com.neusoft.cpap.qm.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.neusoft.mid.commons.exception.Xml2ObjectException;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.core.util.QuickWriter;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.xml.Dom4JDriver;
import com.thoughtworks.xstream.io.xml.PrettyPrintWriter;
import com.thoughtworks.xstream.io.xml.XppDriver;

/**
 * @Description Util for xml
 * @Author Delen.Yin
 * @Created 2014年12月23日
 */
public class XmlUtil {
	private static final Logger logger = LoggerFactory.getLogger(XmlUtil.class);
	private static String PREFIX_CDATA = "<![CDATA[";
    private static String SUFFIX_CDATA = "]]>";
    private static final Integer XSTREAM_NUM=100;
    private static final ConcurrentHashMap<Integer,XStream> xstreamObj1 = new ConcurrentHashMap<Integer,XStream>();
    private static final ConcurrentHashMap<Integer,XStream> xstreamObj2 = new ConcurrentHashMap<Integer,XStream>();
    static{
    	for(int i=0;i<XSTREAM_NUM;i++){
    		xstreamObj1.put(i, new XStream(new Dom4JDriver()));
    		xstreamObj2.put(i, new XStream(new XppDriver() {  
                @Override  
                public HierarchicalStreamWriter createWriter(Writer out) {  
                    return new PrettyPrintWriter(out) {  
                        protected void writeText(QuickWriter writer, String text) {  
                            if (text.startsWith(PREFIX_CDATA) && text.endsWith(SUFFIX_CDATA)) {  
                                writer.write(text);  
                            } else {  
                                super.writeText(writer, text);  
                            }  
                        }  
                    };  
                }  
            }));
    	}
    }
	/**
	 * 
	 * @param xmlFile
	 * @param aliasMap
	 * @return
	 */
	public static <T> T xmlToObject(File xmlFile, Map<String, Class<?>> aliasMap)
			throws Exception {
		T t = null;
		try {
			Random rand=new Random();
			Integer xstreamKey=rand.nextInt(XSTREAM_NUM);
			XStream xstream=xstreamObj1.get(xstreamKey);
			FileInputStream in = new FileInputStream(xmlFile);
			Iterator<String> it = aliasMap.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next();
				Class<?> clazz = aliasMap.get(key);
				xstream.alias(key, clazz);
			}
			t = (T) xstream.fromXML(in);
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
		return t;
	}
	
	public static <T> T xmlToObject(InputStream in, Map<String, Class<?>> aliasMap)
			throws Exception {
		T t = null;
		try {
			Random rand=new Random();
			Integer xstreamKey=rand.nextInt(XSTREAM_NUM);
			XStream xstream=xstreamObj1.get(xstreamKey);
			//FileInputStream in = new FileInputStream(xmlFile);
			Iterator<String> it = aliasMap.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next();
				Class<?> clazz = aliasMap.get(key);
				xstream.alias(key, clazz);
			}
			t = (T) xstream.fromXML(in);
		} catch (Exception e) {
			//e.printStackTrace();
			logger.error(e.getMessage(),e);
			throw e;
		}
		return t;
	}

	public static <T> String objectToXml(String path, T config,
			Map<String, Class<?>> aliasMap) throws IOException {
		String xml = null;

		Random rand=new Random();
		Integer xstreamKey=rand.nextInt(XSTREAM_NUM);
		XStream xstream=xstreamObj2.get(xstreamKey);
		
		FileOutputStream out=null;
		try {
			out = new FileOutputStream(new File(path));
            Iterator<String> it = aliasMap.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next();
				Class<?> clazz = aliasMap.get(key);
				xstream.alias(key, clazz);
			}
			xml = xstream.toXML(config);
			out.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".getBytes());
			out.write(xml.getBytes());
		} catch (IOException e) {
			logger.error(e.getMessage(),e);
			throw e;
		}finally{
			if(out!=null){
				out.close();
				out=null;
			}
		}

		return xml;
	}
}
