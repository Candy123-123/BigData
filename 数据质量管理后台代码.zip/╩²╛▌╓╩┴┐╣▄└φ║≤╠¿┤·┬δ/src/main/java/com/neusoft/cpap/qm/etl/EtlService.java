package com.neusoft.cpap.qm.etl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSON;
import com.neusoft.cpap.qm.common.GlobalConstants;
import com.neusoft.cpap.qm.etl.handler.Handler;
import com.neusoft.cpap.qm.util.DateUtils;
import com.nokia.sai.micro.framework.client.entity.ParamEntity;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;
import com.nokia.sai.micro.framework.exception.AppException;
import com.nokia.sai.micro.framework.interfaces.AppLogger;
import com.nokia.sai.micro.framework.logger.AppLoggerFactory;
import com.nokia.sai.micro.framework.service.BaseService;

@Service("qmSys.EtlService")
public class EtlService extends BaseService {

	private static final AppLogger logger = AppLoggerFactory
			.getLogger(EtlService.class);
	private static final String SERVICE_NAME = "qmSys.EtlService";
	Map<String, Handler> handlerMap = PowershareConfig.handlerMap;

	// etl-参数-create
	public ResultEntity<Map<String, Object>> createWorkEtl(Map<String,Object> paramMap,String processName) throws Exception {
		EtlRequestParam etlParam = new EtlRequestParam();
		String etlName = paramMap.get("etlName").toString();
		Integer taskType = Integer.valueOf(paramMap.get("taskType").toString());
		String sliceType ="D";
		if(paramMap.get("sliceType") != null ){//周期
			sliceType = paramMap.get("sliceType").toString();
		}
		etlParam.setDelay_minute(paramMap.get("delayMinute").toString());
		String isActive = paramMap.get("isActive").toString();
		String isTimerJobActive = paramMap.get("isTimerJobActive").toString();
		etlParam.setProcessName(etlName);
		etlParam.setSliceType(sliceType);
		etlParam.setIsSingleImmed(getIsSingleImmed(taskType));
		etlParam.setRunSliceTime(getRunSliceTime(sliceType, taskType));
		etlParam.setIsActive(isActive);
		etlParam.setIsTimerJobActive(isTimerJobActive);
		etlParam.setUserid(paramMap.get("userId").toString());
		etlParam.setEtlFirstGroup(paramMap.get("etlFristGroup").toString());
		etlParam.setEtlSecondaryGroup(paramMap.get("etlSecondaryGroup").toString());
		getProcessNode(etlParam,paramMap, processName);
		System.err.println("-------------------------createETL--------------------------");
		ResultEntity<Map<String, Object>> result = createEtl(etlParam);
		return result;
	}

	
	// etl-参数-流程节点key-value
	private void getProcessNode(EtlRequestParam etlParam,Map<String,Object> paramMap,String processName) throws AppException {
		Handler handler = null;
		if(processName.equals("qmSchemaTask")){//共享脱敏
			handler = handlerMap.get("share_mask");
		}
//		else if(processName.equals("share")){//共享
//			handler = handlerMap.get("share");
//		}else if(processName.equals("tenant_mask")){//租户脱敏
//			handler = handlerMap.get("tenant_mask");
//		}else if(processName.equals("tenant")){//租户
//			handler = handlerMap.get("tenant");
//		}else if(processName.equals("cleanUpData")){//租户扫描清理数据
//			handler = handlerMap.get("cleanUpData");
//		}else if(processName.equals("moveData")){//租户扫描搬移并清理数据
//			handler = handlerMap.get("moveData");
//		}else if(processName.equals("shrike_share")){//实时共享创建
//			handler = handlerMap.get("shrike_share");
//		}else if(processName.equals("kill_yarn")){//实时共享kill-yarn
//			handler = handlerMap.get("kill_yarn");
//		}
		else{
			logger.info("{} not find processName {}", SERVICE_NAME,processName);
		}
		handler.execute(etlParam, paramMap);
	}

	// etl-参数-调度时间
	public String getRunSliceTime(String sliceType, Integer taskType)
			throws Exception {
		if (taskType.intValue() == 0) {// 周期任务
			return (String) DateUtils
					.StringTime2Date(new Date(), 0, sliceType);
		} else {// 即席 立即执行
			return (String) DateUtils.StringTime2Date(new Date(), -2,
					sliceType);
		}

	}

	// etl-参数-周期任务、立即任务
	private Boolean getIsSingleImmed(Integer taskType) {
		if (taskType.intValue() == 0) {// 周期任务
			return false;
		}
		return true;
	}

	// 延迟时间
	/*private String getDelayMinute(String sliceType, Integer delayMinute) {
		if(delayMinute == null){
			return "0";
		}
		if (sliceType.equals("D") || sliceType.equals("M")) {
			return String.valueOf((delayMinute * 60));
		}
		return "0";
	}*/

	// 调用etlapp-创建etl任务
	public ResultEntity<Map<String, Object>> createEtl(EtlRequestParam etlParam){
		logger.info("{} create workEtl begin,etlName={}", SERVICE_NAME, etlParam.getProcessName());
//		return this
//				.call(new ParamEntity<ResultEntity<Map<String, Object>>>(
//						"etl.app.controller.etlproController.etlproInt",
//						etlParam,
//						new ParameterizedTypeReference<ResultEntity<Map<String, Object>>>() {
//						}));
		RestTemplate restTemplate = new RestTemplate();
		String result_s = restTemplate.postForObject(GlobalConstants.ETL_URL + "etl/app/controller/etlproController/etlproInt", etlParam, String.class);
		return new ResultEntity(true);
	}

	// 调用etlapp-真删除etl任务
	public ResultEntity<Map<String, String>> deleteEtl(String processName)
			throws AppException {
		logger.info("{} delete workEtl begin,etlName={}" ,SERVICE_NAME, processName);
		return this
				.call(new ParamEntity<ResultEntity<Map<String, String>>>(
						"etl.app.controller.etlproController.etlproWorkOrderDel",
						processName,
						new ParameterizedTypeReference<ResultEntity<Map<String, String>>>() {
						}));
	}

	// 调用etlapp -假删除
	public ResultEntity<Map<String, String>> offlineEtl(String processName)
			throws AppException {
		logger.info("{} offline workEtl begin,etlName={}" ,SERVICE_NAME, processName);
		return this
				.call(new ParamEntity<ResultEntity<Map<String, String>>>(
						"etl.app.controller.etlproController.etlproWorkOrderDelFal",
						processName,
						new ParameterizedTypeReference<ResultEntity<Map<String, String>>>() {
						}));
	}

	// 调用etlapp-暂停etl任务-修改timer-job
	public ResultEntity<Map<String, String>> pauseEtl(String processName)
			throws AppException {
		logger.info("{} pause workEtl begin,etlName={}" ,SERVICE_NAME, processName);
		return this
				.call(new ParamEntity<ResultEntity<Map<String, String>>>(
						"etl.app.controller.etlproController.updateEtlProcessActivePause",
						processName,
						new ParameterizedTypeReference<ResultEntity<Map<String, String>>>() {
						}));
	}

	// 调用etlapp-启动etl任务-修改timer-job
	public ResultEntity<Map<String, String>> startUpEtl(Map<String,Object> map)
			throws AppException {
		logger.info("{} start workEtl begin,param={}" ,SERVICE_NAME,JSON.toJSONString(map));
		return this
				.call(new ParamEntity<ResultEntity<Map<String, String>>>(
						"etl.app.controller.etlproController.updateEtlProAndTimeJobIsActiveByProCode",
						map,
						new ParameterizedTypeReference<ResultEntity<Map<String, String>>>() {
						}));
	}

	// etl-参数-update
//	public ResultEntity<Map<String, String>> updateWorkEtl(Boolean isMask,
//			String eltName, String keyCode,String runSliceTime,String workType
//			,String paramsValue,String hbaseTablesSqlUpdate) throws Exception {
//		ShareWork shareWork = new ShareWork();
//		shareWork.setProcessName(eltName);
//		shareWork.setIsActive("1");
//		List<Map<String,Object>> nodeList = new ArrayList<Map<String,Object>>();
//		Map<String,Object> map = new HashMap<String,Object>();
//		String nodeCode  = "";
//		if(isMask!=null){
//			if(workType.equals("1")){
//				nodeCode = isMask==true?"T3":"T2";
//			}else{
//				nodeCode = isMask==true?"T5":"T4";
//			}
//		}
//		if(!StringUtils.isEmpty(keyCode)){
//			map.put("nodeCode", nodeCode);
//			map.put("key", "serialNumber");
//			map.put("value", keyCode);
//			nodeList.add(map);
//		}
//		
//		if(!StringUtils.isEmpty(paramsValue)){
//			Map<String,Object> map2 = new HashMap<String,Object>();
//			map2.put("nodeCode", "T1");
//			map2.put("key", "params");
//			map2.put("value", paramsValue);
//			nodeList.add(map2);
//		}
//		
//		
//		if(!StringUtils.isEmpty(hbaseTablesSqlUpdate)) {
//			Map<String,Object> map3 = new HashMap<String,Object>();
//			map3.put("nodeCode", nodeCode);
//			map3.put("key", "hbaseTablesStr");
//			map3.put("value", hbaseTablesSqlUpdate);
//			nodeList.add(map3);
//		}
//		shareWork.setNodeList(nodeList);
//		shareWork.setIsTimeJobActive("1");
//		shareWork.setRunSliceTime(runSliceTime);
//		
//		
//		ResultEntity<Map<String, String>> updateEtlResult = updateEtl(shareWork);
//		return updateEtlResult;
//	}
//	// 调用etlapp-启用etl任务,修改tokenId
//	private ResultEntity<Map<String, String>> updateEtl(ShareWork shareWork)
//			throws AppException {
//		logger.info("{} update workEtl begin,etlName={}",
//				SERVICE_NAME,shareWork.getProcessName());
//		return this
//				.call(new ParamEntity<ResultEntity<Map<String, String>>>(
//						"etl.app.controller.etlproController.updateWorkOrderEtlNodeVlue",
//						JSON.toJSONString(shareWork),
//						new ParameterizedTypeReference<ResultEntity<Map<String, String>>>() {
//						}));
//
//	}
	//根据任务名称查询etl执行状态
	public ResultEntity<Map<String, String>> queryEtlStatusByEtlName(Map<String,Object> map)
			throws AppException {
		logger.info("{} query workEtlStatus begin,param={}",
				SERVICE_NAME,JSON.toJSONString(map));
		return this
				.call(new ParamEntity<ResultEntity<Map<String, String>>>(
						"etl.app.controller.etlprostatusController.etlstatusSelByProcessName",
						map,
						new ParameterizedTypeReference<ResultEntity<Map<String, String>>>() {
						}));

	}
	// 获得etl参数
	public ResultEntity<String> getEtlParam(
			String processName, String nodeCode,String key) throws Exception {
		
		logger.info("{} getEtlParam begin,processName={},nodeCode={},key={}",
				SERVICE_NAME,processName,nodeCode,key);
		Map map =new HashMap();
		map.put("processName", processName);
		map.put("nodeCode", nodeCode);
		map.put("key", key);
		ResultEntity<String> result = this
				.call(new ParamEntity<ResultEntity<String>>(
						"etl.app.controller.etlproController.getEtlNodeValueByProcessCodeAndNodeCode",
						JSON.toJSONString(map),
						new ParameterizedTypeReference<ResultEntity<String>>() {
						}));
		logger.info("{} getEtlParam end,result={}",
				SERVICE_NAME,JSON.toJSONString(result));
		return result;
		
	}
}
