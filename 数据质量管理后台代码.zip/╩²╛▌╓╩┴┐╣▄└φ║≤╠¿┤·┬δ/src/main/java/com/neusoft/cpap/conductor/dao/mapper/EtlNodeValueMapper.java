package com.neusoft.cpap.conductor.dao.mapper;

import com.neusoft.cpap.conductor.model.EtlNodeValue;

import tk.mybatis.mapper.common.BaseMapper;


public interface EtlNodeValueMapper extends BaseMapper<EtlNodeValue>{

}
