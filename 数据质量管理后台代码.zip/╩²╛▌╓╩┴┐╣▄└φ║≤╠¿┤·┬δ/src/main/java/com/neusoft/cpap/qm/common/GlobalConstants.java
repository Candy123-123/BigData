package com.neusoft.cpap.qm.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Configuration
public class GlobalConstants {
	public static String METADATA_URL;//元数据url
	public static String FERRYBUILDER_URL;//ferry  URL
	public static String ETL_URL;//ETL   URL
	public final static String APP_PATH = System.getProperty("user.dir");
	
	public static String oraResultTableName;
	public static String resultColumns;
	public static String hiveResultTableName;
	public static String queueResultName;
	
	public static String oraDetailTableName;
	public static String detailColumns;
	public static String hiveDetailTableName;
	public static String queueDetailName;
	
	public static String oraUrl;
	public static String oraUser;
	public static String oraPassword;
	
	public static String paralle;
	
	@Value("${conductor.metadataUrl}")
	public void setMETADATA_URL(String metadataUrl) {
		this.METADATA_URL = metadataUrl;
	}
	
	@Value("${conductor.ferryBuilderUrl}")
	public void setFERRYBUILDER_URL(String ferryBuilderUrl) {
		this.FERRYBUILDER_URL = ferryBuilderUrl;
	}
	
	@Value("${conductor.etlUrl}")
	public void setETL_URL(String etlUrl) {
		this.ETL_URL = etlUrl;
	}
	@Value("${conductor.oraResultTableName}")
	public static void setOraResultTableName(String oraResultTableName) {
		GlobalConstants.oraResultTableName = oraResultTableName;
	}
	@Value("${conductor.resultcolumns}")
	public static void setResultcolumns(String resultcolumns) {
		GlobalConstants.resultColumns = resultcolumns;
	}
	@Value("${conductor.hiveResultTableName}")
	public static void setHiveResultTableName(String hiveResultTableName) {
		GlobalConstants.hiveResultTableName = hiveResultTableName;
	}
	@Value("${conductor.queueResultName}")
	public static void setQueueResultName(String queueResultName) {
		GlobalConstants.queueResultName = queueResultName;
	}
	@Value("${conductor.oraDetailTableName}")
	public static void setOraDetailTableName(String oraDetailTableName) {
		GlobalConstants.oraDetailTableName = oraDetailTableName;
	}
	@Value("${conductor.detailcolumns}")
	public static void setDetailcolumns(String detailcolumns) {
		GlobalConstants.detailColumns = detailcolumns;
	}
	@Value("${conductor.hiveDetailTableName}")
	public static void setHiveDetailTableName(String hiveDetailTableName) {
		GlobalConstants.hiveDetailTableName = hiveDetailTableName;
	}
	@Value("${conductor.queueDetailName}")
	public static void setQueueDetailName(String queueDetailName) {
		GlobalConstants.queueDetailName = queueDetailName;
	}
	@Value("${conductor.paralle}")
	public static void setParalle(String paralle) {
		GlobalConstants.paralle = paralle;
	}
	@Value("${spring.datasource.url}")
	public static void setOraUrl(String oraUrl) {
		GlobalConstants.oraUrl = oraUrl;
	}
	@Value("${spring.datasource.username}")
	public static void setOraUser(String oraUser) {
		GlobalConstants.oraUser = oraUser;
	}
	@Value("${spring.datasource.password}")
	public static void setOraPassword(String oraPassword) {
		GlobalConstants.oraPassword = oraPassword;
	}
	
}
