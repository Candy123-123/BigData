package com.neusoft.cpap.qm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neusoft.cpap.qm.common.GlobalConstants;
import com.neusoft.cpap.qm.dao.QmConfigDao;
import com.neusoft.cpap.qm.dao.mapper.SampleRatioMapper;
import com.neusoft.cpap.qm.service.QmBusinessService;
import com.neusoft.cpap.qm.service.QmConfigService;
import com.neusoft.cpap.qm.vo.BasicRuleVo;
import com.neusoft.cpap.qm.vo.DataSourceVo;
import com.neusoft.cpap.qm.vo.QmSampleRatioTab;
import com.neusoft.cpap.qm.vo.QmSourceTab;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;
import com.nokia.sai.micro.framework.util.IdUtil;

@Service
@Transactional
public class QmConfigServiceImpl implements QmConfigService {
	@Autowired
	private QmConfigDao qmConfigDao;
	@Autowired
	private SampleRatioMapper sampleRatioMapper;
	@Autowired
	private QmBusinessService qmBusinessService;
	public static final String REST_SERVICE_URI = "http://10.4.66.160:8801";

	@Override
	public PageInfo<DataSourceVo> queryDataSourceList(Map map) {
		// TODO Auto-generated method stub
		Integer currentPage = (Integer) map.get("current") == null ? 1 : (Integer) map.get("current");
		Integer pageSize = (Integer) map.get("pageSize") == null ? 20 : (Integer) map.get("pageSize");
		PageHelper.startPage(currentPage, pageSize);
		List<DataSourceVo> res = qmConfigDao.queryDataSourceList(map);
		PageInfo<DataSourceVo> pageInfo = new PageInfo(res);
		return pageInfo;
	}

	@Override
	public ResultEntity addDataSourceList(DataSourceVo dataSourceVo) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		qmConfigDao.addDataSourceList(dataSourceVo);
		return result;
	}

	@Override
	public ResultEntity delDataSourceList(String id) {
		// TODO Auto-generated method stub
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		qmConfigDao.delDataSourceList(id);
		return result;
	}

	@Override
	public PageInfo<BasicRuleVo> queryBasicRuleList(Map map) {
		// TODO Auto-generated method stub
		Integer currentPage = (Integer) map.get("current") == null ? 1 : (Integer) map.get("current");
		Integer pageSize = (Integer) map.get("pageSize") == null ? 20 : (Integer) map.get("pageSize");
		PageHelper.startPage(currentPage, pageSize);
		List<BasicRuleVo> res = qmConfigDao.queryBasicRuleList(map);
		PageInfo<BasicRuleVo> pageInfo = new PageInfo(res);
		return pageInfo;
	}

	@Override
	public ResultEntity addCustomRule(Map map) {
		// TODO Auto-generated method stub
		// 校验是否由重名
		ResultEntity result = new ResultEntity();
		int cnt = qmConfigDao.checkExistCustomName(map);
		if (cnt > 0) {
			result.setStatus(false);
			result.setData("名称已存在");
		} else {
			result.setStatus(true);
			qmConfigDao.addCustomRule(map);
		}
		return result;
	}

	@Override
	public void delCustomRule(String id) {
		// TODO Auto-generated method stub
		qmConfigDao.delCustomRule(id);
	}

	@Override
	public List<QmSourceTab> queryDsourceData(Map map) {
		List<QmSourceTab> res = qmConfigDao.queryDsourceData(map);
		return res;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public PageInfo<QmSampleRatioTab> querySamepleRatio(Map<String, Object> map) {
		// TODO Auto-generated method stub
		Integer currentPage = (Integer) map.get("pageNum") == null ? 1 : (Integer) map.get("pageNum");
		Integer pageSize = (Integer) map.get("pageSize") == null ? 20 : (Integer) map.get("pageSize");
		PageHelper.startPage(currentPage, pageSize);
		List<QmSampleRatioTab> res = qmConfigDao.querySamepleRatio(map);
		PageInfo<QmSampleRatioTab> pageInfo = new PageInfo(res);
		return pageInfo;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ResultEntity saveSamepleRatio(QmSampleRatioTab qmSampleRatioTab) {
		ResultEntity resultEntity = new ResultEntity();
		int result = 0;
		if (qmSampleRatioTab.getId() == null) {
			qmSampleRatioTab.setId(IdUtil.nextId());
			result = sampleRatioMapper.insertSelective(qmSampleRatioTab);
		} else {
			result = sampleRatioMapper.updateByPrimaryKey(qmSampleRatioTab);
		}
		if (result == 1) {
			resultEntity.setStatus(true);
		} else {
			resultEntity.setStatus(false);
		}
		return resultEntity;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ResultEntity deleteSamepleRatio(List<QmSampleRatioTab> list) {
		List<Long> listId = new ArrayList<Long>();
		ResultEntity resultEntity = new ResultEntity();
		resultEntity.setStatus(true);
		for (QmSampleRatioTab qmSampleRatioTab : list) {
			listId.add(qmSampleRatioTab.getId());
		}
		try {
			qmConfigDao.delSamepleRatio(listId);
		} catch (Exception e) {
			resultEntity.setStatus(false);
		}

		return resultEntity;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResultEntity queryStandardTreeList(Object param) {
		RestTemplate restTemplate = new RestTemplate();
		ResultEntity<Object> resultEntity = restTemplate.postForObject(
				REST_SERVICE_URI + "/meta/facade/controller/DataQualityController/" + "queryStandardTreeList",
				param, ResultEntity.class);
		ResultEntity result = new ResultEntity();
		result.setStatus(resultEntity.getStatus());
		if (resultEntity.getStatus()) {
			result.setData(resultEntity.getData());
		} 
		result.setData(resultEntity.getData());
		return result;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ResultEntity queryStandardRules(Object param) {
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		RestTemplate restTemplate = new RestTemplate();
		JSONArray resultList = new JSONArray();
		String resultEntity = restTemplate.postForObject( 
				GlobalConstants.METADATA_URL + "/DataQualityController/queryStandardRules",
				param, String.class);
		JSONObject obj = (JSONObject) JSONObject.parse(resultEntity);
		JSONObject data = (JSONObject) obj.get("data");
		result.setData(data);
		JSONArray array = (JSONArray) data.get("list");
		Map param2 = new HashMap();
		for(int i=0;i<array.size();i++){
			JSONObject temp = (JSONObject) array.get(i);
			JSONObject mdStandard = (JSONObject) temp.get("mdStandard");
			String ori_basic_info = mdStandard.get("basic_info").toString();
			JSONArray boundRule = new JSONArray();
			boundRule = qmBusinessService.changeStandard2BasicRule(ori_basic_info, "");
			mdStandard.put("boundRule", boundRule);
		}
		
		
		return result;
	}
	
	@Override
	public List querySchemeId(Map map) {
		return qmConfigDao.querySchemeId(map);
	}

}
