package com.neusoft.cpap.conductor.entity.vo;

import com.neusoft.cpap.conductor.entity.BaseVo;

public class EtlNodeValueVo extends BaseVo{
	private String key;
	private String value;
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
