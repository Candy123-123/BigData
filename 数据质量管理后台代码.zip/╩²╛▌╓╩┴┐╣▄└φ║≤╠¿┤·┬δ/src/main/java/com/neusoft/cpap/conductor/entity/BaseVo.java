package com.neusoft.cpap.conductor.entity;

public class BaseVo {
	//0-修改，1-新增
	private int action;

	public int getAction() {
		return action;
	}

	public void setAction(int action) {
		this.action = action;
	}
	
	
}
