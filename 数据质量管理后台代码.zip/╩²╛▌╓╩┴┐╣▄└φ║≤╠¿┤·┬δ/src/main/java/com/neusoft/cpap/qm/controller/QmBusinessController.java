package com.neusoft.cpap.qm.controller;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageInfo;
import com.neusoft.cpap.qm.service.QmBusinessService;
import com.neusoft.cpap.qm.vo.BaseTaskResult;
import com.neusoft.cpap.qm.vo.GroupVo;
import com.neusoft.cpap.qm.vo.SchemaBasicVo;
import com.neusoft.cpap.qm.vo.SchemaTaskVo;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;

/**
 * 方案相关
 * @author tengh
 *
 */
@RestController
@RequestMapping("/business")
@CrossOrigin
public class QmBusinessController {
	private static final Logger logger = LoggerFactory.getLogger(QmBusinessController.class);
	private static final String SERVICE_NAME = "QmBusinessController";
	@Autowired
	private QmBusinessService qmBusinessService;
	
	@RequestMapping(value = "/hello")
	public String sayHello(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".sayHello],map = "+JSON.toJSONString(map));
		return "hello world";
	}
	
	
	/**
	 * 查询分组信息
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryGroupList")
	public ResultEntity queryGroupList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryGroupList],map = "+JSON.toJSONString(map));
		return qmBusinessService.queryGroupList(map);
	}
	
	/**
	 * 添加分组信息
	 * @param groupVo
	 * @return
	 */
	@RequestMapping(value = "/addGroupList")
	public ResultEntity addGroupList(@RequestBody GroupVo groupVo){
		logger.info("RestService was called [" + SERVICE_NAME+ ".addGroupList],map = "+JSON.toJSONString(groupVo));
		ResultEntity result = new ResultEntity();
		try{
			result = qmBusinessService.addGroupList(groupVo);
		}catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception("添加失败"));;
			throw e;
		}
		return result;
	}
	
	/**
	 * 删除分组信息
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/delGroupList")
	public ResultEntity delGroupList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".delGroupList],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		String id = map.get("id").toString();
		try{
			qmBusinessService.delGroupList(id);
		} catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception(id+"删除失败"));;
			throw e;
		}
		return result;
	}
	
	/**
	 * 查询评估方案
	 * @param map
	 */
	@RequestMapping(value = "/querySchemaList")
	public ResultEntity<PageInfo<SchemaBasicVo>> querySchemaList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySchemaList],map = "+JSON.toJSONString(map));
		return new ResultEntity<PageInfo<SchemaBasicVo>>(qmBusinessService.querySchemaListList(map));
	}
	
	/**
	 * 添加方案时查询准备数据
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/querySchemaComboxByType")
	public ResultEntity querySchemaComboxByType(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySchemaComboxByType],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.querySchemaComboxByType(map);
		return result;
	}
	
	/**
	 * 添加评估方案基础信息
	 * @param schemaBasicVo
	 * @return
	 */
	@RequestMapping(value = "/addSchemaListList")
	public ResultEntity addSchemaListList(@RequestBody SchemaBasicVo schemaBasicVo){
		logger.info("RestService was called [" + SERVICE_NAME+ ".addSchemaListList],map = "+JSON.toJSONString(schemaBasicVo));
		ResultEntity result = new ResultEntity();
		try{
			result = qmBusinessService.addSchemaListList(schemaBasicVo);
		}catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception("添加失败"));;
			throw e;
		}
		return result;
	}
	
	/**
	 * 删除评估方案
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/delSchemaListList")
	public ResultEntity delSchemaListList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".delSchemaListList],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		String ids = map.get("id").toString().replace("[", "").replace("]", "");
		for(String id : ids.split(",")){
			try{
				qmBusinessService.delSchemaListList(id.trim());
			} catch(Exception e) {
				result.setStatus(false);
				result.setException(new Exception(id+"删除失败"));;
				throw e;
			}
		}
		return result;
	}
	
	/**
	 * 修改评估方案
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/modSchemaListList")
	public ResultEntity modSchemaListList(@RequestBody SchemaBasicVo schemaBasicVo){
		logger.info("RestService was called [" + SERVICE_NAME+ ".modSchemaListList],map = "+JSON.toJSONString(schemaBasicVo));
		ResultEntity result = new ResultEntity();
		try{
			result = qmBusinessService.modSchemaListList(schemaBasicVo);
		}catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception("添加失败"));;
			throw e;
		}
		return result;
	}
	
	/**
	 * 查看方案详情
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/querySchemaDetail")
	public ResultEntity querySchemaDetail(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".modSchemaListList],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		try{
			SchemaBasicVo vo = qmBusinessService.querySchemaDetail(map);
			result.setStatus(true);
			result.setData(vo);
		}catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception("添加失败"));;
			throw e;
		}
		return result;
	}
	
	/**
	 * 质量评估查询
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/querySchemaTaskList")
	public ResultEntity<PageInfo<SchemaTaskVo>> querySchemaTaskList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySchemaTaskList],map = "+JSON.toJSONString(map));
		return new ResultEntity<PageInfo<SchemaTaskVo>>(qmBusinessService.querySchemaTaskList(map));
	}
	/**
	 * 设定执行周期
	 * @return
	 */
	@RequestMapping(value = "/setSchemaCycle")
	public ResultEntity setSchemaCycle(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".setSchemaCycle],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		try{
			qmBusinessService.setSchemaCycle(map);//传递协议
			result.setStatus(true);
		}catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception("添加失败"));
			throw e;
		}
		return result;
	}
	
	/**
	 * 启动或禁用方案
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/startOrStopSchema")
	public ResultEntity startOrStopSchema(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".startOrStopSchema],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		try{
			qmBusinessService.startOrStopSchema(map);//传递协议
			result.setStatus(true);
		}catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception("启动或禁用方案失败"));
			throw e;
		}
		return result;
	}
	
	@RequestMapping(value = "/queryAllTaskBySchemaId")
	public ResultEntity<PageInfo<SchemaTaskVo>> queryAllTaskBySchemaId(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryAllTaskBySchemaId],map = "+JSON.toJSONString(map));
		return new ResultEntity<PageInfo<SchemaTaskVo>>(qmBusinessService.queryAllTaskBySchemaId(map));
	}
	/**
	 * 查看评估报告结果总览
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/querySchemaTaskReportSummary")
	public ResultEntity querySchemaTaskReportSummary(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySchemaTaskReportSummary],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.querySchemaTaskReportSummary(map);
		return result;
	}
	
	/**
	 * 按维度查询评估报告
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/querySchemaTaskReportDimention")
	public ResultEntity querySchemaTaskReportDimention(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySchemaTaskReportDimention],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.querySchemaTaskReportDimention(map);
		return result;
	}
	
	/**
	 * 质量指标 查询数据源配置
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/queryHasDataSource")
	public ResultEntity queryHasDataSource(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryHasDataSource],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryHasDataSource(map);
		return result;
	}
	
	/**
	 * 查询质量指标各个汇总信息
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/queryQualitySummary")
	public ResultEntity queryQualitySummary(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryQualitySummary],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryQualitySummary(map);
		return result;
	}
	
	/**
	 * 数据质量分数走势图
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/queryScoreTrend")
	public ResultEntity queryScoreTrend(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryScoreTrend],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryScoreTrend(map);
		return result;
	}
	
	/**
	 * 数据源分数排名
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/queryScoreRank")
	public ResultEntity queryScoreRank(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryScoreRank],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryScoreRank(map);
		return result;
	}
	
	
	/**
	 * 导出报表
	 * @param map
	 * @return
	 */
	@RequestMapping(value="/exportReport")
	public void exportReport(@RequestBody Map map,HttpServletRequest request,HttpServletResponse response){
		logger.info("RestService was called [" + SERVICE_NAME+ ".exportReport],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		qmBusinessService.exportReport(map,request,response);
//		try {
//			String exp_file="";
//			File file = new File(exp_file);
//			// 设置响应头内容
//			response.setContentType("multipart/form-data");
//			response.setCharacterEncoding("UTF-8");
//			String userAgent = request.getHeader("User-Agent");
//			String fileName = file.getName();
//			byte[] bytes = userAgent.contains("MSIE") ? fileName.getBytes() : fileName.getBytes("UTF-8");
//			 // fileName.getBytes("UTF-8")处理safari的乱码问题
//			fileName = new String(bytes, "ISO-8859-1"); // 各浏览器基本都支持ISO编码
//	
//			response.setHeader("Content-Disposition", "attachment;" + "filename=" + fileName);
//			// 输出到输出流中
//			OutputStream out = response.getOutputStream();
//			out = response.getOutputStream();
//			out.write(FileUtils.readFileToByteArray(file));
//			// 关闭输出流
//			out.flush();
//			out.close();
//		} catch (UnsupportedEncodingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	/**
	 * 质量指标 查询方案名
	 * @param map
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value="/queryScheme")
	public ResultEntity queryScheme(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryScheme],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryScheme(map);
		return result;
	}
	
	/**
	 * 方案正确率环比排名
	 * @param map
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value="/queryLinkRatio")
	public ResultEntity<PageInfo<BaseTaskResult>> queryLinkRatio(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryScheme],map = "+JSON.toJSONString(map));
		return new ResultEntity<PageInfo<BaseTaskResult>>(qmBusinessService.queryLinkRatio(map));
	}
	
	/**
	 * 正确率
	 * @param map
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/queryStatis")
	public ResultEntity queryStatis(@RequestBody Map<String,Object> map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryDsourceData],map = "+JSON.toJSONString(map));
		return qmBusinessService.queryStatis(map);
	}
	
	/**
	 * 质量评估 按维度查询
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryDimension")
	public ResultEntity queryDimension(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySchemaTaskReportDimention],map = "+JSON.toJSONString(map));
		return qmBusinessService.queryDimension(map);
	}
	
	/**
	 * 选中维度 下坠时间查询
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryTimeDimension")
	public ResultEntity queryTimeDimension(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySchemaTaskReportDimention],map = "+JSON.toJSONString(map));
		return qmBusinessService.queryTimeDimension(map);
	}
	
	/**
	 * 按字段统计
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryFieldStat")
	public ResultEntity queryFieldStat(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryFieldStat],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryFieldStat(map);
		return result;
	}
	
	/**
	 * 按字段规则统计
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryFieldAndRuleStat")
	public ResultEntity queryFieldAndRuleStat(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryFieldAndRuleStat],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryFieldAndRuleStat(map);
		return result;
	}
	
	/**
	 * 选中维度 按字段统计
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryHourFieldStat")
	public ResultEntity queryHourFieldStat(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryFieldStat],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryHourFieldStat(map);
		return result;
	}
	
	/**
	 * 选中维度 按字段规则统计
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryHourFieldAndRuleStat")
	public ResultEntity queryHourFieldAndRuleStat(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryFieldAndRuleStat],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryHourFieldAndRuleStat(map);
		return result;
	}
	
	/**
	 * 无维度 按字段统计
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryNoFieldStat")
	public ResultEntity queryNoFieldStat(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryFieldStat],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryNoFieldStat(map);
		return result;
	}
	
	/**
	 * 无维度 按字段规则统计
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryNoFieldAndRuleStat")
	public ResultEntity queryNoFieldAndRuleStat(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryFieldAndRuleStat],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result = qmBusinessService.queryNoFieldAndRuleStat(map);
		return result;
	}
}
