package com.neusoft.cpap.conductor.entity.vo;

import java.util.List;
import java.util.Map;


public class EtlOptionVo{
	private List<Map> process;
	private List<Map> group;
	private List<Map> handler;
	private List<Map> waitingList;
	private String user;
	private String cpuLimit;
	private String memLimit;
	public List<Map> getProcess() {
		return process;
	}
	public void setProcess(List<Map> process) {
		this.process = process;
	}
	public List<Map> getGroup() {
		return group;
	}
	public void setGroup(List<Map> group) {
		this.group = group;
	}
	public List<Map> getHandler() {
		return handler;
	}
	public void setHandler(List<Map> handler) {
		this.handler = handler;
	}
	public List<Map> getWaitingList() {
		return waitingList;
	}
	public void setWaitingList(List<Map> waitingList) {
		this.waitingList = waitingList;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCpuLimit() {
		return cpuLimit;
	}
	public void setCpuLimit(String cpuLimit) {
		this.cpuLimit = cpuLimit;
	}
	public String getMemLimit() {
		return memLimit;
	}
	public void setMemLimit(String memLimit) {
		this.memLimit = memLimit;
	}
	
	
	
}
