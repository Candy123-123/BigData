package com.neusoft.cpap.conductor.entity;

import java.util.HashMap;
import java.util.Map;

public class CommandEntity {

	private String template;
	private String sparkHome;
	private String master = "yarn";
	private String deployMode = "cluster";
	private String queue = "default";
	private String principal;
	private String keytab;
	private String proxyUser;
	private int numExecutors = 1;
	private int executorCores = 1;	
	private String driverMemory="1g";
	private String executorMemory="4g";
	private String mainClass;
	private String files = "config.zip,log4j.properties";
	private Map<String, String> conf = new HashMap<>();
	private String mainJar;
	private String mainParams;
	private String jars;
	
	public String getJars() {
		return jars;
	}
	public void setJars(String jars) {
		this.jars = jars;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	public String getSparkHome() {
		return sparkHome;
	}
	public void setSparkHome(String sparkHome) {
		this.sparkHome = sparkHome;
	}
	public String getMaster() {
		return master;
	}
	public void setMaster(String master) {
		this.master = master;
	}
	public String getDeployMode() {
		return deployMode;
	}
	public void setDeployMode(String deployMode) {
		this.deployMode = deployMode;
	}
	public String getQueue() {
		return queue;
	}
	public void setQueue(String queue) {
		this.queue = queue;
	}
	public String getProxyUser() {
		return proxyUser;
	}
	public void setProxyUser(String proxyUser) {
		this.proxyUser = proxyUser;
	}
	public int getNumExecutors() {
		return numExecutors;
	}
	public void setNumExecutors(int numExecutors) {
		this.numExecutors = numExecutors;
	}
	public int getExecutorCores() {
		return executorCores;
	}
	public void setExecutorCores(int executorCores) {
		this.executorCores = executorCores;
	}
	public String getDriverMemory() {
		return driverMemory;
	}
	public void setDriverMemory(String driverMemory) {
		this.driverMemory = driverMemory;
	}
	public String getExecutorMemory() {
		return executorMemory;
	}
	public void setExecutorMemory(String executorMemory) {
		this.executorMemory = executorMemory;
	}
	public String getMainClass() {
		return mainClass;
	}
	public void setMainClass(String mainClass) {
		this.mainClass = mainClass;
	}
	public String getFiles() {
		return files;
	}
	public void setFiles(String files) {
		this.files = files;
	}
	public Map<String, String> getConf() {
		return conf;
	}
	public void setConf(Map<String, String> conf) {
		this.conf = conf;
	}
	public String getMainJar() {
		return mainJar;
	}
	public void setMainJar(String mainJar) {
		this.mainJar = mainJar;
	}
	public String getMainParams() {
		return mainParams;
	}
	public void setMainParams(String mainParams) {
		this.mainParams = mainParams;
	}
	
	public String getPrincipal() {
		return principal;
	}
	public void setPrincipal(String principal) {
		this.principal = principal;
	}
	public String getKeytab() {
		return keytab;
	}
	public void setKeytab(String keytab) {
		this.keytab = keytab;
	}
	@Override
	public String toString() {
		return "CommandEntity [template=" + template + ", sparkHome=" + sparkHome + ", master=" + master
				+ ", deployMode=" + deployMode + ", queue=" + queue + ", principal=" + principal + ", keytab=" + keytab
				+ ", proxyUser=" + proxyUser + ", numExecutors=" + numExecutors + ", executorCores=" + executorCores
				+ ", driverMemory=" + driverMemory + ", executorMemory=" + executorMemory + ", mainClass=" + mainClass
				+ ", files=" + files + ", conf=" + conf + ", mainJar=" + mainJar + ", mainParams=" + mainParams
				+ ", jars=" + jars + "]";
	}
	
}
