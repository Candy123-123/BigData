package com.neusoft.cpap.qm.etl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class MetaDataClient {

	private static Logger logger = LoggerFactory.getLogger(MetaDataClient.class);
	private final static String META_ID_PARA_NAME = "store_id";
	private final static String META_STATUS_PARA_NAME = "status";

	public static List getRemoteMetaData(String url, List<String> msgTypes) {
		RestTemplate restTemplate = new RestTemplate();	
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		for (String msgTypeId : msgTypes) {
			Map<String, Object> request = new HashMap<String, Object>();
			request.put(META_ID_PARA_NAME, msgTypeId);
			request.put(META_STATUS_PARA_NAME, 1);

			Result responseBean = restTemplate.postForObject(url, request, MetaDataClient.Result.class);
			if (responseBean.getStatus() == false) {
				logger.error("get", responseBean.getException());
				continue;
			}
			List<MdStoreDetails> fields = responseBean.getData();
			if (fields.isEmpty()) {
				break;
			}
			Object [] dataTypes = new Object[fields.size()+2];
			String [] dataCodes = new String[fields.size()+2];
			int i = 0;
			for (MdStoreDetails field : fields) {					
				dataCodes[i] = field.getCode();
				int dataTypeCode = field.getDataType();
				if(dataTypeCode == 0)
					dataTypes[i] = Long.class;
				else if(dataTypeCode == 1)
					dataTypes[i] = Long.class;
				else if(dataTypeCode == 2)
					dataTypes[i] = Double.class;
				else if(dataTypeCode == 3)
					dataTypes[i] = String.class;
				else if(dataTypeCode == 4)
					dataTypes[i] = Date.class;
				else 
					dataTypes[i] = String.class;	          
			    i++;			   
			}
			dataCodes[dataTypes.length-2] = "calling_user_tag";
			dataCodes[dataTypes.length-1] = "called_user_tag";
			dataTypes[dataTypes.length-2] = byte[].class;
			dataTypes[dataTypes.length-1] = byte[].class;
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", "ds"+msgTypeId);
			map.put("dataCodes", dataCodes);
			map.put("dataTypes", dataTypes);
			
			list.add(map);
		}
		return list;
	}
	
	
	public static final int FIELD_TYPE_LONG = 0;
	public static final int FIELD_TYPE_INTEGER = 1;
	public static final int FIELD_TYPE_FLOAT = 2;
	public static final int FIELD_TYPE_STRING = 3;
	public static final int FIELD_TYPE_TIMESTAMP = 4;
	public static final int FIELD_TYPE_BOOLEAN = 99;
	

	public static void main(String[] args) {
		String TEST_URL = "http://10.4.66.32:8801/meta/core/controller/StoreController/getStoreDetails";
		String[] TEST_MSG_TYPES = new String[] { "36", "65",  "72","85", "455" };
		List remoteMeta = getRemoteMetaData(TEST_URL,Arrays.asList(TEST_MSG_TYPES));
		System.out.println(remoteMeta);

		
	}
	
	private static class Result extends ResultEntity<List<MdStoreDetails>> {
	}	
	
	private static class ResultEntity<T> {
		private boolean status;
		private Exception exception;
		private T data;

		public ResultEntity() {
			super();
		}

		public ResultEntity(Exception exception) {
			this.status = false;
			this.exception = exception;
		}

		public ResultEntity(T data) {
			this.status = true;
			this.data = data;
		}

		public boolean getStatus() {
			return status;
		}

		public void setStatus(boolean status) {
			this.status = status;
		}

		public Exception getException() {
			return exception;
		}

		public void setException(Exception exception) {
			this.exception = exception;
		}

		public T getData() {
			return data;
		}

		public void setData(T data) {
			this.data = data;
		}
	}
	
	public static Class[] convertDataTypes(int[] dataTypes) {
		// TODO Auto-generated method stub
		Class[] cepEventDataTypes = new Class[dataTypes.length];
		for (int i = 0; i < dataTypes.length; i++) {
			switch (dataTypes[i]) {
			case MetaDataClient.FIELD_TYPE_STRING:
				cepEventDataTypes[i] = String.class;
				break;
			// 按照terrace约定
			case MetaDataClient.FIELD_TYPE_INTEGER:
				cepEventDataTypes[i] = Long.class;
				break;
			case MetaDataClient.FIELD_TYPE_LONG:
				cepEventDataTypes[i] = Long.class;
				break;
			// 按照terrace约定
			case MetaDataClient.FIELD_TYPE_FLOAT:
				cepEventDataTypes[i] = Double.class;
				break;
			case MetaDataClient.FIELD_TYPE_TIMESTAMP:
				cepEventDataTypes[i] = Date.class;
				break;
			case MetaDataClient.FIELD_TYPE_BOOLEAN:
				cepEventDataTypes[i] = Boolean.class;
				break;
			default:
				cepEventDataTypes[i] = String.class;
			}

		}
		return cepEventDataTypes;
	}

	
	private static class MdStoreDetails {
		private Long id;
		private Long storeId;
		private Long logicDetailsId;
		private String code;
		private String name;
		private Integer type;
		private Integer dataType;
		private Integer dataLen;
		private Integer dataPrecision;
		private Integer orderNum;
		private Integer status;
		private String remark;
		private Integer isUpdated;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Integer getType() {
			return type;
		}

		public void setType(Integer type) {
			this.type = type;
		}

		public Integer getStatus() {
			return status;
		}

		public void setStatus(Integer status) {
			this.status = status;
		}

		public String getRemark() {
			return remark;
		}

		public void setRemark(String remark) {
			this.remark = remark;
		}

		public Integer getIsUpdated() {
			return isUpdated;
		}

		public void setIsUpdated(Integer isUpdated) {
			this.isUpdated = isUpdated;
		}

		public Integer getDataType() {
			return dataType;
		}

		public void setDataType(Integer dataType) {
			this.dataType = dataType;
		}

		public Integer getDataLen() {
			return dataLen;
		}

		public void setDataLen(Integer dataLen) {
			this.dataLen = dataLen;
		}

		public Integer getDataPrecision() {
			return dataPrecision;
		}

		public void setDataPrecision(Integer dataPrecision) {
			this.dataPrecision = dataPrecision;
		}

		public Integer getOrderNum() {
			return orderNum;
		}

		public void setOrderNum(Integer orderNum) {
			this.orderNum = orderNum;
		}

		public Long getStoreId() {
			return storeId;
		}

		public void setStoreId(Long storeId) {
			this.storeId = storeId;
		}

		public Long getLogicDetailsId() {
			return logicDetailsId;
		}

		public void setLogicDetailsId(Long logicDetailsId) {
			this.logicDetailsId = logicDetailsId;
		}
	}

}
