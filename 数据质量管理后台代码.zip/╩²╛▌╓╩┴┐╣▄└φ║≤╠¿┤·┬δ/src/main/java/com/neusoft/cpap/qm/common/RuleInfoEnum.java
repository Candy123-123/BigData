package com.neusoft.cpap.qm.common;

public enum RuleInfoEnum {
	Rule_200001("func1"),
	Rule_200002("func2"),
	Rule_200003("func1"),
	Rule_200004("func1"),
	Rule_200005("func1"),
	Rule_200006("func1"),
	Rule_200007("func1"),
	Rule_200008("func1"),
	Rule_200009("func1"),
	Rule_200010("func1"),
	Rule_200011("func1"),
	Rule_200012("func1"),
	Rule_200013("func1");
	
	
	private String func_name;
	
	private RuleInfoEnum(String func_name){
		this.func_name = func_name;
	}
	
	public String getFuncName(){
		return func_name;
	}
}
