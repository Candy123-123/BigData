package com.neusoft.cpap.qm.util;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class DateUtils {
	public static Date toDate(LocalDate localDate) {
        return Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
    }
 
    public static Date toDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }
 
    public static LocalDate toLocalDate(Date date) {
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
    }
 
    public static LocalDateTime toLocalDateTime(Date date) {
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }
    public static String getSpecialTime(String startTime,String endTime,String type,String prefix) {
    	String result="";
    	
    	String startYear=startTime.substring(0, 4);
    	String startMonth=startTime.substring(4,6);
    	startMonth = startMonth.replaceFirst("^0*", "");
    	String startDay=startTime.substring(6,8);
    	startDay = startDay.replaceFirst("^0*", "");
    	String startHour=startTime.substring(8,10);
    	startHour = startHour.replaceFirst("^0*", "");
    	if(startHour.equals("")) {
    		startHour="0";
    	}
    	String startMinute=startTime.substring(10,12);
    	startMinute = startMinute.replaceFirst("^0*", "");
    	if(startMinute.equals("")) {
    		startMinute="0";
    	}
    	int startMinuteInt=Integer.parseInt(startMinute);
    	startMinuteInt=startMinuteInt/5*5;
    	DateTime startDateTime = new DateTime(Integer.parseInt(startYear),Integer.parseInt(startMonth),Integer.parseInt(startDay),
    			Integer.parseInt(startHour),startMinuteInt);
    	
    	String endYear=endTime.substring(0, 4);
    	String endMonth=endTime.substring(4,6);
    	endMonth = endMonth.replaceFirst("^0*", "");
    	String endDay=endTime.substring(6,8);
    	endDay = endDay.replaceFirst("^0*", "");
    	String endHour=endTime.substring(8,10);
    	endHour = endHour.replaceFirst("^0*", "");
    	if(endHour.equals("")) {
    		endHour="0";
    	}
    	String endMinute=endTime.substring(10,12);
    	endMinute = endMinute.replaceFirst("^0*", "");
    	if(endMinute.equals("")) {
    		endMinute="0";
    	}
    	DateTime endDateTime = new DateTime(Integer.parseInt(endYear),Integer.parseInt(endMonth),Integer.parseInt(endDay),
    			Integer.parseInt(endHour),Integer.parseInt(endMinute));
    	
		if (type.equals("H")) {
			while (startDateTime.isBefore(endDateTime)) {
				if(prefix!=null&&!prefix.equals("")) {
					result += prefix+startDateTime.getYear() + "/" + fillZeroBeforeNum(2, startDateTime.getMonthOfYear())
					+ fillZeroBeforeNum(2, startDateTime.getDayOfMonth()) + "/"
					+ fillZeroBeforeNum(2, startDateTime.getHourOfDay()) + ",";
				}else {
					result += startDateTime.getYear() + "/" + fillZeroBeforeNum(2, startDateTime.getMonthOfYear())
					+ fillZeroBeforeNum(2, startDateTime.getDayOfMonth()) + "/"
					+ fillZeroBeforeNum(2, startDateTime.getHourOfDay()) + ",";
				}
				
				startDateTime = startDateTime.plusHours(1);
			}
		}else if(type.equals("5min")) {
			while (startDateTime.isBefore(endDateTime)) {
				if(prefix!=null&&!prefix.equals("")) {
					result += prefix+startDateTime.getYear()  + fillZeroBeforeNum(2, startDateTime.getMonthOfYear())
					+ fillZeroBeforeNum(2, startDateTime.getDayOfMonth())
					+ fillZeroBeforeNum(2, startDateTime.getHourOfDay())+fillZeroBeforeNum(2, startDateTime.getMinuteOfHour()) + ",";
				}else {
					result += startDateTime.getYear()  + fillZeroBeforeNum(2, startDateTime.getMonthOfYear())
					+ fillZeroBeforeNum(2, startDateTime.getDayOfMonth())
					+ fillZeroBeforeNum(2, startDateTime.getHourOfDay())+fillZeroBeforeNum(2, startDateTime.getMinuteOfHour()) + ",";
				}
				
				startDateTime = startDateTime.plusMinutes(5);
			}
		}
		result=result.substring(0, result.length()-1);

    	return result;
    }
    
    public static final String timeFormat_ss = "yyyy-MM-dd HH:mm:ss";
    public static String StringTime2Date(Date date, Integer num, String sliceType)
			throws Exception {
		DateTimeFormatter df = DateTimeFormat.forPattern(timeFormat_ss);
		SimpleDateFormat format0 = new SimpleDateFormat(timeFormat_ss);
		String time = format0.format(date);
		DateTime dt = DateTime.parse(String.valueOf(time), df);
		if (sliceType.equalsIgnoreCase("H")) {
			return String.valueOf(df.print(dt.plusHours(num.intValue())));
		} else if (sliceType.equalsIgnoreCase("D")) {
			return String.valueOf(df.print(dt.plusDays(num.intValue())));
		} else if (sliceType.equalsIgnoreCase("W")) {
			return String.valueOf(df.print(dt.plusWeeks(num.intValue())));
		} else if (sliceType.equalsIgnoreCase("M")) {
            return String.valueOf(df.print(dt.plusMonths(num.intValue())));
		} else if (sliceType.equalsIgnoreCase("T")) {
			return String.valueOf(df.print(dt.plusMonths(num.intValue()-2)));
		} else if (sliceType.equalsIgnoreCase("Q") ||sliceType.equalsIgnoreCase("F")  ) {
			return getDateNow(timeFormat_ss);
		}
		return String.valueOf(df.print(dt.plusMonths(num.intValue()-2)));
	}
    
    public static String getDateNow(String timeFormat){
		Date date = Calendar.getInstance().getTime();
		String dateStr = new SimpleDateFormat(timeFormat).format(date);
		return dateStr;
	}
    /*
	 * 数字前面补0
	 * 
	 */
	public static String fillZeroBeforeNum(int length,int number){
		return String.format("%0"+length+"d", number);
	}
    public static void main(String args[]) {
    	System.out.println(getSpecialTime("20200915000200","20200916000000","H","/aaa/bbb/"));;
    }
}
