package com.neusoft.cpap.qm.etl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class EtlRequestParam {
	
	private String processName;//任务名称
	private String runSliceTime;//运行时间
	private String sliceType;//时间片 D M
	private Boolean isSingleImmed;//是否单次立即执行 true =是
	private String delay_minute;//延迟时间 分钟
	private String dependName;
	private String isActive;//0=禁用 1=启用
	private String isTimerJobActive;//0=禁用 1=启用
	private String etlFirstGroup;//一级分组
	private String etlSecondaryGroup;//二级级分组
	private String userid;//用户名
	private List<String> nodeType = new ArrayList<String>();//节点编号
	private List<Map<String,Object>> nodeValue = new ArrayList<Map<String,Object>>();
	
		
}
