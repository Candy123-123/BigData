package com.neusoft.cpap.qm.etl;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.espertech.esper.client.Configuration;
import com.neusoft.cpap.qm.common.GlobalConstants;
import com.neusoft.cpap.qm.etl.handler.Handler;
import com.neusoft.cpap.qm.util.ConfigUtil;


@Component
@Order(value=1)
public class PowershareConfig implements ApplicationRunner{
	public static Map mapConf = new HashMap();
	public static Map<String, Handler> handlerMap = new HashMap<String, Handler>();
	public static Configuration configuration = new Configuration();
	private static final Logger logger = LoggerFactory.getLogger(PowershareConfig.class);
	private static String[] paths = { "/config/param.properties","/config/work-order.properties" };
	private static final String etlProcessPath = "/src/main/resources/etl-process.xml";
//	private static final String etlFerryHandlePath = "/config/etl-ferry.xml";
//	public static Map<String,EtlFerryTaskHandle> etlFerryHandleParamMap = new HashMap<String,EtlFerryTaskHandle>();
//	private static final String etlSftpHandlePath = "/config/etl-sftp.xml";
//	public static Map<String,EtlSftpTaskHandle> etlSftpHandleParamMap = new HashMap<String,EtlSftpTaskHandle>();
	
	// 获取param.properties的配置参数
	@Override
	public void run(ApplicationArguments args) throws Exception {
		/*for (String path : paths) {
			try {
				Properties properties = new Properties();
				path =  GlobalConstants.APP_PATH + path;
				Map map = ConfigUtil.loadProperty(path);
				System.err.println(JSON.toJSONString(map));
				mapConf.putAll(map);
			} catch (Exception e) {
				logger.error("load " + path + " error", e);
			}
		}*/
		buildHandlerMap();
		
	}
	
	private static void buildHandlerMap() {
		List<Process> processList = null;
		String path = GlobalConstants.APP_PATH + etlProcessPath;
		try {		
			processList = ConfigUtil.loadProcessXML(path);
		} catch (IOException e) {
			logger.error("load " + path + " error", e);
		}
		for (Process process : processList) {
			String processName = process.getProcessName();
			List<Node> nodeList = process.getProcessNode();
			Handler root = null;
			Handler last = null;
			for (Node node : nodeList) {
				try{
				Class<Handler> handlerClass = (Class<Handler>) Class.forName(node.getNodeValue());
				Handler point = handlerClass.newInstance();
				Field nodeTypeField = handlerClass.getDeclaredField("nodeType");
				nodeTypeField.setAccessible(true);
				nodeTypeField.set(point, node.getNodeType());
				if (last == null) {
					last = point;
					root = point;
				} else {
					last = last.setNextHandler(point);
				}			
			}catch(Exception e){
				logger.error("buildHandlerMap error", e);
			}
		}
		handlerMap.put(processName, root);
	}
   }
//	public static void loadEtlHandleParam(){
//		//etl-ferry
//    	File fileFerry = new File(  GlobalConstants.APP_PATH + etlFerryHandlePath);
//		Map<String, Class<?>> ferryMap = new HashMap<String, Class<?>>();
//		ferryMap.put("ferryHandle", List.class);
//		ferryMap.put("ferry", EtlFerryTaskHandle.class);
//		try {
//			List<EtlFerryTaskHandle> etlFerryHandleList = XmlUtil.<List<EtlFerryTaskHandle>> xmlToObject(fileFerry, ferryMap);
//			for(EtlFerryTaskHandle etlFerryHandle:etlFerryHandleList){
//				etlFerryHandleParamMap.put(etlFerryHandle.getId(), etlFerryHandle);
//			}
//			
//		} catch (Xml2ObjectException e) {
//			logger.error("load etl-ferry.xml error", e);
//		}
//		//etl-sftp
//		File fileSftp = new File(  GlobalConstants.APP_PATH + etlSftpHandlePath);
//		Map<String, Class<?>> sftpMap = new HashMap<String, Class<?>>();
//		sftpMap.put("sftpHandle", List.class);
//		sftpMap.put("sftp", EtlSftpTaskHandle.class);
//		try {
//			List<EtlSftpTaskHandle> etlSftpHandleList = XmlUtil.<List<EtlSftpTaskHandle>> xmlToObject(fileSftp, sftpMap);
//			for(EtlSftpTaskHandle etlSftpHandle:etlSftpHandleList){
//				etlSftpHandleParamMap.put(etlSftpHandle.getId(), etlSftpHandle);
//			}
//			
//		} catch (Xml2ObjectException e) {
//			logger.error("load etl-sftp.xml error", e);
//		}
//		
//    }
//	public static void main(String[] args) {
//		loadEtlHandleParam();
//		System.err.println(JSON.toJSONString(etlFerryHandleParamMap));
//	}

}
