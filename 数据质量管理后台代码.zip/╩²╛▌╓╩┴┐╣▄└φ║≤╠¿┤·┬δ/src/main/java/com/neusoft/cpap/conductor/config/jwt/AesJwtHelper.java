package com.neusoft.cpap.conductor.config.jwt;

import java.util.Calendar;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.alibaba.fastjson.JSON;
import com.neusoft.mid.msf.auth.common.util.DateUtils;
import com.neusoft.mid.msf.auth.common.util.aes.AbstractMidAes;
import com.neusoft.mid.msf.auth.common.util.aes.SatpBase64EncDec;
import com.neusoft.mid.msf.auth.common.util.aes.SatpOracleAesUtil;
import com.neusoft.mid.msf.auth.common.util.jwt.IJWTInfo;
import com.neusoft.mid.msf.auth.common.util.jwt.JWTInfo;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;

public class AesJwtHelper {

    private static Map<String, AbstractMidAes> aesKeyMap = new ConcurrentHashMap<>();

    private static AbstractMidAes getAbstractMidAes(String aesKey) {
        AbstractMidAes midAes = aesKeyMap.get(aesKey);
        if (midAes == null) {
            synchronized (AesJwtHelper.class) {
                midAes = aesKeyMap.get(aesKey);
                if (midAes == null) {// double check lock
                    midAes = new SatpOracleAesUtil(aesKey, SatpBase64EncDec.getInstance());
                    aesKeyMap.put(aesKey, midAes);
                }
            }
        }
        return midAes;
    }

    public static void main(String[] args) throws Exception{
//        String aesKey="flzxsqcysyhljt!1";
//        AbstractMidAes midAes=new SatpOracleAesUtil(aesKey, SatpBase64EncDec.getInstance());
//        String src="王野18";
//        String encResult=midAes.aesEnc(src);
//        String correctResult="uiA2hHs2QWdzVGqGtpc2iA==";
//        System.out.println(src+":"+encResult);
//        System.out.println(encResult+":"+midAes.aesDec(encResult));
//        System.out.println("test:"+DigestUtils.md5Hex("test"));
//        System.out.println("cpap:"+DigestUtils.md5Hex("cpap"));

    }
    /**
     * 生成Token
     *
     * @param jwtInfo
     * @param aesKey
     * @return
     * @throws Exception
     */
    public static String generateToken(IJWTInfo jwtInfo, String aesKey) {
        AbstractMidAes midAes = getAbstractMidAes(aesKey);
        return midAes.aesEnc(JSON.toJSONString(jwtInfo));
    }

    /**
     * 获取token中的用户信息,同时校验是否过期
     *
     * @param token
     * @param aesKey
     * @return
     * @throws Exception
     */
    public static IJWTInfo getInfoFromToken(String token, String aesKey) throws Exception {
        JWTInfo jwtInfo = parseToken(token, aesKey);
        //去掉超时判断
        /*
        if (jwtInfo.getExpire() != null && jwtInfo.getExpire().length() > 0) {
            Calendar cal = DateUtils.parse(jwtInfo.getExpire(), DateUtils.DATE_TIME_PATTERN);
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis > cal.getTimeInMillis()) {
                throw new ExpiredJwtException(null, null, "TokenExpiredError");
            }
        }*/
        return jwtInfo;
    }

    /**
     * 获取token中的用户信息
     *
     * @param token
     * @param aesKey
     * @return
     * @throws Exception
     */
    private static JWTInfo parseToken(String token, String aesKey) {
        JWTInfo jwtInfo;
        try {
            AbstractMidAes midAes = getAbstractMidAes(aesKey);
            String json = midAes.aesDec(token);
            jwtInfo = JSON.parseObject(json, JWTInfo.class);
        } catch (Exception e) {
            throw new SignatureException("TokenParseError");
        }
        return jwtInfo;
    }
}
