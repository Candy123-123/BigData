package com.neusoft.cpap.conductor.dao.mapper;

import com.neusoft.cpap.conductor.model.EtlProcessNode;

import tk.mybatis.mapper.common.BaseMapper;

public interface EtlProcessNodeMapper extends BaseMapper<EtlProcessNode>{

}
