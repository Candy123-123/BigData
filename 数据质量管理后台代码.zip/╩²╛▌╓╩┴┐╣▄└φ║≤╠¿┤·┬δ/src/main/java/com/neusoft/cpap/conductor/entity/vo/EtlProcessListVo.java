package com.neusoft.cpap.conductor.entity.vo;

import java.util.Date;

import com.neusoft.cpap.conductor.entity.BaseVo;


public class EtlProcessListVo extends BaseVo{

	private Long processId;
	private String processCode;
	private String sliceType;
	private String sliceTypeName;
	private String isActive;
	private Date runSliceTime;
	private String runStatus;
	private String primaryGroup;
	private String secondaryGroup;
	private String isSingleImmed;
	public Long getProcessId() {
		return processId;
	}
	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	public String getProcessCode() {
		return processCode;
	}
	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}
	public String getSliceType() {
		return sliceType;
	}
	public void setSliceType(String sliceType) {
		this.sliceType = sliceType;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public Date getRunSliceTime() {
		return runSliceTime;
	}
	public void setRunSliceTime(Date runSliceTime) {
		this.runSliceTime = runSliceTime;
	}
	public String getRunStatus() {
		return runStatus;
	}
	public void setRunStatus(String runStatus) {
		this.runStatus = runStatus;
	}
	public String getPrimaryGroup() {
		return primaryGroup;
	}
	public void setPrimaryGroup(String primaryGroup) {
		this.primaryGroup = primaryGroup;
	}
	public String getSecondaryGroup() {
		return secondaryGroup;
	}
	public void setSecondaryGroup(String secondaryGroup) {
		this.secondaryGroup = secondaryGroup;
	}
	public String getIsSingleImmed() {
		return isSingleImmed;
	}
	public void setIsSingleImmed(String isSingleImmed) {
		this.isSingleImmed = isSingleImmed;
	}
	public String getSliceTypeName() {
		return sliceTypeName;
	}
	public void setSliceTypeName(String sliceTypeName) {
		this.sliceTypeName = sliceTypeName;
	}
	
	
	
}
