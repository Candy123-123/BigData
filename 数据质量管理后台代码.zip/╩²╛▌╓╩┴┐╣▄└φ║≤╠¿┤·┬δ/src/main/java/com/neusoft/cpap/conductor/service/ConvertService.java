package com.neusoft.cpap.conductor.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.neusoft.cpap.conductor.common.ActionEnum;
import com.neusoft.cpap.conductor.dao.EtlConfigDao;
import com.neusoft.cpap.conductor.entity.EtlNodeValuePo;
import com.neusoft.cpap.conductor.entity.EtlProcessGroupMapPo;
import com.neusoft.cpap.conductor.entity.EtlProcessGroupPo;
import com.neusoft.cpap.conductor.entity.EtlProcessGroups;
import com.neusoft.cpap.conductor.entity.EtlProcessNodePo;
import com.neusoft.cpap.conductor.entity.EtlProcessPo;
import com.neusoft.cpap.conductor.entity.EtlTimerJobPo;
import com.neusoft.cpap.conductor.entity.vo.EtlNodeValueVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessNodeVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessVo;
import com.neusoft.cpap.conductor.model.EtlNodeValue;
import com.neusoft.cpap.conductor.model.EtlProcess;
import com.neusoft.cpap.conductor.model.EtlProcessGroup;
import com.neusoft.cpap.conductor.model.EtlProcessGroupMap;
import com.neusoft.cpap.conductor.model.EtlProcessNode;
import com.neusoft.cpap.conductor.model.EtlTimerJob;
import com.neusoft.cpap.conductor.util.*;
import com.nokia.sai.micro.framework.util.IdUtil;

@Service
@Transactional
public class ConvertService {
	@Autowired
	private EtlConfigDao etlConfigdao;
	

	public EtlProcessPo convertVo2Po(EtlProcessVo etlProcessVo) throws InterruptedException {
		EtlProcessPo etlProcessPo=new EtlProcessPo();
		etlProcessPo.setAction(etlProcessVo.getAction());
		//EtlProcess
		EtlProcess etlProcess =new EtlProcess();
		if(etlProcessVo.getAction()== ActionEnum.add.type) {
			etlProcess.setIsActive("0");
		}
		if(etlProcessVo.getId()!=null) {
			etlProcess.setId(etlProcessVo.getId());
		}
		etlProcess.setPriority(0);
		etlProcess.setProcessCode(etlProcessVo.getProcessCode());
		etlProcess.setProcessPower(0);
		etlProcess.setProcessTemplate(etlProcessVo.getProcessTemplate());
		etlProcess.setSliceType(etlProcessVo.getSliceType());
		if(etlProcessVo.getSliceType().equals("")) {
			//设置默认值，防止单次流程保存报错
			etlProcess.setSliceType("H");
		}
		
		etlProcessPo.setEtlProcess(etlProcess);
		
		//EtlTimerJobPo
		EtlTimerJobPo etlTimerJobPo =new EtlTimerJobPo();
		etlTimerJobPo.setAction(etlProcessVo.getAction());
		EtlTimerJob etlTimerJob=new EtlTimerJob();
		if(etlProcessVo.getTimerId()!=null) {
			etlTimerJob.setId(etlProcessVo.getTimerId());
		}
		etlTimerJob.setDelayMinute(etlProcessVo.getDelayMinute());
		etlTimerJob.setDependTimerJob(etlProcessVo.getDependTimerJob());
		etlTimerJob.setExclusionProcess(etlProcessVo.getExclusionProcess());
		if(etlProcessVo.getAction()== ActionEnum.add.type) {
			etlTimerJob.setIsActive("0");
			etlTimerJob.setIsSingleImmed(etlProcessVo.getIsSingleImmed());
			etlTimerJob.setIsSingleTimer("0");
			etlTimerJob.setRunLock(0);
		}
		//如果是单次流程,处理默认值
		if(etlProcessVo.getIsSingleImmed().equals("1")) {
			etlTimerJob.setSliceType("H");
			etlTimerJob.setRunSliceTime(new Date(0));
		}else {
			String oriSliceTime=etlProcessVo.getRunSliceTime();
			if(etlProcessVo.getSliceType().equals("H")) {
				LocalDateTime tmpSliceTime=LocalDateTime.parse(oriSliceTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH"));
				etlTimerJob.setRunSliceTime(DateUtils.toDate(tmpSliceTime));
			}else if(etlProcessVo.getSliceType().equals("D")) {
				LocalDate tmpSliceTime=LocalDate.parse(oriSliceTime, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				etlTimerJob.setRunSliceTime(DateUtils.toDate(tmpSliceTime));
			}else if(etlProcessVo.getSliceType().equals("W")) {
//				int year=Integer.parseInt(oriSliceTime.substring(0, oriSliceTime.indexOf("-")));
//				int week=Integer.parseInt(oriSliceTime.substring(oriSliceTime.indexOf("-")+1));
//				Calendar c = Calendar.getInstance();
//				c.setFirstDayOfWeek(Calendar.MONDAY);
//		        c.setWeekDate(year,week,Calendar.MONDAY);
//				etlTimerJob.setRunSliceTime(c.getTime());
				LocalDate tmpSliceTime=LocalDate.parse(oriSliceTime, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				etlTimerJob.setRunSliceTime(DateUtils.toDate(tmpSliceTime));
			}else if(etlProcessVo.getSliceType().equals("M")) {
				oriSliceTime=oriSliceTime+"-01";
				LocalDate tmpSliceTime=LocalDate.parse(oriSliceTime, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				etlTimerJob.setRunSliceTime(DateUtils.toDate(tmpSliceTime));
			}else if(etlProcessVo.getSliceType().equals("Y")) {
				oriSliceTime=oriSliceTime+"-01-01";
				LocalDate tmpSliceTime=LocalDate.parse(oriSliceTime, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
				etlTimerJob.setRunSliceTime(DateUtils.toDate(tmpSliceTime));
			}else if(etlProcessVo.getSliceType().equals("F")) {
				LocalDateTime tmpSliceTime=LocalDateTime.parse(oriSliceTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
				etlTimerJob.setRunSliceTime(DateUtils.toDate(tmpSliceTime));
			}else if(etlProcessVo.getSliceType().equals("Q")) {
				LocalDateTime tmpSliceTime=LocalDateTime.parse(oriSliceTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
				etlTimerJob.setRunSliceTime(DateUtils.toDate(tmpSliceTime));
			}
			
			
			etlTimerJob.setSliceType(etlProcessVo.getSliceType());
		}
		
		
		if(etlProcessVo.getDelayMinute()==null||etlProcessVo.getDelayMinute().equals("")) {
			etlTimerJob.setDelayMinute(0);
		}
		etlTimerJobPo.setEtlTimerJob(etlTimerJob);
		etlProcessPo.setEtlTimerJobVo(etlTimerJobPo);
		
		//EtlProcessGroupMapPo
		EtlProcessGroupMapPo etlProcessGroupMapPo =new EtlProcessGroupMapPo();
		//新增map
		if(etlProcessVo.getAction()==ActionEnum.add.type) {
			etlProcessGroupMapPo.setAction(ActionEnum.add.type);
		}else {
			List<EtlProcessGroupMap> etlProcessGroupMapList=etlConfigdao.selectGroupMapByProcessId(etlProcessVo.getId());
			if(etlProcessGroupMapList!=null&&etlProcessGroupMapList.size()>0) {
				etlProcessGroupMapPo.setAction(ActionEnum.update.type);
			}else {
				etlProcessGroupMapPo.setAction(ActionEnum.add.type);
			}
		}
		
		EtlProcessGroupMap etlProcessGroupMap=new EtlProcessGroupMap();
		if(etlProcessVo.getGroupMapId()!=null) {
			etlProcessGroupMap.setId(etlProcessVo.getGroupMapId());
		}
		if(etlProcessVo.getSecondaryGroup()!=null) {
			etlProcessGroupMap.setType(2);
		}else if(etlProcessVo.getPrimaryGroup()!=null) {
			etlProcessGroupMap.setType(1);
		}
		etlProcessGroupMap.setProcessId(etlProcessVo.getId());

		//EtlProcessGroups
		EtlProcessGroups etlProcessGroups=new EtlProcessGroups();
		EtlProcessGroupPo primaryEtlProcessGroupPo=new EtlProcessGroupPo();
		EtlProcessGroupPo secondEtlProcessGroupPo=new EtlProcessGroupPo();
		etlProcessGroups.setPrimaryEtlProcessGroup(primaryEtlProcessGroupPo);
		etlProcessGroups.setSecondaryEtlProcessGroup(secondEtlProcessGroupPo);
		long secondGroupId=0;
		//查询1级分组是否存在
		List<EtlProcessGroup> primaryGroupList=etlConfigdao.selectPrimaryGroupExistsByCode(etlProcessVo.getPrimaryGroup());
		//新的1级分组
		if(primaryGroupList==null||primaryGroupList.size()==0) {
			primaryEtlProcessGroupPo.setAction(ActionEnum.add.type);
			EtlProcessGroup primaryProcessGroup=new EtlProcessGroup();
			primaryProcessGroup.setCode(etlProcessVo.getPrimaryGroup());
			primaryProcessGroup.setName(etlProcessVo.getPrimaryGroup());
			primaryProcessGroup.setStatus(1);
			primaryProcessGroup.setType(1);
			primaryProcessGroup.setId(IdUtil.nextId());
			primaryEtlProcessGroupPo.setEtlProcessGroup(primaryProcessGroup);
			
			secondEtlProcessGroupPo.setAction(ActionEnum.add.type);
			EtlProcessGroup secondaryProcessGroup=new EtlProcessGroup();
			secondaryProcessGroup.setCode(etlProcessVo.getSecondaryGroup());
			secondaryProcessGroup.setName(etlProcessVo.getSecondaryGroup());
			secondaryProcessGroup.setStatus(1);
			secondaryProcessGroup.setType(2);
			secondaryProcessGroup.setId(IdUtil.nextId());
			secondaryProcessGroup.setPid(primaryProcessGroup.getId());
			secondEtlProcessGroupPo.setEtlProcessGroup(secondaryProcessGroup);
			
			secondGroupId=secondaryProcessGroup.getId();
		}//已存在的1级分组
		else {
			primaryEtlProcessGroupPo.setAction(ActionEnum.update.type);
			EtlProcessGroup primaryEtlProcessGroup=primaryGroupList.get(0);
			List<EtlProcessGroup> secondGroupList=etlConfigdao.selectSecondaryGroupExistsByCode(etlProcessVo.getSecondaryGroup());
			if(secondGroupList==null||secondGroupList.size()==0) {//新的2级分组
				secondEtlProcessGroupPo.setAction(ActionEnum.add.type);
				EtlProcessGroup secondaryProcessGroup=new EtlProcessGroup();
				secondaryProcessGroup.setCode(etlProcessVo.getSecondaryGroup());
				secondaryProcessGroup.setName(etlProcessVo.getSecondaryGroup());
				secondaryProcessGroup.setStatus(1);
				secondaryProcessGroup.setType(2);
				secondaryProcessGroup.setId(IdUtil.nextId());
				secondaryProcessGroup.setPid(primaryEtlProcessGroup.getId());
				secondEtlProcessGroupPo.setEtlProcessGroup(secondaryProcessGroup);
				
				secondGroupId=secondaryProcessGroup.getId();
			}else {//已存在的2级分组
				for(EtlProcessGroup etlProcessGroup:secondGroupList) {
					if(etlProcessGroup.getPid().longValue()==primaryEtlProcessGroup.getId().longValue()) {
						secondEtlProcessGroupPo.setAction(ActionEnum.update.type);
						secondGroupId=etlProcessGroup.getId();
					}
				}
			}
		}
		etlProcessPo.setEtlProcessGroups(etlProcessGroups);

		etlProcessGroupMap.setGroupId(secondGroupId);
		etlProcessGroupMap.setStatus(1);
		etlProcessGroupMapPo.setEtlProcessGroupMap(etlProcessGroupMap);
		etlProcessPo.setEtlProcessGroupMapPo(etlProcessGroupMapPo);

		
		
		//List<EtlProcessNodePo>
		List<EtlProcessNodePo> etlProcessNodePoList =new ArrayList<EtlProcessNodePo>();
		for(EtlProcessNodeVo etlProcessNodeVo:etlProcessVo.getEtlProcessNodeVoList()) {
			EtlProcessNodePo etlProcessNodePo=new EtlProcessNodePo();
			if(etlProcessNodeVo.getNodeType().equals("38")
					||etlProcessNodeVo.getNodeType().equals("52")
					||etlProcessNodeVo.getNodeType().equals("53")
					||etlProcessNodeVo.getNodeType().equals("54")) {
				etlProcessNodePo.setAction(etlProcessNodeVo.getAction());
			}else {
				etlProcessNodePo.setAction(ActionEnum.none.type);
			}
			
			EtlProcessNode etlProcessNode =new EtlProcessNode();
			if(etlProcessNodeVo.getAction()== ActionEnum.add.type) {
				etlProcessNode.setIsActive("1");
				etlProcessNode.setNodePower(0);
				etlProcessNode.setPriority(0);
			}
			if(etlProcessNodeVo.getId()!=null) {
				etlProcessNode.setId(etlProcessNodeVo.getId());
			}
			etlProcessNode.setNodeCode(etlProcessNodeVo.getNodeCode());
			etlProcessNode.setNodeName(etlProcessNodeVo.getNodeName());
			etlProcessNode.setNodeType(etlProcessNodeVo.getNodeType());
			etlProcessNode.setLabel(etlProcessNodeVo.getLabel());
			etlProcessNode.setActive(etlProcessNodeVo.getActive());
			etlProcessNode.setEdit(etlProcessNodeVo.getEdit());
			etlProcessNodePo.setEtlProcessNode(etlProcessNode);
			
		    List<EtlNodeValuePo>  etlNodeValueVoList=new ArrayList<EtlNodeValuePo>();
		    Map<String,Object> etlNodeValueVo=etlProcessNodeVo.getEtlNodeValueVoList();
	    	for(String key:etlNodeValueVo.keySet()) {
	    		if(key.endsWith("_id")) {
	    			continue;
	    		}
	    		if(!key.equals("conf")) {
	    			EtlNodeValuePo etlNodeValuePo=new EtlNodeValuePo();
	    			if(etlProcessNodeVo.getNodeType().equals("38")
	    					||etlProcessNodeVo.getNodeType().equals("52")
	    					||etlProcessNodeVo.getNodeType().equals("53")
	    					||etlProcessNodeVo.getNodeType().equals("54")) {
	    				etlNodeValuePo.setAction(etlProcessNodeVo.getAction());
	    			}else {
	    				etlNodeValuePo.setAction(ActionEnum.none.type);
	    			}
			    	
			    	EtlNodeValue etlNodeValue=new EtlNodeValue();
			    	if(etlProcessNodeVo.getAction()== ActionEnum.add.type) {
			    		etlNodeValue.setIsActive("1");
			    	}
			    	if(etlNodeValueVo.get(key+"_id")!=null) {
			    		etlNodeValue.setId(Long.valueOf(etlNodeValueVo.get(key+"_id").toString()));
			    	}
			    	etlNodeValue.setKey(key);
			    	if(etlNodeValueVo.get(key)!=null) {
			    		etlNodeValue.setValue(etlNodeValueVo.get(key).toString());
			    	}
			    	
			    	etlNodeValuePo.setEtlNodeValue(etlNodeValue);
			    	etlNodeValueVoList.add(etlNodeValuePo);
	    		}else {
	    			Map<String,String> confVal=new HashMap<String,String>();
	    			List<EtlNodeValueVo> confList=(List<EtlNodeValueVo>)etlNodeValueVo.get(key);
					for(EtlNodeValueVo defNodeValue:confList) {
						confVal.put(defNodeValue.getKey(), defNodeValue.getValue());
					}
					 
	    			EtlNodeValuePo etlNodeValuePo=new EtlNodeValuePo();
	    			if(etlProcessNodeVo.getNodeType().equals("38")
	    					||etlProcessNodeVo.getNodeType().equals("52")
	    					||etlProcessNodeVo.getNodeType().equals("53")
	    					||etlProcessNodeVo.getNodeType().equals("54")) {
	    				etlNodeValuePo.setAction(etlProcessNodeVo.getAction());
	    			}else {
	    				etlNodeValuePo.setAction(ActionEnum.none.type);
	    			}
			    	EtlNodeValue etlNodeValue=new EtlNodeValue();
			    	if(etlProcessNodeVo.getAction()== ActionEnum.add.type) {
			    		etlNodeValue.setIsActive("1");
			    	}
			    	if(etlNodeValueVo.get(key+"_id")!=null) {
			    		etlNodeValue.setId(Long.valueOf(etlNodeValueVo.get(key+"_id").toString()));
			    	}
			    	etlNodeValue.setKey(key);
			    	etlNodeValue.setValue(JSON.toJSONString(confVal));
			    	etlNodeValuePo.setEtlNodeValue(etlNodeValue);
			    	etlNodeValueVoList.add(etlNodeValuePo);
	    		}
		    }
		    	
		    etlProcessNodePo.setEtlNodeValueVoList(etlNodeValueVoList);
		    etlProcessNodePoList.add(etlProcessNodePo);
		}
		etlProcessPo.setEtlProcessNodeVoList(etlProcessNodePoList);
		
		return etlProcessPo;
	}
	
	public EtlProcessVo convertPo2Vo(EtlProcessPo etlProcessPo) {
		EtlProcessVo etlProcessVo=new EtlProcessVo();
		etlProcessVo.setAction(etlProcessPo.getAction());
		etlProcessVo.setId(etlProcessPo.getEtlProcess().getId());
		etlProcessVo.setTimerId(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getId());
		etlProcessVo.setDelayMinute(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getDelayMinute());
		etlProcessVo.setDependTimerJob(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getDependTimerJob());
		etlProcessVo.setExclusionProcess(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getExclusionProcess());
		etlProcessVo.setIsSingleImmed(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getIsSingleImmed());
		etlProcessVo.setProcessCode(etlProcessPo.getEtlProcess().getProcessCode());
		etlProcessVo.setProcessTemplate(etlProcessPo.getEtlProcess().getProcessTemplate());
		etlProcessVo.setRunLock(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getRunLock());
		LocalDateTime localDateTime=DateUtils.toLocalDateTime(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getRunSliceTime());
		String sliceTimeStr="";
		if(etlProcessPo.getEtlProcess().getSliceType().equals("H")) {
			sliceTimeStr=localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH"));
		}else if(etlProcessPo.getEtlProcess().getSliceType().equals("D")) {
			sliceTimeStr=localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		}else if(etlProcessPo.getEtlProcess().getSliceType().equals("W")) {
//			Calendar c = Calendar.getInstance();
//			c.setTime(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getRunSliceTime());
//			int year=c.getWeekYear();
//			int week=c.get(Calendar.WEEK_OF_YEAR);
//			sliceTimeStr=year+"-"+week;
			sliceTimeStr=localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		}else if(etlProcessPo.getEtlProcess().getSliceType().equals("M")) {
			sliceTimeStr=localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM"));
		}else if(etlProcessPo.getEtlProcess().getSliceType().equals("Y")) {
			sliceTimeStr=localDateTime.format(DateTimeFormatter.ofPattern("yyyy"));
		}else if(etlProcessPo.getEtlProcess().getSliceType().equals("F")) {
			sliceTimeStr=localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
		}else if(etlProcessPo.getEtlProcess().getSliceType().equals("Q")) {
			sliceTimeStr=localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
		}
		etlProcessVo.setRunSliceTime(sliceTimeStr);
		etlProcessVo.setSliceType(etlProcessPo.getEtlProcess().getSliceType());
		
		if(etlProcessVo.getIsSingleImmed().equals("1")) {
			etlProcessVo.setIsActive(etlProcessPo.getEtlTimerJobVo().getEtlTimerJob().getIsActive());
		}else {
			etlProcessVo.setIsActive(etlProcessPo.getEtlProcess().getIsActive());
		}
		
		if(etlProcessPo.getEtlProcessGroupMapPo()!=null) {
			etlProcessVo.setGroupMapId(etlProcessPo.getEtlProcessGroupMapPo().getEtlProcessGroupMap().getId());
			//String primaryGroup=etlConfigdao.selectParentCodeById(etlProcessPo.getEtlProcessGroupMapPo().getEtlProcessGroupMap().getGroupId());
			//String secondaryGroup=etlConfigdao.selectGroupCodeById(etlProcessPo.getEtlProcessGroupMapPo().getEtlProcessGroupMap().getGroupId());
			String primaryGroup=etlProcessPo.getEtlProcessGroups().getPrimaryEtlProcessGroup().getEtlProcessGroup().getCode();
			String secondaryGroup=etlProcessPo.getEtlProcessGroups().getSecondaryEtlProcessGroup().getEtlProcessGroup().getCode();
			etlProcessVo.setPrimaryGroup(primaryGroup);
			etlProcessVo.setSecondaryGroup(secondaryGroup);
		}
		
		
		List<EtlProcessNodeVo> etlProcessNodeVoList=new ArrayList<EtlProcessNodeVo>();
		for(EtlProcessNodePo etlProcessNodePo:etlProcessPo.getEtlProcessNodeVoList()) {
			EtlProcessNodeVo etlProcessNodeVo=new EtlProcessNodeVo();
			etlProcessNodeVo.setAction(etlProcessNodePo.getAction());
			etlProcessNodeVo.setId(etlProcessNodePo.getEtlProcessNode().getId());
			etlProcessNodeVo.setNodeType(etlProcessNodePo.getEtlProcessNode().getNodeType());
			etlProcessNodeVo.setNodeCode(etlProcessNodePo.getEtlProcessNode().getNodeCode());
			etlProcessNodeVo.setNodeName(etlProcessNodePo.getEtlProcessNode().getNodeName());
			etlProcessNodeVo.setActive(etlProcessNodePo.getEtlProcessNode().getActive());
			etlProcessNodeVo.setEdit(etlProcessNodePo.getEtlProcessNode().getEdit());
			etlProcessNodeVo.setLabel(etlProcessNodePo.getEtlProcessNode().getLabel());
			Map<String,Object> etlNodeValueVoMap=new HashMap<String,Object>();
			for(EtlNodeValuePo etlNodeValuePo:etlProcessNodePo.getEtlNodeValueVoList()) {
				EtlNodeValue etlNodeValue=etlNodeValuePo.getEtlNodeValue();
				if(!etlNodeValue.getKey().equals("conf")) {
					if(etlProcessNodeVo.getNodeType().equals("38")
							||etlProcessNodeVo.getNodeType().equals("52")
							||etlProcessNodeVo.getNodeType().equals("53")
							||etlProcessNodeVo.getNodeType().equals("54")) {
						etlNodeValueVoMap.put(etlNodeValue.getKey(), etlNodeValue.getValue());
						etlNodeValueVoMap.put(etlNodeValue.getKey()+"_id", etlNodeValue.getId());
					}else {
						etlNodeValueVoMap.put(etlNodeValue.getKey(), etlNodeValue.getValue());
					}
					
				}else {
	    			Map<String,String> confVal=(Map<String,String>)JSON.parse(etlNodeValue.getValue());
	    			List<EtlNodeValueVo> confList=new ArrayList<EtlNodeValueVo>();
	    			for(String key:confVal.keySet()) {
	    				EtlNodeValueVo etlNodeValueVo=new EtlNodeValueVo();
	    				etlNodeValueVo.setKey(key);
	    				etlNodeValueVo.setValue(confVal.get(key));
	    				confList.add(etlNodeValueVo);
	    			}
	    			etlNodeValueVoMap.put(etlNodeValue.getKey(), confList);
	    			etlNodeValueVoMap.put(etlNodeValue.getKey()+"_id", etlNodeValue.getId());
				}
			}
			etlProcessNodeVo.setEtlNodeValueVoList(etlNodeValueVoMap);;
			etlProcessNodeVoList.add(etlProcessNodeVo);
		}
		etlProcessVo.setEtlProcessNodeVoList(etlProcessNodeVoList);
		
		return etlProcessVo;
	}

	
}