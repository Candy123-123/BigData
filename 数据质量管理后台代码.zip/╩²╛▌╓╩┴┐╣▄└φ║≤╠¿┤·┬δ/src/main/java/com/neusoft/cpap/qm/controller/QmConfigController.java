package com.neusoft.cpap.qm.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.neusoft.cpap.qm.common.GlobalConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.neusoft.cpap.qm.service.QmConfigService;
import com.neusoft.cpap.qm.vo.BaseTaskResult;
import com.neusoft.cpap.qm.vo.BasicRuleVo;
import com.neusoft.cpap.qm.vo.DataSourceVo;
import com.neusoft.cpap.qm.vo.QmSampleRatioTab;
import com.neusoft.cpap.qm.vo.QmSourceTab;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;
import com.nokia.sai.micro.framework.exception.AppException;
import org.springframework.web.client.RestTemplate;

/**
 * 数据源和配置管理部分的页面
 * @author tengh
 *
 */
@RestController
@RequestMapping("/config1")
public class QmConfigController {
	private static final Logger logger = LoggerFactory.getLogger(QmConfigController.class);
	private static final String SERVICE_NAME = "QmConfigController";
	public static final String REST_SERVICE_URI = GlobalConstants.METADATA_URL;
	@Autowired
	private QmConfigService smConfigService;
	
	/**
	 * 查询数据源配置列表信息
	 * @param request
	 * @param response
	 * @param map
	 */
	@RequestMapping(value = "/queryDataSourceList")
	public ResultEntity<PageInfo<DataSourceVo>> queryDataSourceList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryDataSourceList],map = "+JSON.toJSONString(map));
		ResultEntity<PageInfo<DataSourceVo>> result=new ResultEntity(smConfigService.queryDataSourceList(map));
		result.setStatus(true);
		return result;
	}
	
	/**
	 * 添加数据源
	 * @param dataSourceVo
	 * @return
	 */
	@RequestMapping(value = "/addDataSourceList")
	public ResultEntity addDataSourceList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".addDataSourceList],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		//查询目前数据库中的数据源的id
		PageInfo<DataSourceVo> pageinfo=  smConfigService.queryDataSourceList(new HashMap());
		List<DataSourceVo> list=pageinfo.getList();
		HashSet<String> id_result=new HashSet<>();
		for(DataSourceVo i:list) id_result.add(i.getId());
		try{

			String id_code_name=(String)map.get("id_code_name");
			String[] id_code_name_arr=id_code_name.split(",");

			String id=id_code_name_arr[0];
			JSONObject flag=new JSONObject();
			result.setStatus(true);
			if(id_result.contains(id)){
				flag.put("flag",false);
				result.setData(flag);
			}else{
				String code=id_code_name_arr[1];
				String name=id_code_name_arr[2];
				Integer type=0;

				if("null".equals(id_code_name_arr[3])||id_code_name_arr[3].isEmpty()){
					type=0;
				}else{
					type=Integer.parseInt(id_code_name_arr[3]);
				}

                String partitionTimeformate=id_code_name_arr[4];
                String partitionField=id_code_name_arr[5];
				String desc_info=(String) map.get("desc_info");
				DataSourceVo dataSourceVo=new DataSourceVo();
				dataSourceVo.setId(id);
				dataSourceVo.setCode(code);
				dataSourceVo.setDesc_info(desc_info);
				dataSourceVo.setName(name);
				dataSourceVo.setType(type);
				dataSourceVo.setPartitiontimeformate(partitionTimeformate);
				dataSourceVo.setPartitionfield(partitionField);
				flag.put("flag",true);
				result.setData(flag);
				smConfigService.addDataSourceList(dataSourceVo);
			}

		}catch(Exception e) {
			result.setStatus(false);
			result.setException(new Exception("添加失败"));;
			throw e;
		}
		return result;
	}
	
	/**
	 * 删除数据源配置
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/delDataSourceList")
	public ResultEntity delDataSourceList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".delDataSourceList],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		//ids前台传的是一个数组 toString后 是一个 [1,2,3,4]的样子
		String ids = map.get("ids").toString();
		//去除数组的前后[ ]  ids=1,2,3,4
		ids=ids.substring(1,ids.length()-1);
		// 不能删除的id  查询评估方案表中的所有数据源id
		List<String> can_not_deleteid=smConfigService.querySchemeId(map);
		StringBuffer s=new StringBuffer();
		for(String id : ids.split(", ")){
			try{
				//查询id是否在评估方案表中的数据源id中 如果有就不删除
				if(!can_not_deleteid.contains(id)){
					smConfigService.delDataSourceList(id);
				}else{
					//把不能删除的拼到字符串里
					s.append(id+" ");
				}
			} catch(Exception e) {
				result.setStatus(false);
				result.setException(new Exception(id+"删除失败"));;
				throw e;
			}
		}
		//创建一个json对象
		JSONObject j=new JSONObject();
		//把不能删除的id的字符串传给前台
		j.put("list",s.toString());
		//如果s.length==0 说明全部可以删除 返回true
		//s.length!=0 说明有一部分无法删除 返回false
		j.put("flag",s.length()==0);
		result.setData(j);
		return result;
	}
	
	/**
	 * 查询标签库左侧树
	 */
	@RequestMapping(value = "/queryMarkTreeList")
	public ResultEntity queryMarkTreeList(){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryMarkTreeList]");
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		//调用元数据系统接口
		try{
			RestTemplate restTemplate = new RestTemplate();
			Map param = new HashMap();//空参查询
			 String s = restTemplate.postForObject(REST_SERVICE_URI + "/DataQualityController/queryMarkTreeList", param,
					String.class);
			JSONObject jsobj=(JSONObject) JSONObject.parse(s);
			JSONArray jsarray=(JSONArray) jsobj.get("data");
			jsarray=mod_key(jsarray);
			result.setData(jsarray);
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	/**
	 * 修改json 的key值 id---> value
	 * 因为 jsonArray中的children也是JsonArray 所以采用递归方法
	 * @param array json数组
	 * @return 修改后的json数组
	 */
	private JSONArray mod_key(JSONArray array){
		if(array==null) return null;
		int n=array.size();
		JSONArray res=new JSONArray();
		for(int i=0;i<n;i++){
			JSONObject temp=(JSONObject)array.get(i);
			JSONObject new_obj=new JSONObject();

			//new_obj.put("pid",temp.get("pid"));
			//new_obj.put("code",temp.get("code"));
			//判断是否是最后一个节点
			if((JSONArray)temp.get("children")==null||((JSONArray) temp.get("children")).size()==0){  //是最后一个节点
				//请求数据库查询该节点的信息  map为请求参数
				Map param=new HashMap();
				param.put("tree_node",temp.get("id"));
				//调用接口查询 id code name type
				RestTemplate restTemplate = new RestTemplate();
				String dd=restTemplate.postForObject(REST_SERVICE_URI + "/DataQualityController/queryMarkerDataSource", param,
						String.class);
				//将查询到的信息转化为json对象
				JSONObject jo=(JSONObject)JSONObject.parse(dd);
				//根据json对象获取数组
				JSONArray jarr=(JSONArray) jo.get("data");
				//叶节点的孩子们
				JSONArray leaf_children=new JSONArray();
				for(int z=0;z<jarr.size();z++){
					JSONObject jjj=new JSONObject();
					//取出索引为z的元素
					JSONObject zzz=(JSONObject)jarr.get(z);
					jjj.put("value",zzz.get("id")+","+zzz.get("code")+","+zzz.get("name")+","+zzz.get("type")+","+zzz.get("partitionTimeformate")+","+zzz.get("partitionField"));
					jjj.put("label",zzz.get("name"));
					leaf_children.add(jjj);
				}

				new_obj.put("label",temp.get("label"));
				new_obj.put("children",leaf_children);
			}else{
				//不是最后一个节点
				//new_obj.put("value",temp.get("id"));
				new_obj.put("label",temp.get("label"));
				JSONArray new_obj_array=mod_key((JSONArray) temp.get("children"));
				new_obj.put("children",new_obj_array);

			}
			res.add(new_obj);

		}
		return  res;
	}
	
	/**
	 * 根据选中标签查询对应的数据源
	 */
	@RequestMapping(value = "/queryMarkerDataSource")
	public ResultEntity queryMarkerDataSource(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryMarkerDataSource],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		String tree_node = map.get("tree_node").toString();
		//调用元数据系统接口
		
		return result;
		
	}
	
	/**
	 * 标准规则左侧树
	 */
	@RequestMapping(value = "/queryStandardTreeList")
	public ResultEntity queryStandardTreeList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryStandardTreeList],map = "+JSON.toJSONString(map));
//		ResultEntity result = new ResultEntity();
//		result.setStatus(true);
//		//调用元数据系统接口
//		JSONObject obj = new JSONObject();
//		return result;
		return smConfigService.queryStandardTreeList(map);
	}
	
	
	/**
	 * 查询标准树叶子节点对应的具体的数据标准
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/queryStandardRules")
	public ResultEntity queryStandardRules(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryStandardRules],map = "+JSON.toJSONString(map));
		return smConfigService.queryStandardRules(map);
	}
	
	/**
	 * 查询基础规则库
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryBasicRuleList")
	public ResultEntity<PageInfo<BasicRuleVo>> queryBasicRuleList(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryBasicRuleList],map = "+JSON.toJSONString(map));
		ResultEntity<PageInfo<BasicRuleVo>> result = new ResultEntity(smConfigService.queryBasicRuleList(map));
		result.setStatus(true);
		return result;
	}
	
	
	public ResultEntity addCustomRule(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".addCustomRule],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		smConfigService.addCustomRule(map);
		return result;
	}
	
	public ResultEntity delCustomRule(@RequestBody Map map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".addCustomRule],map = "+JSON.toJSONString(map));
		ResultEntity result = new ResultEntity();
		result.setStatus(true);
		String []ids = map.get("ids").toString().split(",");
		for(String id : ids){
			smConfigService.delCustomRule(id);
		}
		return result;
	}
	
	/**
	 * 查询数据源
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/queryDsourceData")
	public ResultEntity<List<QmSourceTab>> queryDsourceData(@RequestBody Map<String,Object> map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".queryDsourceData],map = "+JSON.toJSONString(map));
		return new ResultEntity<List<QmSourceTab>>(smConfigService.queryDsourceData(map));
	}
	
	/**
	 * 查询抽样比例
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/querySamepleRatio")
	public ResultEntity<PageInfo<QmSampleRatioTab>> querySamepleRatio(@RequestBody Map<String,Object> map){
		logger.info("RestService was called [" + SERVICE_NAME+ ".querySamepleRatio],map = "+JSON.toJSONString(map));
		return new ResultEntity<PageInfo<QmSampleRatioTab>>(smConfigService.querySamepleRatio(map));
	}
	
	/**
	 * 保存抽样比例
	 * @param QmSampleRatioTab对象
	 * @return ResultEntity<QmSampleRatioTab>
	 * @throws AppException
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value="/saveSamepleRatio")
	public ResultEntity saveSamepleRatio(@RequestBody QmSampleRatioTab qmSampleRatioTab) throws AppException {
		logger.info("RestService was called [" + SERVICE_NAME + ".saveMdRange]");
		return smConfigService.saveSamepleRatio(qmSampleRatioTab);
	}
	
	/**
	 * 删除抽样比例
	 * @param QmSampleRatioTab对象
	 * @return ResultEntity<QmSampleRatioTab>
	 * @throws AppException
	 */
	@SuppressWarnings("rawtypes")
	@RequestMapping(value="/deleteSamepleRatio")
	public ResultEntity deleteSamepleRatio(@RequestBody List<QmSampleRatioTab> list) throws AppException {
		logger.info("RestService was called [" + SERVICE_NAME + ".deleteSamepleRatio]");
		return smConfigService.deleteSamepleRatio(list);
	}
	
}
