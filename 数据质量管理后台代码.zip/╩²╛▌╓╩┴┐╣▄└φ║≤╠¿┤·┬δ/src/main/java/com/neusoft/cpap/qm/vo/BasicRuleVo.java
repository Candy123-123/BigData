package com.neusoft.cpap.qm.vo;

import lombok.Data;

/**
 * 基础库规则
 * @author tengh
 *
 */
@Data
public class BasicRuleVo {
	private String id;//id
	private String code;//编码
	private String name;//名称
	private String desc_info;//描述
	private String timestamp;//更新时间
	private String group_id;//归属
}
