package com.neusoft.cpap.qm.service;

import java.util.List;
import java.util.Map;

import com.github.pagehelper.PageInfo;
import com.neusoft.cpap.qm.vo.BasicRuleVo;
import com.neusoft.cpap.qm.vo.DataSourceVo;
import com.neusoft.cpap.qm.vo.QmSampleRatioTab;
import com.neusoft.cpap.qm.vo.QmSourceTab;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;


public interface QmConfigService {
	public PageInfo<DataSourceVo> queryDataSourceList(Map map);
	public ResultEntity addDataSourceList(DataSourceVo dataSourceVo);
	public ResultEntity delDataSourceList(String id);
	public PageInfo<BasicRuleVo> queryBasicRuleList(Map map);
	public ResultEntity addCustomRule(Map map);
	public void delCustomRule(String id);
	
	List<QmSourceTab> queryDsourceData(Map map);
	
	@SuppressWarnings("rawtypes")
	ResultEntity saveSamepleRatio(QmSampleRatioTab qmSampleRatioTab);
	
	PageInfo<QmSampleRatioTab> querySamepleRatio(Map<String, Object> map);
	
	ResultEntity deleteSamepleRatio(List<QmSampleRatioTab> list);
	ResultEntity queryStandardTreeList(Object param);
	ResultEntity queryStandardRules(Object param);
	//查询评估方案信息表的数据源id方法
	public List querySchemeId(Map map);
}
