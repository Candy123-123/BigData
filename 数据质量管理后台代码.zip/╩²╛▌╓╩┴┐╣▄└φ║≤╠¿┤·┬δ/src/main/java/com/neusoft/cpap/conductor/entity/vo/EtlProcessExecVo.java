package com.neusoft.cpap.conductor.entity.vo;

import com.neusoft.cpap.conductor.entity.BaseVo;


public class EtlProcessExecVo extends BaseVo{

	private String processName;
	private String dataSliceTime;
	private String processInstance;
	private String startTime;
	private String endTime;
	private Integer costTime;
	private String runStatus;
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getDataSliceTime() {
		return dataSliceTime;
	}
	public void setDataSliceTime(String dataSliceTime) {
		this.dataSliceTime = dataSliceTime;
	}
	public String getProcessInstance() {
		return processInstance;
	}
	public void setProcessInstance(String processInstance) {
		this.processInstance = processInstance;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public Integer getCostTime() {
		return costTime;
	}
	public void setCostTime(Integer costTime) {
		this.costTime = costTime;
	}
	public String getRunStatus() {
		return runStatus;
	}
	public void setRunStatus(String runStatus) {
		this.runStatus = runStatus;
	}
	
	
}
