package com.neusoft.cpap.conductor.entity;

import java.util.List;

import com.neusoft.cpap.conductor.model.EtlProcessNode;

public class EtlProcessNodePo extends BaseVo{
	
	private EtlProcessNode etlProcessNode;
	
    private List<EtlNodeValuePo>  etlNodeValueVoList;

	public EtlProcessNode getEtlProcessNode() {
		return etlProcessNode;
	}

	public void setEtlProcessNode(EtlProcessNode etlProcessNode) {
		this.etlProcessNode = etlProcessNode;
	}

	public List<EtlNodeValuePo> getEtlNodeValueVoList() {
		return etlNodeValueVoList;
	}

	public void setEtlNodeValueVoList(List<EtlNodeValuePo> etlNodeValueVoList) {
		this.etlNodeValueVoList = etlNodeValueVoList;
	}

	@Override
	public String toString() {
		return "EtlProcessNodeVo [etlProcessNode=" + etlProcessNode
				+ ", etlNodeValueVoList=" + etlNodeValueVoList + "]";
	}
}
