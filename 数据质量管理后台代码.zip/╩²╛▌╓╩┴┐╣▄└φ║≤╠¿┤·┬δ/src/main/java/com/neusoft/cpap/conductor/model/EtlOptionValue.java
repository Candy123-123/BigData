package com.neusoft.cpap.conductor.model;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="ETL_OPTION_VALUE")
public class EtlOptionValue {
    private String optionCode;
    private String optionName;
    private String optionValue;
    private String optionDesc;
    private Integer optionStatus;
	public String getOptionCode() {
		return optionCode;
	}
	public void setOptionCode(String optionCode) {
		this.optionCode = optionCode;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public String getOptionValue() {
		return optionValue;
	}
	public void setOptionValue(String optionValue) {
		this.optionValue = optionValue;
	}
	public String getOptionDesc() {
		return optionDesc;
	}
	public void setOptionDesc(String optionDesc) {
		this.optionDesc = optionDesc;
	}
	public Integer getOptionStatus() {
		return optionStatus;
	}
	public void setOptionStatus(Integer optionStatus) {
		this.optionStatus = optionStatus;
	}
    
    
}
