package com.neusoft.cpap.conductor.model;


import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="ETL_TRIGGER_JOB")
public class EtlTriggerJob {
	
	@Id
	private Long id;
	private Long processId;
	private Long fileSourceId;
	private Date runSliceTime;
	private Integer delayMinute;
	private String dependJob;
	private String exclusionProcess;
	private Long timerJob;
	private String isActive;
	private Integer runLock;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getProcessId() {
		return processId;
	}
	public void setProcessId(Long processId) {
		this.processId = processId;
	}
	public Long getFileSourceId() {
		return fileSourceId;
	}
	public void setFileSourceId(Long fileSourceId) {
		this.fileSourceId = fileSourceId;
	}
	public Date getRunSliceTime() {
		return runSliceTime;
	}
	public void setRunSliceTime(Date runSliceTime) {
		this.runSliceTime = runSliceTime;
	}
	public Integer getDelayMinute() {
		return delayMinute;
	}
	public void setDelayMinute(Integer delayMinute) {
		this.delayMinute = delayMinute;
	}
	public String getDependJob() {
		return dependJob;
	}
	public void setDependJob(String dependJob) {
		this.dependJob = dependJob;
	}
	public String getExclusionProcess() {
		return exclusionProcess;
	}
	public void setExclusionProcess(String exclusionProcess) {
		this.exclusionProcess = exclusionProcess;
	}
	
	public Long getTimerJob() {
		return timerJob;
	}
	public void setTimerJob(Long timerJob) {
		this.timerJob = timerJob;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public Integer getRunLock() {
		return runLock;
	}
	public void setRunLock(Integer runLock) {
		this.runLock = runLock;
	}
	@Override
	public String toString() {
		return "EtlTriggerJob [id=" + id + ", processId=" + processId
				+ ", fileSourceId=" + fileSourceId + ", runSliceTime="
				+ runSliceTime + ", delayMinute=" + delayMinute
				+ ", dependJob=" + dependJob + ", exclusionProcess="
				+ exclusionProcess + ", timerJob=" + timerJob + ", isActive="
				+ isActive + ", runLock=" + runLock + "]";
	}
	
}
