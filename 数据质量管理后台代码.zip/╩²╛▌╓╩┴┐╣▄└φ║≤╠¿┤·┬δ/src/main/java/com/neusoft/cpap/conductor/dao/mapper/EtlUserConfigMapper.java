package com.neusoft.cpap.conductor.dao.mapper;

import com.neusoft.cpap.conductor.model.EtlUserConfig;

import tk.mybatis.mapper.common.BaseMapper;

public interface EtlUserConfigMapper extends BaseMapper<EtlUserConfig>{

}
