package com.neusoft.cpap.conductor.entity;

import com.neusoft.cpap.conductor.model.EtlProcessGroupMap;

public class EtlProcessGroupMapPo extends BaseVo{
	private EtlProcessGroupMap etlProcessGroupMap;

	public EtlProcessGroupMap getEtlProcessGroupMap() {
		return etlProcessGroupMap;
	}

	public void setEtlProcessGroupMap(EtlProcessGroupMap etlProcessGroupMap) {
		this.etlProcessGroupMap = etlProcessGroupMap;
	}
	
}
