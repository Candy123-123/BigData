package com.neusoft.cpap.conductor.model;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="ETL_PROCESS")
public class EtlProcess {
    @Id
	private Long id;
	private String processCode;
	private String processNameEn;
	private String processNameZh;
	private String processTemplate;
	private String processType;
	private String sliceType;
	private Integer priority;
	private Integer processPower;
	private String isActive;
	private String dataSource;
	private String userId;

	
	/*
	 * private int action;
	 * 
	 * public int getAction() { return action; } public void setAction(int action) {
	 * this.action = action; }
	 */
	 
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getProcessCode() {
		return processCode;
	}
	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}
	public String getProcessNameEn() {
		return processNameEn;
	}
	public void setProcessNameEn(String processNameEn) {
		this.processNameEn = processNameEn;
	}
	public String getProcessNameZh() {
		return processNameZh;
	}
	public void setProcessNameZh(String processNameZh) {
		this.processNameZh = processNameZh;
	}
	public String getProcessTemplate() {
		return processTemplate;
	}
	public void setProcessTemplate(String processTemplate) {
		this.processTemplate = processTemplate;
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getSliceType() {
		return sliceType;
	}
	public void setSliceType(String sliceType) {
		this.sliceType = sliceType;
	}
	public Integer getPriority() {
		return priority;
	}
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	public Integer getProcessPower() {
		return processPower;
	}
	public void setProcessPower(Integer processPower) {
		this.processPower = processPower;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "EtlProcess [id=" + id + ", processCode=" + processCode
				+ ", processNameEn=" + processNameEn + ", processNameZh="
				+ processNameZh + ", processTemplate=" + processTemplate
				+ ", processType=" + processType + ", sliceType=" + sliceType
				+ ", priority=" + priority + ", processPower=" + processPower
				+ ", isActive=" + isActive + ", dataSource=" + dataSource
				+ ", userId=" + userId + "]";
	}
		
	
}
