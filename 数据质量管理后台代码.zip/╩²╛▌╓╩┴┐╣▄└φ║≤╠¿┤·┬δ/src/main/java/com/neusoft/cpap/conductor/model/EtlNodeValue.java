package com.neusoft.cpap.conductor.model;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="ETL_NODE_VALUE")
public class EtlNodeValue {
	
	@Id
	private Long id;
	private Long nodeId;
	@Column(name="KEY_")
	private String key;
	@Column(name="VALUE_")
	private String value;
	private String isActive;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getNodeId() {
		return nodeId;
	}
	public void setNodeId(Long nodeId) {
		this.nodeId = nodeId;
	}			
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getIsActive() {
		return isActive;
	}
	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	@Override
	public String toString() {
		return "EtlNodeValue [id=" + id + ", nodeId=" + nodeId + ", key=" + key
				+ ", value=" + value + ", isActive=" + isActive + "]";
	}
	
	

}
