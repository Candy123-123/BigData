package com.neusoft.cpap.conductor.model;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Transient;

import com.neusoft.cpap.conductor.entity.BaseVo;

public class EtlUserConfig extends BaseVo{
	@Id
	private Long id;
	@Column(name="USER_")
	private String user;
	@Column(name="KEY_")
	private String key;
	@Column(name="VALUE_")
	private String value;
	@Transient
	private Boolean inputShow;
	@Transient
	private String keyInput;
	@Transient
	private String valueInput;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Boolean getInputShow() {
		return inputShow;
	}
	public void setInputShow(Boolean inputShow) {
		this.inputShow = inputShow;
	}
	public String getKeyInput() {
		return keyInput;
	}
	public void setKeyInput(String keyInput) {
		this.keyInput = keyInput;
	}
	public String getValueInput() {
		return valueInput;
	}
	public void setValueInput(String valueInput) {
		this.valueInput = valueInput;
	}
	@Override
	public String toString() {
		return "EtlUserConfig [id=" + id + ", user=" + user + ", key=" + key + ", value=" + value + ", inputShow="
				+ inputShow + ", keyInput=" + keyInput + ", valueInput=" + valueInput + "]";
	}

}
