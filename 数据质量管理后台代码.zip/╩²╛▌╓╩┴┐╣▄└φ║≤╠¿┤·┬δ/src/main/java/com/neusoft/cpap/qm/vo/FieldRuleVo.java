package com.neusoft.cpap.qm.vo;

import lombok.Data;

import com.alibaba.fastjson.JSONArray;

/**
 * 字段级规则关联表
 * @author tengh
 *
 */
@Data
public class FieldRuleVo {
	private String schema_id;//方案ID
	private String field;//字段编码
	private String fieldName;//字段名称
	private String[] fields;//字段编码
	private String fieldsName;
	private String id;//字段对应的规则ID
	private String ruleName;//规则名称
	private JSONArray boundRule;//规则配置详细参数
	private byte[] boundRules;
	private String params;//参数 多个值，分隔
	private String s_e_pos;//开始位置,结束位置
	private int ruleType;//规则类型 1 标准规则 2添加的规则
}
