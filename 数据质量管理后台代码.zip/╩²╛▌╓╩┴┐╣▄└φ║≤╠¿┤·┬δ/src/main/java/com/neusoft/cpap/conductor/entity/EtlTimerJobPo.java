package com.neusoft.cpap.conductor.entity;

import com.neusoft.cpap.conductor.model.EtlTimerJob;

public class EtlTimerJobPo extends BaseVo{
	
	private EtlTimerJob etlTimerJob;

	public EtlTimerJob getEtlTimerJob() {
		return etlTimerJob;
	}

	public void setEtlTimerJob(EtlTimerJob etlTimerJob) {
		this.etlTimerJob = etlTimerJob;
	}

	@Override
	public String toString() {
		return "EtlTimerJobVo [etlTimerJob=" + etlTimerJob + "]";
	}
	
	

}
