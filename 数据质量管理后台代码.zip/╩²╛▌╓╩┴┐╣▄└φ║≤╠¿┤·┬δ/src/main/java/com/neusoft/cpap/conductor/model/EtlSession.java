package com.neusoft.cpap.conductor.model;

import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="ETL_SESSION")
public class EtlSession {
	@Id
    private String token;
    private Date createTime;
    private Date updateTime;
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
    
}
