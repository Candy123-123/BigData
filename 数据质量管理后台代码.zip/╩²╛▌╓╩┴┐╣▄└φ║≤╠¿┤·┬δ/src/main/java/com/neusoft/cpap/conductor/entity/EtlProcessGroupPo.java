package com.neusoft.cpap.conductor.entity;

import com.neusoft.cpap.conductor.model.EtlProcessGroup;

public class EtlProcessGroupPo extends BaseVo{
	private EtlProcessGroup etlProcessGroup;

	public EtlProcessGroup getEtlProcessGroup() {
		return etlProcessGroup;
	}

	public void setEtlProcessGroup(EtlProcessGroup etlProcessGroup) {
		this.etlProcessGroup = etlProcessGroup;
	}

	
}
