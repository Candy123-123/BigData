package com.neusoft.cpap.qm.etl.handler;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.neusoft.cpap.qm.etl.EtlRequestParam;
@Component
public class TaskScheduleHandle extends BaseHandler{

	private String nodeType;
	@Override
	public void doExecute(EtlRequestParam etlParam, Map<String, Object> paramMap) {
		// TODO Auto-generated method stub
		etlParam.getNodeType().add(nodeType);
		Map<String,Object> ferryMap = new HashMap<String,Object>();
		ferryMap.put("ferryHostName",paramMap.get("hostname"));
		ferryMap.put("ferryPassWord", paramMap.get("password"));
		ferryMap.put("ferryUserName", paramMap.get("username"));		
		ferryMap.put("shellFile", paramMap.get("shellFile"));
		ferryMap.put("yarnAddress", paramMap.get("yarnAddress"));
		ferryMap.put("ferryTimeFormat",paramMap.get("ferryTimeFormat") );
		etlParam.getNodeValue().add(ferryMap);
	}

}
