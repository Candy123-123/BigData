package com.neusoft.cpap.conductor.entity.vo;

import java.util.Map;

import com.neusoft.cpap.conductor.entity.BaseVo;

public class EtlProcessNodeVo extends BaseVo{
	private Long id;
	private String nodeCode;
	private String nodeName;
	private String nodeType;
	private Boolean active;
	private Boolean edit;
	private String label;
	
    private Map<String,Object>  etlNodeValueVoList;

	public String getNodeCode() {
		return nodeCode;
	}

	public void setNodeCode(String nodeCode) {
		this.nodeCode = nodeCode;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public Map<String, Object> getEtlNodeValueVoList() {
		return etlNodeValueVoList;
	}

	public void setEtlNodeValueVoList(Map<String, Object> etlNodeValueVoList) {
		this.etlNodeValueVoList = etlNodeValueVoList;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Boolean getEdit() {
		return edit;
	}

	public void setEdit(Boolean edit) {
		this.edit = edit;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	@Override
	public String toString() {
		return "EtlProcessNodeVo [id=" + id + ", nodeCode=" + nodeCode + ", nodeName=" + nodeName + ", nodeType="
				+ nodeType + ", active=" + active + ", edit=" + edit + ", label=" + label + ", etlNodeValueVoList="
				+ etlNodeValueVoList + "]";
	}

}
