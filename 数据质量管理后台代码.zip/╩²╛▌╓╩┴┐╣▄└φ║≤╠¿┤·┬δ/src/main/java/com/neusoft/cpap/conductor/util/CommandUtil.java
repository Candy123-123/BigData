package com.neusoft.cpap.conductor.util;

import java.io.BufferedReader;  
import java.io.IOException;  
import java.io.InputStream;  
import java.io.InputStreamReader;  
import java.io.UnsupportedEncodingException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang.StringUtils;  

import ch.ethz.ssh2.Connection;  
import ch.ethz.ssh2.Session;  
import ch.ethz.ssh2.StreamGobbler;  

/** 
 * 远程执行linux的shell script 
 * @author Ickes 
 * @since  V0.1 
 */  
public class CommandUtil {  
    //字符编码默认是utf-8  
    private static String  DEFAULTCHART="UTF-8";  
    private Connection conn;  
    private String ip;
    private Integer port;
    private String userName;  
    private String userPwd;  
    private static int seq=0;
    
    public static String fillZeroBeforeNum(int length){
    	seq++;
		return String.format("%0"+length+"d", seq);
	}
      
    public CommandUtil(String ip, String userName, String userPwd) {  
        this.ip = ip;  
        this.userName = userName;  
        this.userPwd = userPwd;  
    }
    public CommandUtil(String ip, Integer port,String userName, String userPwd) {  
        this.ip = ip;
        this.port=port;
        this.userName = userName;  
        this.userPwd = userPwd;  
    }
      
      
    public CommandUtil() {  
          
    }  
      
    /** 
     * 远程登录linux的主机 
     * @author Ickes 
     * @since  V0.1 
     * @return 
     *      登录成功返回true，否则返回false 
     */  
    public Boolean login(){  
        boolean flg=false;  
        try { 
        	if(this.port!=null) {
        		conn = new Connection(ip,port); 
        	}else {
        		conn = new Connection(ip); 
        	}
            
            conn.connect();//连接  
            //conn.connect(null, 10000000, 10000000);
            flg=conn.authenticateWithPassword(userName, userPwd);//认证  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        return flg;  
    }

    /** 
     * @author Ickes 
     * 远程执行shll脚本或者命令 
     * @param cmd 
     *      即将执行的命令 
     * @return 
     *      命令执行完后返回的结果值 
     * @since V0.1 
     */  
    public String execute(String cmd){  
        String result="";  
        try {  
            if(login()){  
                Session session= conn.openSession();//打开一个会话  
                session.execCommand(cmd);//执行命令  
                result=processStdout(session.getStdout(),DEFAULTCHART);  
                //如果为得到标准输出为空，说明脚本执行出错了  
                if(StringUtils.isBlank(result)){  
                    result=processStdout(session.getStderr(),DEFAULTCHART);  
                }  
                conn.close();  
                session.close();  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
           
        }  
        return result;  
    }  
      
      
    /** 
     * @author Ickes 
     * 远程执行shll脚本或者命令 
     * @param cmd 
     *      即将执行的命令 
     * @return 
     *      命令执行成功后返回的结果值，如果命令执行失败，返回空字符串，不是null 
     * @since V0.1 
     */  
    /*public String executeSuccess(String cmd){  
        String result="";  
        try {  
            if(login()){  
                Session session= conn.openSession();//打开一个会话  
                session.execCommand(cmd);//执行命令  
                result=processStdout(session.getStdout(),DEFAULTCHART);
                conn.close();  
                session.close();  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        return result;  
    }*/  
    
    public String executeSuccess2(String cmd)throws Exception{  
        String result="";  
        try {  
            if(login()){  
                Session session= conn.openSession();//打开一个会话  
                session.execCommand(cmd);//执行命令  
                
                InputStream    stdout = new StreamGobbler(session.getStdout());
                InputStream    stderr = new StreamGobbler(session.getStderr());
                System.out.println("-------------任务正在执行，请等待yarn执行完成后返回结果------------");
                result=processStdout(stdout,DEFAULTCHART); 
                result+="@@@@@"+processStdout(stderr,DEFAULTCHART);
                conn.close();  
                session.close();  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
            throw e;
        }  
        return result;  
    }  
    
    public String executeSuccess3(String cmd,String processCode)throws Exception{  
        String result="";  
        InputStream    stdout=null;
        InputStream    stderr=null;
        try {  
            if(login()){  
                Session session= conn.openSession();//打开一个会话  
                session.execCommand(cmd);//执行命令  
                
                stdout = new StreamGobbler(session.getStdout());
                stderr = new StreamGobbler(session.getStderr());
                StreamGobbler gobbler=new StreamGobbler(session.getStdout());
                System.out.println("-------------任务开始执行-------------");
                
                LogResult logResult=new LogResult("stdout");
                LogResult errLogResult=new LogResult("stderr");
                LogProcessThread stdoutProcess=new LogProcessThread(stdout,Thread.currentThread().getName(),logResult,processCode);
                LogProcessThread stderrProcess=new LogProcessThread(stderr,Thread.currentThread().getName(),errLogResult,processCode);
                stdoutProcess.start();
                stderrProcess.start();

                while(true) {
                	Thread.currentThread().sleep(1000);

                	if(logResult.getStopFlag().get()&&errLogResult.getStopFlag().get()) {
                		break;
                	}
                }
                result+="stdout:"+logResult.getResult();
                result+="stderr:"+errLogResult.getResult();
                conn.close();  
                session.close();  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
            throw e;
        }  catch (InterruptedException e1) {
        	stdout.close();
    		stderr.close();
    		throw e1;
        }
        return result;  
    }
    class LogResult{
    	private String result;
    	private AtomicBoolean stopFlag=new AtomicBoolean(false);
    	private String type;
    	LogResult(String type){
    		this.type=type;
    	}
		public String getResult() {
			return result;
		}
		public void setResult(String result) {
			this.result = result;
		}
		public AtomicBoolean getStopFlag() {
			return stopFlag;
		}
		public void setStopFlag(AtomicBoolean stopFlag) {
			this.stopFlag = stopFlag;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
    }
    //日志处理线程
    class LogProcessThread extends Thread{
    	private InputStream is;
    	private String threadName;
    	private LogResult logResult;
    	private String processCode;
    	LogProcessThread(InputStream is,String threadName,LogResult logResult,String processCode){
    		this.is=is;
    		this.threadName=threadName;
    		this.logResult=logResult;
    		this.processCode=processCode;
    	}
		public void run() {
			Thread.currentThread().setName(threadName+"_"+logResult.getType());
			
			StringBuffer buffer = new StringBuffer();
	        try {  
	            BufferedReader br = new BufferedReader(new InputStreamReader(is,DEFAULTCHART));  
	            String line=null;  
	            while((line=br.readLine()) != null){
	            	System.out.println(processCode+":"+line);
	            	/*int urlIndex = line.indexOf("tracking URL:");
	            	if (urlIndex > 0) {
						String url = line.substring(urlIndex);
						String applicationId = url.substring(url.indexOf("application"));
						applicationId = applicationId.substring(0, applicationId.indexOf("/"));
						System.out.println(logResult.getType()+"##########applicationId:" + applicationId+",processCode:"+processCode);
					}*/
					
	                buffer.append(line+"\n"); 
	            }  
	        } catch (UnsupportedEncodingException e) {  
	            e.printStackTrace();  
	        } catch (IOException e) {  
	            e.printStackTrace();
	        }
	        logResult.setResult(buffer.toString());
			logResult.setStopFlag(new AtomicBoolean(true));
		}
    	
    }
   /** 
    * 解析脚本执行返回的结果集 
    * @author Ickes 
    * @param in 输入流对象 
    * @param charset 编码 
    * @since V0.1 
    * @return 
    *       以纯文本的格式返回 
    */  
    private String processStdout(InputStream in, String charset){  
        //InputStream    stdout = new StreamGobbler(in);  
        StringBuffer buffer = new StringBuffer();
        try {  
            BufferedReader br = new BufferedReader(new InputStreamReader(in,charset));  
            String line=null;  
            while((line=br.readLine()) != null){
				
                buffer.append(line+"\n"); 
            }  
        } catch (UnsupportedEncodingException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        return buffer.toString();  
    }
    private String processStdout2(InputStream in, String charset,String processCode){  
        //InputStream    stdout = new StreamGobbler(in);  
        StringBuffer buffer = new StringBuffer();
        try {  
            BufferedReader br = new BufferedReader(new InputStreamReader(in,charset));  
            String line=null;  
            while((line=br.readLine()) != null){
            	int urlIndex = line.indexOf("tracking URL:");
            	if (urlIndex > 0) {
					String url = line.substring(urlIndex);
					String applicationId = url.substring(url.indexOf("application"));
					applicationId = applicationId.substring(0, applicationId.indexOf("/"));
					System.out.println("##########applicationId:" + applicationId+",processCode:"+processCode);
				}else{
					
				}
				
                buffer.append(line+"\n"); 
            }  
        } catch (UnsupportedEncodingException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        return buffer.toString();  
    }  
      
    public static void setCharset(String charset) {  
        DEFAULTCHART = charset;  
    }  
    public Connection getConn() {  
        return conn;  
    }  
    public void setConn(Connection conn) {  
        this.conn = conn;  
    }  
    public String getIp() {  
        return ip;  
    }  
    public void setIp(String ip) {  
        this.ip = ip;  
    }  
    public String getUserName() {  
        return userName;  
    }  
    public void setUserName(String userName) {  
        this.userName = userName;  
    }  
    public String getUserPwd() {  
        return userPwd;  
    }  
    public void setUserPwd(String userPwd) {  
        this.userPwd = userPwd;  
    }
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}  
    
}  
