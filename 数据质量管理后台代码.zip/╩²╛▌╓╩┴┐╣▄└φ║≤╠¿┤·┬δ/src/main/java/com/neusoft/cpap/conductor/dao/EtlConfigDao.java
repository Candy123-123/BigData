package com.neusoft.cpap.conductor.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.neusoft.cpap.conductor.entity.EtlProcessNodeExecPo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessExecVo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessListVo;
import com.neusoft.cpap.conductor.model.EtlNodeValue;
import com.neusoft.cpap.conductor.model.EtlOptionValue;
import com.neusoft.cpap.conductor.model.EtlProcess;
import com.neusoft.cpap.conductor.model.EtlProcessGroup;
import com.neusoft.cpap.conductor.model.EtlProcessGroupMap;
import com.neusoft.cpap.conductor.model.EtlProcessNode;
import com.neusoft.cpap.conductor.model.EtlSession;
import com.neusoft.cpap.conductor.model.EtlTimerJob;
import com.neusoft.cpap.conductor.model.EtlUserConfig;
import com.nokia.sai.micro.framework.dao.BaseDao;


public interface EtlConfigDao extends BaseDao{
	
	Long selectProcessId();
	
	Integer selectProcessNameIfExists(@Param("process_code")String process_code);
	
	Map selectMaxNodeValueIdByProcessCode(Map<?,?> paramMap);
	
	Long selectMaxNodeValueIdByProcessId(@Param("id")Long id);
	
	//查询Etl任务基础信息
	List<EtlProcess> selectEtlProcess(Map<?,?> paramMap);
	
	//根据etl任务id 查询流程节点 
	List<EtlProcessNode>  selectEtlProcessNodeByProcessId(@Param("id")Long id);

	//根据流程id 查询流程节点值
	List<EtlNodeValue>  selectEtlNodeValueByNodeId(@Param("id")Long id);
	
	List<EtlNodeValue>  selectEtlNodeValue(Map<?,?> paramMap);
	
	//根据etl任务id 查询调度信息
	List<EtlTimerJob> selectEtlTimerJobByProcessId(@Param("id")Long id);
	
	List<EtlTimerJob> selectEtlTimerJobByDependId(@Param("id")Long id);
	
	List<Map> selectEtlDependByProcessId(@Param("id")Long id);
	
	List<Map> selectEtlExclusionByProcessId(@Param("id")Long id);
	
	List<Map> selectAllEtlByUserId(@Param("userId")String userId);
	
	List<Map> selectAllEtlProcessGroup();
	List<Map> selectSecondaryEtlProcessGroup(@Param("primaryCode")String primaryCode);
	
	List<EtlProcessGroup> selectPrimaryGroupExistsByCode(@Param("primaryCode")String primaryCode);
	List<EtlProcessGroup> selectSecondaryGroupExistsByCode(@Param("secondaryCode")String secondaryCode);
	List<EtlProcessGroup> selectProcessGroupById(@Param("id")Long id);
	
	List<EtlProcessListVo> selectEtlProcessListVo(Map<?,?> paramMap);
	List<EtlProcessExecVo> selectEtlProcessExecList(Map<?,?> paramMap);
	List<EtlProcessNodeExecPo> selectEtlProcessNodeExecList(Map<?,?> paramMap);
	
	List<String> selectClientLog(@Param("oid")Long oid);
	
	List<EtlUserConfig> selectUserConfigByUser(@Param("user")String user);
	
	Long selectGroupIdByCode(Map<?,?> paramMap);
	String selectGroupCodeById(@Param("id")Long id);
	String selectParentCodeById(@Param("id")Long id);
	List<EtlProcessGroupMap> selectGroupMapByProcessId(@Param("id")Long id);
	
	List<EtlOptionValue> selectEtlOptionValue(@Param("etlOptionValue")EtlOptionValue etlOptionValue);
	
	List<Map> selectUsers();
	
	List<EtlSession> selectEtlSession(@Param("token")String token);
}
