package com.neusoft.cpap.qm.etl;

import org.springframework.stereotype.Component;

import com.espertech.esper.client.hook.ConditionHandler;
import com.espertech.esper.client.hook.ConditionHandlerFactoryContext;
@Component
public class MyCEPEngineConditionHandlerFactory implements com.espertech.esper.client.hook.ConditionHandlerFactory{

	@Override
	public ConditionHandler getHandler(ConditionHandlerFactoryContext context) {
		// TODO Auto-generated method stub
		return new MyConditionHandler();
	}

}
