package com.neusoft.cpap.qm.vo;

import lombok.Data;

@Data
public class BaseTaskResult {

	private String name;//名称
	private String precent;//百分比
	private String stat_dimention;//维度名称
	private String create_time;//开始时间
	private String source_id;//数据源ID
	
	private String ratio;//正确率
	private String huanbi;//正确路环比
	
	private String correct_msg_cnt;//正确数
	private String amount;//总数
	private String hour_dimention;//时间维度
	
	
}
