package com.neusoft.cpap.qm.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.neusoft.cpap.qm.util.ExcelHeader;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExportFieldStatVo {

	@ExcelHeader(value = "字段")
	private String field_name;
	
	@ExcelHeader(value = "规则名称")
	private String rule_name;
	
	@ExcelHeader(value = "错误次数")
	private int error_msg_cnt;
	
}
