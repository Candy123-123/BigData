package com.neusoft.cpap.qm.vo;

import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "QM_SOURCE_TAB")
public class QmSourceTab {
	@Id
	private String id;
	private String name;
	private String desc_info;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc_info() {
		return desc_info;
	}
	public void setDesc_info(String desc_info) {
		this.desc_info = desc_info;
	}
	
}
