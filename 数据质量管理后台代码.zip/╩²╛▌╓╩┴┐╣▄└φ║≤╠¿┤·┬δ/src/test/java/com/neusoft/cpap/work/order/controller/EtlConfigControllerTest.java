package com.neusoft.cpap.work.order.controller;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.neusoft.cpap.conductor.entity.EtlProcessPo;
import com.neusoft.cpap.conductor.entity.vo.EtlProcessListVo;
import com.nokia.sai.micro.framework.client.entity.ResultEntity;

public class EtlConfigControllerTest {
	public static final String REST_SERVICE_URI = "http://localhost:8899/";

	//ferry任务保存测试
	@Test
	public void saveEtlProcessVo() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String param = "{\"action\":1,\"etlProcess\":{\"id\":null,\"processCode\":\"caijd_ferry\",\"processNameEn\":\"\",\"processNameZh\":\"\",\"processTemplate\":\"T1_template\",\"processType\":null,\"sliceType\":\"D\",\"priority\":0,\"processPower\":0,\"isActive\":\"0\",\"dataSource\":null,\"userId\":null},\"etlProcessNodeVoList\":[{\"action\":1,\"etlProcessNode\":{\"id\":null,\"processId\":null,\"nodeCode\":\"T1\",\"nodeName\":\"caijd_ferry\",\"nodeType\":\"38\",\"priority\":0,\"nodePower\":0,\"isActive\":\"1\"},\"etlNodeValueVoList\":[{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"hostname\",\"value\":\"10.4.66.32\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"username\",\"value\":\"cpap\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"password\",\"value\":\"cpap\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"shellFile\",\"value\":\"/home/cpap/app/meta-new/ferry/SMS_BASE_TASK_001/client.sh\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"params\",\"value\":\"{startDate:[yyyyMMdd]}\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"yarnAddress\",\"value\":\"http://hd06.neusoft.com:8088/ws/v1/cluster/apps/\",\"isActive\":\"1\"}}]}],\"etlTimerJobVo\":{\"action\":1,\"etlTimerJob\":{\"id\":null,\"processId\":null,\"sliceType\":\"D\",\"delayMinute\":0,\"runSliceTime\":null,\"dependTimerJob\":null,\"exclusionProcess\":null,\"isActive\":\"1\",\"runLock\":0,\"isSingleTimer\":\"0\",\"isSingleImmed\":\"1\"}}}";
			EtlProcessPo etlProcessVo = JSON.parseObject(param, new TypeReference<EtlProcessPo>() {
			});
			// etlProcessVo.getEtlTimerJobVo().getEtlTimerJob().setRunSliceTime(new Date());
			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/saveEtlProcessVo", etlProcessVo,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//spark任务保存测试
	@Test
	public void saveEtlProcessVoSpark() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String param = "{\"action\":1,\"etlProcess\":{\"id\":null,\"processCode\":\"caijd_spark\",\"processNameEn\":\"\",\"processNameZh\":\"\",\"processTemplate\":\"T1_template\",\"processType\":null,\"sliceType\":\"D\",\"priority\":0,\"processPower\":0,\"isActive\":\"0\",\"dataSource\":null,\"userId\":null},\"etlProcessNodeVoList\":[{\"action\":1,\"etlProcessNode\":{\"id\":null,\"processId\":null,\"nodeCode\":\"T1\",\"nodeName\":\"caijd_spark\",\"nodeType\":\"54\",\"priority\":0,\"nodePower\":0,\"isActive\":\"1\"},\"etlNodeValueVoList\":[{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"main-jar\",\"value\":\"ferry.jar\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"main-class\",\"value\":\"com.neusoft.mid.ferry.core.framework.StartUp\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"params\",\"value\":\"notebook.xml {startDate:${yyyyMMdd}}\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"files\",\"value\":\"config.zip,log4j.properties\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"master\",\"value\":\"yarn\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"deploy-mode\",\"value\":\"cluster\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"num-executors\",\"value\":\"3\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"executor-cores\",\"value\":\"4\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"executor-memory\",\"value\":\"16g\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"driver-memory\",\"value\":\"1g\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"jars\",\"value\":\"lib/ant-1.8.2.jar,lib/dom4j-1.6.1.jar,lib/gson-2.8.1.jar,lib/slf4j-api-1.7.16.jar,lib/xml-apis-1.0.b2.jar,lib/xpp3_min-1.1.4c.jar,lib/xstream-1.3.1.jar,lib/hbase-client-1.1.1.jar,lib/hbase-common-1.1.1.jar,lib/hbase-protocol-1.1.1.jar,lib/hbase-server-1.1.1.jar,lib/hive-hbase-handler-2.3.0.jar,lib/htrace-core-3.1.0-incubating.jar,lib/activemq-all-5.10.2.jar\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"conf\",\"value\":\"{'spark.executor.extraJavaOptions':'-XX:MetaspaceSize=1024m -XX:MaxMetaspaceSize=1024m -XX:+UseParNewGC -Xmn2g -XX:SurvivorRatio=3 -XX:+UseConcMarkSweepGC -XX:+UseCMSInitiatingOccupancyOnly -XX:CMSInitiatingOccupancyFraction=68 -XX:ParallelGCThreads=4 -XX:+UseCMSCompactAtFullCollection -XX:CMSFullGCsBeforeCompaction=3 -XX:SoftRefLRUPolicyMSPerMB=0 -XX:+CMSParallelRemarkEnabled -XX:+UseFastAccessorMethods -XX:+UseBiasedLocking -XX:+AggressiveOpts -XX:+UseCompressedOops -XX:+ExplicitGCInvokesConcurrent -XX:+DisableExplicitGC -XX:+AlwaysLockClassLoader'}\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"sparkPath\",\"value\":\"/home/cpap/tenant/caijd_spark\",\"isActive\":\"1\"}}]}],\"etlTimerJobVo\":{\"action\":1,\"etlTimerJob\":{\"id\":null,\"processId\":null,\"sliceType\":\"D\",\"delayMinute\":0,\"runSliceTime\":null,\"dependTimerJob\":null,\"exclusionProcess\":null,\"isActive\":\"1\",\"runLock\":0,\"isSingleTimer\":\"0\",\"isSingleImmed\":\"1\"}}}";
			EtlProcessPo etlProcessVo = JSON.parseObject(param, new TypeReference<EtlProcessPo>() {
			});
			// etlProcessVo.getEtlTimerJobVo().getEtlTimerJob().setRunSliceTime(new Date());
			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/saveEtlProcessVo", etlProcessVo,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//cmd任务保存测试
	@Test
	public void saveEtlProcessVoCmd() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String param = "{\"action\":1,\"etlProcess\":{\"id\":null,\"processCode\":\"caijd_cmd\",\"processNameEn\":\"\",\"processNameZh\":\"\",\"processTemplate\":\"T1_template\",\"processType\":null,\"sliceType\":\"D\",\"priority\":0,\"processPower\":0,\"isActive\":\"0\",\"dataSource\":null,\"userId\":null},\"etlProcessNodeVoList\":[{\"action\":1,\"etlProcessNode\":{\"id\":null,\"processId\":null,\"nodeCode\":\"T1\",\"nodeName\":\"caijd_cmd\",\"nodeType\":\"52\",\"priority\":0,\"nodePower\":0,\"isActive\":\"1\"},\"etlNodeValueVoList\":[{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"commandPath\",\"value\":\"/home/cpap/tenant/caijd_cmd\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"command\",\"value\":\"sh run.sh 20191016\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"successKeywords\",\"value\":\"OK\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"failKeywords\",\"value\":\"\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"defaultResultCode\",\"value\":\"1\",\"isActive\":\"1\"}},{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"errResultCode\",\"value\":\"1\",\"isActive\":\"1\"}}]}],\"etlTimerJobVo\":{\"action\":1,\"etlTimerJob\":{\"id\":null,\"processId\":null,\"sliceType\":\"D\",\"delayMinute\":0,\"runSliceTime\":null,\"dependTimerJob\":null,\"exclusionProcess\":null,\"isActive\":\"1\",\"runLock\":0,\"isSingleTimer\":\"0\",\"isSingleImmed\":\"1\"}}}";
			EtlProcessPo etlProcessVo = JSON.parseObject(param, new TypeReference<EtlProcessPo>() {
			});
			// etlProcessVo.getEtlTimerJobVo().getEtlTimerJob().setRunSliceTime(new Date());
			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/saveEtlProcessVo", etlProcessVo,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//sql任务保存测试
	@Test
	public void saveEtlProcessVoSql() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String param = "{\"action\":1,\"etlProcess\":{\"id\":null,\"processCode\":\"caijd_sql\",\"processNameEn\":\"\",\"processNameZh\":\"\",\"processTemplate\":\"T1_template\",\"processType\":null,\"sliceType\":\"D\",\"priority\":0,\"processPower\":0,\"isActive\":\"0\",\"dataSource\":null,\"userId\":null},\"etlProcessNodeVoList\":[{\"action\":1,\"etlProcessNode\":{\"id\":null,\"processId\":null,\"nodeCode\":\"T1\",\"nodeName\":\"caijd_sql\",\"nodeType\":\"53\",\"priority\":0,\"nodePower\":0,\"isActive\":\"1\"},\"etlNodeValueVoList\":[{\"action\":1,\"etlNodeValue\":{\"id\":null,\"nodeId\":null,\"key\":\"sql\",\"value\":\"insert into test_etl_ui.f_sms_msisdn_d_tenant_sql select day_id,msisdn,province,msisdn_brand,src_record_cnt,dst_record_cnt from default.f_sms_msisdn_d where slicetime=20191016\",\"isActive\":\"1\"}}]}],\"etlTimerJobVo\":{\"action\":1,\"etlTimerJob\":{\"id\":null,\"processId\":null,\"sliceType\":\"D\",\"delayMinute\":0,\"runSliceTime\":null,\"dependTimerJob\":null,\"exclusionProcess\":null,\"isActive\":\"1\",\"runLock\":0,\"isSingleTimer\":\"0\",\"isSingleImmed\":\"1\"}}}";
			EtlProcessPo etlProcessVo = JSON.parseObject(param, new TypeReference<EtlProcessPo>() {
			});
			// etlProcessVo.getEtlTimerJobVo().getEtlTimerJob().setRunSliceTime(new Date());
			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/saveEtlProcessVo", etlProcessVo,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//
//	// 查询流程
//	@Test
//	public void queryEtlProcessVo() throws Exception {
//		try {
//			RestTemplate restTemplate = new RestTemplate();
//			Long param = 384374435408662528L;
//			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/queryEtlProcessVo", param,
//					String.class);
//			System.out.println(result);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
	// 删除流程
	@Test
	public void deleteEtlProcessVo() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			Long param = 9112237100L;
			ParameterizedTypeReference<ResultEntity<EtlProcessPo>> typeRef = new ParameterizedTypeReference<ResultEntity<EtlProcessPo>>() {
			};
			ResponseEntity<ResultEntity<EtlProcessPo>> result = restTemplate.exchange(
					REST_SERVICE_URI + "/config/queryEtlProcessVo", HttpMethod.POST, new HttpEntity<>(param), typeRef);
			EtlProcessPo etlProcessVo = result.getBody().getData();

			String result2 = restTemplate.postForObject(REST_SERVICE_URI + "/config/delEtlProcessVo", etlProcessVo,
					String.class);
			System.out.println(result2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//
//	// 解锁流程
//	@Test
//	public void unlockEtlProcess() throws Exception {
//		try {
//			RestTemplate restTemplate = new RestTemplate();
//			Long param = 384740732260732928L;
//			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/unlockEtlProcess", param,
//					String.class);
//			System.out.println(result);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	// 开启/禁用流程
//	@Test
//	public void enableEtlProcess() throws Exception {
//		try {
//			RestTemplate restTemplate = new RestTemplate();
//			Long param = 384740732260732928L;
//			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/enableEtlProcess", param,
//					String.class);
//			System.out.println(result);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	
//	// 依赖流程
//	@Test
//	public void queryEtlProcessDepend() throws Exception {
//		try {
//			RestTemplate restTemplate = new RestTemplate();
//			Long param = 384740732260732928L;
//			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/queryEtlProcessDepend", param,
//					String.class);
//			System.out.println(result);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	@Test
//	public void queryEtlProcessVoList() throws Exception {
//		try {
//			EtlProcessListVo etlProcessListVo=new EtlProcessListVo();
//			etlProcessListVo.setIsActive(String.valueOf(1));
//			RestTemplate restTemplate = new RestTemplate();
//			MultiValueMap<String, Object> uriVariables = new LinkedMultiValueMap<>();
//			uriVariables.add("currentPage",1);
//			uriVariables.add("pageSize", 1);
//			uriVariables.add("etlProcessListVo",etlProcessListVo);
//			HttpHeaders headers = new HttpHeaders();
//	        headers.add("Content-Type", "application/json");
//	        HttpEntity<MultiValueMap<String, Object>> r = new HttpEntity<>(uriVariables, headers);
//			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/queryEtlProcessVoList",r,
//					String.class);
//			JSONObject obj=JSONObject.parseObject(result);
//			JSONArray jsons=obj.getJSONArray("data");
//			System.out.println(jsons);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	@Test
	public void upload() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
		
			 HttpHeaders headers = new HttpHeaders();
			    MediaType type = MediaType.parseMediaType("multipart/form-data");
			    // 设置请求的格式类型
			    headers.setContentType(type);
			    FileSystemResource fileSystemResource = new FileSystemResource("e:/caijd_cmd.zip");
			    MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
			    form.add("file", fileSystemResource);
			    HttpEntity<MultiValueMap<String, Object>> files = new HttpEntity<>(form, headers);
//			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/upload", files,
//					String.class);
			ResponseEntity<ResultEntity> responseResponseEntity = restTemplate.postForEntity(REST_SERVICE_URI + "/config/upload", files, ResultEntity.class);
			ResultEntity body = responseResponseEntity.getBody();
			System.out.println(body);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//查询流程列表
	@Test
	public void queryEtlProcessVoList() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			Map param = new HashMap();
			EtlProcessListVo etlProcessListVo=new EtlProcessListVo();
			etlProcessListVo.setProcessCode("test");
			param.put("etlProcessListVo", JSON.toJSONString(etlProcessListVo));
			param.put("currentPage", 2);
			param.put("pageSize", 10);

			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/queryEtlProcessVoList", param,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//查询流程执行列表
	@Test
	public void queryEtlProcessExecList() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			Map param = new HashMap();
			param.put("name", "test");
			param.put("runStatus", "1");
			param.put("dataSliceTime", "2019-12-10 00:00:00");
			param.put("startTimeMin", "2019-12-11 10:00:00");
			param.put("currentPage", 1);
			param.put("pageSize", 20);;

			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/queryEtlProcessExecList", param,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//查看调度详情
	@Test
	public void queryEtlProcessNodeExecList() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			Map param = new HashMap();
			param.put("name", "test");
			param.put("dataSliceTime", "2019-12-10 00:00:00");
			param.put("processInstance", "test_D_20191210000000_20191211161549");

			String result = restTemplate.postForObject(REST_SERVICE_URI + "/config/queryEtlProcessNodeExecList", param,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
