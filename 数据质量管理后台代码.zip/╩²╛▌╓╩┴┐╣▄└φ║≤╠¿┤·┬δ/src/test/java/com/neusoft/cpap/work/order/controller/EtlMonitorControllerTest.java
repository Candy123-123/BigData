package com.neusoft.cpap.work.order.controller;

import org.junit.Test;
import org.springframework.web.client.RestTemplate;

public class EtlMonitorControllerTest {
	public static final String REST_SERVICE_URI = "http://localhost:8899/";


	//查询spark日志
	@Test
	public void getSparkLogUrl() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String applicationId="application_1568185161096_89764";

			String result = restTemplate.postForObject(REST_SERVICE_URI + "/monitor/getSparkLogUrl", applicationId,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//查询yarn日志
	@Test
	public void getYarnLog() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String applicationId="application_1568185161096_89764";

			String result = restTemplate.postForObject(REST_SERVICE_URI + "/monitor/getYarnLog", applicationId,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//查询本地日志
	@Test
	public void getClientLog() throws Exception {
		try {
			RestTemplate restTemplate = new RestTemplate();
			Long oid=-7581790329224842346L;

			String result = restTemplate.postForObject(REST_SERVICE_URI + "/monitor/getClientLog", oid,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
