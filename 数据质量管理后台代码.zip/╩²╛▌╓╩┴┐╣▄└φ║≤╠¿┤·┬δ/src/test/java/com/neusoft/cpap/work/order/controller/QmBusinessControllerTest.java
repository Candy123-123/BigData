package com.neusoft.cpap.work.order.controller;

import java.util.Map;

import org.junit.Test;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;

public class QmBusinessControllerTest {
	public static final String REST_SERVICE_URI = "http://10.4.66.42:8899/";
	@Test
	public void querySchemaListList(){
		try {
			RestTemplate restTemplate = new RestTemplate();
			String param = "";
			Map map = JSON.parseObject(param, new TypeReference<Map>() {
			});
			// etlProcessVo.getEtlTimerJobVo().getEtlTimerJob().setRunSliceTime(new Date());
			String result = restTemplate.postForObject(REST_SERVICE_URI + "/business/querySchemaListList", map,
					String.class);
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
