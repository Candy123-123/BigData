**demo**: [https://github.com/15224986/sjt-vue-cli3](https://github.com/15224986/sjt-vue-cli3)

# To start

This is a project template for [vue-cli](https://cli.vuejs.org/zh/)

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8280
npm run serve

# build for production with minification
npm run build

```

1.0.1
