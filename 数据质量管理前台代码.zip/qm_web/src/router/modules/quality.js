export default [
    {
        path: 'sourceData',
        name: 'sourceData',
        component: () => import(/* webpackChunkName: "sourceData" */ '@/views/quality/sourceData/index'),
        meta: {
            title: "数据源管理",        // tags-view 名字
            keepAlive: true             // 是否开启缓存
        }
    },
    {
        path: 'evaluationPlan',
        name: 'evaluationPlan',
        component: () => import(/* webpackChunkName: "evaluationPlan" */ '@/views/quality/evaluationPlan/index'),
        meta: {
            title: "评估方案",
            keepAlive: true
        }
    },
	{
        path: 'assessment',
        name: 'assessment',
        component: () => import(/* webpackChunkName: "qualityReport" */ '@/views/quality/assessment/index'),
        meta: {
            title: "质量评估",
            keepAlive: true
        }
    },
    {
        path: 'standardRule',
        name: 'standardRule',
        component: () => import(/* webpackChunkName: "setConfig" */ '@/views/quality/standardRule/standard_Index'),
        meta: {
            title: "标准规则",
            keepAlive: true
        }
    },
    {
        path: 'sampleRatio',
        name: 'sampleRatio',
        component: () => import(/* webpackChunkName: "dataSource" */ '@/views/quality/sampleRatio/sample_Index'),
        meta:{
            title: "抽样比例",
            keepAlive: true,
            path: '/quality/sampleRatio'
        }
    },
    {
        path: 'assessResult',
        name: 'assessResult',
        component: () => import(/* webpackChunkName: "dataSource" */ '@/views/quality/assessResult/result_Index'),
        meta:{
            title: "质量指标",
            keepAlive: true,
            path: '/quality/assessResult'
        }
    },
	{
        path: 'basicRule',
        name: 'basicRule',
        component: () => import(/* webpackChunkName: "setConfig" */ '@/views/quality/setConfig/basicRule'),
        meta: {
            title: "基础规则",
            keepAlive: true
        }
    },
    {
        path: 'qualityReport',
        name: 'qualityReport',
        component: () => import(/* webpackChunkName: "qualityReport" */ '@/views/quality/qualityReport/index'),
        meta: {
            title: "质量报告",
            keepAlive: true
        }
    },
]
