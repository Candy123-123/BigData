<template>
    <el-container id="app">
        <el-header id="page-header">
            <div class="moc-page-logo">数据质量管理</div>
            
            <div class="moc-page-user">
                <el-avatar icon="el-icon-user-solid" shape="circle" size="small"></el-avatar>
			    <span>admin</span>
            </div>
        </el-header>
        <router-view></router-view>
    </el-container>
</template>
<script>
    // 加载资源
    export default {
        name: 'App'
    }
</script>
