import mocDialogDrag from './modules/dialogDrag'




export {
    mocDialogDrag
}
