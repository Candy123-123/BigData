<template>
    <el-container id="page-bodier">
    	<el-aside id="page-sidebar" width="auto">
            <el-menu
                :default-active="$route.path"
                class="moc-menu-vertical"
                router
            >
                <el-menu-item index="/quality/sourceData">
                    <i class="el-icon-s-order"></i>
                    <span slot="title">数据源管理</span>
                </el-menu-item>
                <el-menu-item index="/quality/evaluationPlan">
                    <i class="el-icon-s-order"></i>
                    <span slot="title">评估方案</span>
                </el-menu-item>
                <el-menu-item index="/quality/assessment">
                    <i class="el-icon-s-order"></i>
                    <span slot="title">质量评估</span>
                </el-menu-item>
                <el-menu-item index="/quality/qualityReport">
                    <i class="el-icon-s-order"></i>
                    <span slot="title">质量报告</span>
                </el-menu-item>

                <el-submenu index="0">
                    <template slot="title">
                        <i class="el-icon-s-tools"></i>
                        <span>配置管理</span>
                    </template>
                    <el-menu-item index="/quality/standardRule">
                        <span slot="title" class="p-l-md">标准规则</span>
                    </el-menu-item>
					<el-menu-item index="/quality/basicRule">
                        <span slot="title" class="p-l-md">基础规则</span>
                    </el-menu-item>
                    <el-menu-item index="/quality/sampleRatio">
                        <span slot="title" class="p-l-md">抽样比例</span>
                    </el-menu-item>
                </el-submenu>
                <el-menu-item index="/quality/assessResult">
                    <i class="el-icon-s-marketing"></i>
                    <span slot="title">质量指标</span>
                </el-menu-item>

    		</el-menu>
    	</el-aside>
        <el-main id="page-container">
            <div class="neu-tagsView-box">
                <moc-tags-view></moc-tags-view>
            </div>
            <transition name="stage-left-right" mode="out-in">
                <keep-alive>
                    <router-view :key="key" v-if="$route.meta.keepAlive"></router-view>
                </keep-alive>
            </transition>
            <transition name="stage-left-right" mode="out-in">
                <router-view :key="key" v-if="!$route.meta.keepAlive"></router-view>
            </transition>
    	</el-main>
    </el-container>
</template>
<script>


    export default {
        mixins:[],
        components: {},
        data () {
			return {

			}
        },
        computed: {
			key() {
				return this.$route.fullPath
			}
		},
        created(){
        },
        mounted(){
        },
        methods:{

        }
    }
</script>
<style lang="scss">
    /* 可以设置不同的进入和离开动画 */
    /* 设置持续时间和动画函数 */
    .stage-left-right-enter-active,
    .stage-left-right-leave-active {
        -webkit-transition: all .5s;
        transition: all .5s
    }
    .stage-left-right-enter {
        opacity: 0;
        -webkit-transform: translateX(-30px);
        transform: translateX(-30px)
    }
    .stage-left-right-leave-to {
        opacity: 0;
        -webkit-transform: translateX(30px);
        transform: translateX(30px)
    }
</style>
