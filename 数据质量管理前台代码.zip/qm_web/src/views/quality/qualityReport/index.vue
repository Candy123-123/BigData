<template>
    <moc-container id="page-content">
        <moc-section v-if="showPage==='detail'">
            <div class="qm-vice-page-title">
                <a @click="onCancel()" href="javascript:;">
                    <i class="el-icon-arrow-left"></i> {{search.value}} 数据质量报告
                </a>
            </div>
        </moc-section>
        <moc-section class="qm-search">
            <el-form :model="search" :inline="true" label-width="120px" label-suffix="：">
                <el-form-item label="数据源">
                    <p class="qm-form-text">{{content.dataSource}}</p>
                </el-form-item>
                <el-form-item label="规则错误总量">
                    <p class="qm-form-text">{{content.data1}}</p>
                </el-form-item>
                <el-form-item label="核查数据总量">
                    <p class="qm-form-text">{{content.data2}}</p>
                </el-form-item>
                <el-form-item label="问题数据总量">
                    <p class="qm-form-text">{{content.data3}}</p>
                </el-form-item>
                <el-form-item label="正确率">
                    <p class="qm-form-text">{{content.data4}}</p>
                </el-form-item>
                <el-row>
                    <el-form-item label="统计纬度" v-if="showPage==='page'">
                        <el-select v-model="search.statistical" @change="onStatisticalChange" placeholder="请选择"
                                   filterable>
                            <el-option
                                v-for="(item, index) in options.statistical"
                                :key="index"
                                :label="item.label"
                                :value="item.value"
                                :disabled="item.disabled"
                            >
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item :label="statisticalName" v-else-if="showPage==='detail'">
                        <p class="qm-form-text">{{search.value}}</p>
                    </el-form-item>
                </el-row>
            </el-form>
        </moc-section>
        <moc-section style="margin: 0 20px;">
            <el-collapse v-model="activeCollapseNames" class="qm-collapse">
                <el-collapse-item v-if="search.statistical !== '33'" title="统计纬度总览" name="1">
                    <div id="echarts-1" style="height: 360px;" class="echarts-item"></div>
                </el-collapse-item>
                <el-collapse-item title="字段统计" name="2">
                    <el-table :data="fieldTableData" border stripe>
                        <el-table-column label="序号" type="index" width="60" align="center"></el-table-column>
                        <el-table-column v-if="search.statistical !== '33' && flag==true" prop="hour_dimention"
                                         label="纬度"></el-table-column>
                        <el-table-column v-if="search.statistical !== '33' && flag==false" prop="stat_dimention"
                                         label="纬度"></el-table-column>
                        <el-table-column prop="field_name" label="字段"></el-table-column>
                        <el-table-column prop="rule_name" label="规则名称"></el-table-column>
                        <el-table-column label="错误次数">
                            <template slot-scope="scope">
                                <el-tag type="info">{{scope.row.cnt}}</el-tag>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-collapse-item>
                <el-collapse-item title="字段规则统计" name="3">
                    <el-table :data="fieldRuleTableData" border stripe>
                        <el-table-column label="序号" type="index" width="60" align="center"></el-table-column>
                        <el-table-column v-if="search.statistical !== '33' && flag==true" prop="hour_dimention"
                                         label="纬度"></el-table-column>
                        <el-table-column v-if="search.statistical !== '33' && flag==false" prop="stat_dimention"
                                         label="纬度"></el-table-column>
                        <el-table-column prop="field_name" label="字段"></el-table-column>
                        <el-table-column prop="rule_name" label="规则名称"></el-table-column>
                        <el-table-column label="错误次数">
                            <template slot-scope="scope">
                                <el-tag type="info">{{scope.row.cnt}}</el-tag>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-collapse-item>
            </el-collapse>
        </moc-section>
    </moc-container>
</template>
<script>

    /**
     * 混入对象
     */
    // 页面通用的
    import common from '@/mixins/common.js';
    import myCharts from '@/utils/myCharts.js'

    export default {
        mixins: [
            common
        ],
        data() {
            return {

                /**
                 * 请求路径
                 */
                urlManage: {
                    querySchemaTaskReportSummary: "/business/querySchemaTaskReportSummary",
                    queryTimeDimension: "/business/queryTimeDimension",
                    queryDimension: "/business/queryDimension",
                    queryHourFieldStat: "/business/queryHourFieldStat",
                    queryHourFieldAndRuleStat: "/business/queryHourFieldAndRuleStat",
                    queryFieldStat: "/business/queryFieldStat",
                    queryFieldAndRuleStat: "/business/queryFieldAndRuleStat",
                    queryNoFieldStat: "/business/queryNoFieldStat",
                    queryNoFieldAndRuleStat: "/business/queryNoFieldAndRuleStat"
                },

                flag: true,

                enumMap: [],

                showPage: 'page',
                /**
                 * 展开的 折叠面板
                 */
                activeCollapseNames: ['1', '2', '3'],
                /**
                 * 搜索条件
                 */
                statisticalName: '省份',
                search: {
                    statistical: '22',
                    value: '',
                    schema_id: '123456789',
                    slice_time: '987654321'

                },
                /**
                 * 内容
                 */
                content: {
                    dataSource: '',
                    data1: '',
                    data2: '',
                    data3: '',
                    data4: '',
                },
                /**
                 * 统计纬度总览
                 */
                statistical: {
                    legend: ["正确量", "消息总量", "正确率(%)"],
                    xAxisData: [],
                    yAxis: {
                        type: 'value',
                        axisLabel: {
                            formatter: '{value} %'
                        }
                    },
                    series: [
                        {
                            name: '正确量',
                            type: 'bar',
                            barWidth: 30,
                            markLine: {
                                data: [
                                    {type: 'average', name: '平均值'}
                                ]
                            },
                            data: []
                        },
                        {
                            name: '消息总量',
                            type: 'bar',
                            barWidth: 30,
                            data: []
                        },
                        {
                            name: '正确率(%)',
                            type: 'bar',
                            barWidth: 30,
                            data: []
                        }
                    ]
                },
                /**
                 * 字段统计
                 */
                fieldTableData: [
                    /* {
                         latitude: '北京市',
                         field: '主叫号',
                         ruleName: '主叫号规则',
                         errorNum: 515,
                     }*/
                ],
                /**
                 * 字段规则统计
                 */
                fieldRuleTableData: [
                    /* {
                         latitude: '北京市',
                         field: '主叫号',
                         ruleName: '主叫号规则',
                         errorNum: 18585,
                     }*/
                ],
                /**
                 * 下拉、单选、多选等的数据
                 */
                options: {
                    statistical: []
                },

            }
        },
        created() {
            this.initOptions();
        },
        mounted() {
            this.initData();
            this.queryDataSource();//查询数据源
        },
        methods: {

            //查询数据源
            queryDataSource() {
                let params = {...this.search};
                this.$http.post(this.urlManage.querySchemaTaskReportSummary, params).then(response => {
                    if (response.status == true) {
                        this.content.dataSource = response.data.source_name;
                        this.content.data1 = response.data.rule_msg_cnt;
                        this.content.data2 = response.data.msg_total_cnt;
                        this.content.data3 = response.data.error_msg_cnt;
                        this.content.data4 = response.data.correct_per
                    }
                }).catch(error => {
                    console.log(error);
                });
            },

            /**
             * 创建图表
             */
            createdCharts(data) {
                myCharts.makeBar("echarts-1", this.statistical, function (options) {
                }, (params) => {
                    console.log(params.name);
                    if (this.showPage === 'page') {
                        this.search.value = params.name
                        this.showPage = 'detail'
                        this.initData(params)
                    }
                });

            },

            /**
             * 初始化表格数据
             */
            initData(params) {

                if (this.showPage === 'page' && this.search.statistical == '22') {
                    //echars
                    this.$http.post(this.urlManage.queryTimeDimension, {
                        "schema_id": "111",
                        "slice_time": "任务1"
                    }).then(response => {
                        if (response.status == true) {
                            this.statistical.xAxisData = response.data.hour_dimention;
                            this.statistical.series[0].data = response.data.correct;
                            this.statistical.series[1].data = response.data.amount;
                            this.statistical.series[2].data = response.data.ratio;
                            this.$nextTick(() => {
                                this.createdCharts()
                            })
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                    //字段统计
                    this.$http.post(this.urlManage.queryHourFieldStat, {
                        "schema_id": "111",
                        "slice_time": "任务1"
                    }).then(response => {
                        if (response.status == true) {
                            this.fieldTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });

                    //字段规则统计
                    this.$http.post(this.urlManage.queryHourFieldAndRuleStat, {
                        "schema_id": "111",
                        "slice_time": "任务1"
                    }).then(response => {
                        if (response.status == true) {
                            this.fieldRuleTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                    this.flag = true;
                } else if (this.showPage === 'detail' && this.search.statistical == '22') {
                    //echars
                    this.$http.post(this.urlManage.queryDimension, {
                        "schema_id": "111",
                        "slice_time": "任务1",
                        "hour_dimention": params.name
                    }).then(response => {
                        if (response.status == true) {
                            this.statistical.xAxisData = response.data.stat_dimention;
                            this.statistical.series[0].data = response.data.correct;
                            this.statistical.series[1].data = response.data.amount;
                            this.statistical.series[2].data = response.data.ratio;
                            this.enumMap = response.data.enumMap;
                            this.$nextTick(() => {
                                this.createdCharts()
                            })
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                    //字段统计
                    this.$http.post(this.urlManage.queryFieldStat, {
                        "schema_id": "111",
                        "slice_time": "任务1",
                        "hour_dimention": params.name
                    }).then(response => {
                        if (response.status == true) {
                            this.fieldTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });

                    //字段规则统计
                    this.$http.post(this.urlManage.queryFieldAndRuleStat, {
                        "schema_id": "111",
                        "slice_time": "任务1",
                        "hour_dimention": params.name
                    }).then(response => {
                        if (response.status == true) {
                            this.fieldRuleTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                    this.flag = false;
                } else if (this.showPage === 'page' && this.search.statistical == '11') {
                    //echars
                    this.$http.post(this.urlManage.queryDimension, {
                        "schema_id": "111",
                        "slice_time": "任务1"
                    }).then(response => {
                        if (response.status == true) {
                            this.statistical.xAxisData = response.data.stat_dimention;
                            this.statistical.series[0].data = response.data.correct;
                            this.statistical.series[1].data = response.data.amount;
                            this.statistical.series[2].data = response.data.ratio;
                            this.enumMap = response.data.enumMap;
                            this.$nextTick(() => {
                                this.createdCharts()
                            })
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                    //字段统计
                    this.$http.post(this.urlManage.queryFieldStat, {"schema_id": "111", "slice_time": "任务1"}).then(response => {
                        if (response.status == true) {
                            this.fieldTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });

                    //字段规则统计
                    this.$http.post(this.urlManage.queryFieldAndRuleStat, {"schema_id": "111", "slice_time": "任务1"}).then(response => {
                        if (response.status == true) {
                            this.fieldRuleTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                    this.flag = false;
                } else if (this.showPage === 'detail' && this.search.statistical == '11') {
                    let stats = params.name.split(',');
                    let statName = "";
                    for (let i = 0; i < stats.length; i++) {
                        if (i != stats.length - 1) {
                            for (var prop in this.enumMap[i]) {
                                if (this.enumMap[i].hasOwnProperty(prop)) {
                                    if (this.enumMap[i][prop] == stats[i]){
                                        statName=statName+prop;
                                        break;
                                    } ;
                                }
                            }
                        } else {
                            for (var prop in this.enumMap[i]) {
                                if (this.enumMap[i].hasOwnProperty(prop)) {
                                    if (this.enumMap[i][prop] == stats[i]){
                                        statName=statName+prop;
                                        break;
                                    } ;
                                }
                            }
                        }
                    }
                    //echars
                    this.$http.post(this.urlManage.queryTimeDimension, {
                        "schema_id": "111",
                        "slice_time": "任务1",
                        "stat_dimention": statName
                    }).then(response => {
                        if (response.status == true) {
                            this.statistical.xAxisData = response.data.hour_dimention;
                            this.statistical.series[0].data = response.data.correct;
                            this.statistical.series[1].data = response.data.amount;
                            this.statistical.series[2].data = response.data.ratio;
                            this.$nextTick(() => {
                                this.createdCharts()
                            })
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                    //字段统计
                    this.$http.post(this.urlManage.queryHourFieldStat, {
                        "schema_id": "111",
                        "slice_time": "任务1",
                        "stat_dimention": statName
                    }).then(response => {
                        if (response.status == true) {
                            this.fieldTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });

                    //字段规则统计
                    this.$http.post(this.urlManage.queryHourFieldAndRuleStat, {
                        "schema_id": "111",
                        "slice_time": "任务1",
                        "stat_dimention": statName
                    }).then(response => {
                        if (response.status == true) {
                            this.fieldRuleTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                    this.flag = true;
                } else if (this.search.statistical == '33') {

                    //字段统计
                    this.$http.post(this.urlManage.queryNoFieldStat, {
                        "schema_id": "111",
                        "slice_time": "任务1"
                    }).then(response => {
                        if (response.status == true) {
                            this.fieldTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });

                    //字段规则统计
                    this.$http.post(this.urlManage.queryNoFieldAndRuleStat, {
                        "schema_id": "111",
                        "slice_time": "任务1"
                    }).then(response => {
                        if (response.status == true) {
                            this.fieldRuleTableData = response.data.list;
                        }
                    }).catch(error => {
                        console.log(error);
                    });
                }
            },

            /**
             * 赋值
             */
            onStatisticalChange(val) {
                for (let index = 0; index < this.options.statistical.length; index++) {
                    const element = this.options.statistical[index];
                    if (element.value == val) {
                        this.statisticalName = element.label
                        break;
                    }
                }
                this.initData();
            },
            onCancel() {
                this.showPage = 'page';
                this.initData();
            },

            /**
             * 查询分组信息
             */
            initOptions() {
                this.options.statistical = [
                    {
                        value: '11',
                        label: '省份'
                    },
                    {
                        value: '22',
                        label: '时间'
                    },
                    {
                        value: '33',
                        label: '无'
                    }
                ]
                // this.initData();
            },

        }
    }
</script>
