<template>
    <moc-container id="page-content" flex>
        <moc-section class="qm-search">
            <div>
                <el-form ref="tableRowForm" :rules="rules" label-width="80px" :model="tableRowForm"
                         class="dm-table-tools" label-suffix="：" size="mini">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="方案名称">
                                <el-select v-model="tableRowForm.filterTableName" class="neu-form-block"
                                           placeholder="请选择" filterable
                                           clearable @change="changelabel">
                                    <el-option
                                        v-for="(item,index) in dsourceData"
                                        :key="index"
                                        :value="item.NAME"
                                    >
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="执行周期">
                                <el-select v-model="tableRowForm.label" class="neu-form-block"
                                           placeholder="请选择" filterable
                                           clearable disabled="disabled">
                                    <el-option
                                        v-for="(item,index) in options.dataType"
                                        :key="index"
                                        :lable="item.value"
                                        :value="item.label"
                                    >
                                        <span style="float: left">{{ item.label }}</span>
                                        <span
                                            style="float: right; color: #8492a6; font-size: 13px">{{ item.desc }}</span>
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8" v-if="tableRowForm.label=='天'">
                            <el-form-item label="时间" prop="startTime">
                                <el-date-picker value-format=" yyyy-MM-dd" format="yyyy-MM-dd"
                                                v-model="tableRowForm.startTime" type="date"
                                                placeholder="选择日期"
                                                :picker-options="pickerOptionsStart"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8" v-if="tableRowForm.label=='天'">
                            <el-form-item label="至" prop="endTime">
                                <el-date-picker value-format=" yyyy-MM-dd" format="yyyy-MM-dd"
                                                v-model="tableRowForm.endTime" type="date" placeholder="选择日期"
                                                :picker-options="pickerOptionsEnd"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8" v-if="tableRowForm.label=='月'">
                            <el-form-item label="时间" prop="startTime_m">
                                <el-date-picker value-format=" yyyy-MM" format="yyyy-MM"
                                                v-model="tableRowForm.startTime_m" type="month"
                                                placeholder="选择月"
                                                :picker-options="pickerOptionsStart_m"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8" v-if="tableRowForm.label=='月'">
                            <el-form-item label="至" prop="endTime_m">
                                <el-date-picker value-format=" yyyy-MM" format="yyyy-MM"
                                                v-model="tableRowForm.endTime_m" type="month"
                                                placeholder="选择月" :picker-options="pickerOptionsEnd_m"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8" v-if="tableRowForm.label=='小时'">
                            <el-form-item label="至" prop="startTime_h">
                                <el-date-picker v-model="tableRowForm.startTime_h" type="datetime"
                                                format="yyyy-MM-dd HH:mm:ss" value-format="yyyy-MM-dd HH:mm:ss"
                                                placeholder="选择日期时间"
                                                :picker-options="pickerOptionsStart_h"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8" v-if="tableRowForm.label=='小时'">
                            <el-form-item label="至" prop="endTime_h">
                                <el-date-picker v-model="tableRowForm.endTime_h" type="datetime" @input="datemeStart"
                                                format="yyyy-MM-dd HH:mm:ss" value-format="yyyy-MM-dd HH:mm:ss"
                                                placeholder="选择日期时间"
                                                :picker-options="pickerOptionsStart_h"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col :span="6">
                            <el-form-item label="">
                                <el-button size="mini" type="primary"
                                           @click="onSearch('tableRowForm')"><i class="el-icon-search"></i> 查询
                                </el-button>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </div>
        </moc-section>
        <div class="dm-title" style="margin-left: -8px">数据质量正确率走势图</div>
        <div class='mychart' style="width: 100%;height: 100%" id='mychart'></div>
        <moc-section>
            <div class="dm-title" style="margin-left: -8px">方案正确率环比排名</div>
            <el-table :data="linkRatioData" border stripe tooltip-effect="light">
                <el-table-column type="index" label="序号" width="60"
                                 align="center"></el-table-column>
                <el-table-column label="方案名称" prop="name" min-width="200"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="当前数据正确率" prop="ratio" min-width="100"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="正确率环比" prop="huanbi" min-width="100" show-overflow-tooltip>
                    <template slot-scope="scope">
                        <div>
                            <div v-if="scope.row.huanbi.includes('-')">
                                <span>{{scope.row.huanbi.substring(scope.row.huanbi.lastIndexOf('-')+ 1)}}</span>
                                <span style="float: right;margin-right: 75%"><i class="el-icon-bottom"
                                                                                style="color:#ff1f1c;font-size: 15px"></i></span>
                            </div>
                            <div v-else>
                                <span>{{scope.row.huanbi}}</span>
                                <span style="float: right;margin-right: 75%"><i class="el-icon-top"
                                                                                style="color:#2cff24;font-size: 15px"></i></span>
                            </div>
                        </div>
                    </template>
                </el-table-column>
            </el-table>
        </moc-section>
        <moc-section class="qm-pagination">
            <el-pagination
                :current-page.sync="pagination.pageNum"
                :page-size.sync="pagination.pageSize"
                :page-sizes="pagesizes"
                :total="pagination.total"
                :layout="pagelayout"
                background
                @size-change="handleSizeChange"
                @current-change="handlePageChange"
            >
            </el-pagination>
        </moc-section>
    </moc-container>
</template>

<script>
    // 计算序号的公共方法
    import common from "@/mixins/common.js";
    // 加载资源
    export default {
        components: {},
        mixins: [common],
        data() {
            return {
                /**
                 * 请求路径
                 */
                urlManage: {
                    queryStatis: '/business/queryStatis',
                    queryScheme: '/business/queryScheme',
                    queryLinkRatio: '/business/queryLinkRatio'

                },
                /**
                 * 分页器相关
                 */
                pagesizes: [10, 20, 30, 50],
                pagelayout: "total, sizes, prev, pager, next, jumper",
                pagination: {
                    pageNum: 1,              // 当前页
                    pageSize: 10,     // 每页显示条目个数
                    total: 0                // 总条数
                },
                tableData: [],
                filterTableName: "",
                dsourceData: [],
                dialogVisible: false,
                tableRowForm: {
                    filterTableName: '',
                    label: '',
                    startTime: '',
                    endTime: '',
                    startTime_m: '',
                    endTime_m: '',
                    startTime_h: '',
                    endTime_h: '',
                    schema_id: ''
                },
                options: {
                    dataType: [
                        {
                            label: "小时",
                            value: '0'
                        },
                        {
                            label: "天",
                            value: '1'
                        },
                        {
                            label: "月",
                            value: '2'
                        },
                    ],
                },
                dataBase: [],
                dataName: ['维度名称'],
                dataTime: ['时间段'],
                dataMore: [{
                    'name': '维度名称',
                    'type': 'line',
                    'stack': '总量',
                    'data': [0]
                }],
                linkRatioData: [],
                rules: {
                    startTime: [{required: true, message: "请选择时间", trigger: "blur"}],
                    endTime: [{required: true, message: "请选择时间", trigger: "blur"}],
                    startTime_h: [{required: true, message: "请选择时间", trigger: "blur"}],
                    endTime_h: [{required: true, message: "请选择时间", trigger: "blur"}],
                    startTime_m: [{required: true, message: "请选择时间", trigger: "blur"}],
                    endTime_m: [{required: true, message: "请选择时间", trigger: "blur"}]
                },
                pickerOptionsStart: {
                    disabledDate: time => {
                        const endDateVal = new Date(this.tableRowForm.endTime).getTime()
                        if (endDateVal) {
                            return time.getTime() > endDateVal - 0
                        }
                    }
                },
                pickerOptionsEnd: {
                    disabledDate: time => {
                        const beginDateVal = new Date(this.tableRowForm.startTime).getTime()
                        if (beginDateVal) {
                            return time.getTime() < beginDateVal - 0
                        }
                    }
                },
                pickerOptionsStart_m: {
                    disabledDate: time => {
                        const beginDateVal = new Date(this.tableRowForm.endTime_m).getTime()
                        if (beginDateVal) {
                            return time.getTime() < beginDateVal - 0
                        }
                    }
                },
                pickerOptionsEnd_m: {
                    disabledDate: time => {
                        const beginDateVal = new Date(this.tableRowForm.startTime_m).getTime()
                        if (beginDateVal) {
                            return time.getTime() < beginDateVal - 0
                        }
                    }
                },
                pickerOptionsStart_h: {
                    disabledDate: time => {
                        const beginDateVal = new Date(this.tableRowForm.endTime_h).getTime()
                        if (beginDateVal) {
                            return time.getTime() < beginDateVal - 0
                        }
                    }
                },
                pickerOptionsEnd_h: {
                    disabledDate: time => {
                        const beginDateVal = new Date(this.tableRowForm.startTime_h).getTime()
                        if (beginDateVal) {
                            return time.getTime() < beginDateVal - 0
                        }
                    }
                },

            };
        },
        created() {

        },
        mounted() {
            this.init();
            this.queryScheme();
            this.queryLinkRatio();
        },
        computed: {},
        watch: {},
        methods: {

            //查询方案名称
            queryScheme() {
                var params = {};
                this.$http.post(this.urlManage.queryScheme, params)
                    .then(response => {
                        if (response.status == true) {
                            if (response.data == null) {
                                this.dsourceData = [];
                            } else {
                                this.dsourceData = response.data;
                            }
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            },

            //查询按钮的事件
            onSearch(formName) {
                this.$refs[formName].validate(valid => {
                    if (valid) {
                        this.queryStatis();
                    } else {
                        return false;
                    }
                })
            },

            //查询数据质量的正确率
            queryStatis() {
                let that = this;
                this.$http.post(this.urlManage.queryStatis, this.tableRowForm).then(response => {
                    that.dataName = [];
                    that.dataTime = [];
                    that.dataMore = [];
                    if (response.status == true) {
                        that.dataName = response.data.name;
                        that.dataTime = response.data.time;
                        that.dataMore = response.data.series;
                        // for (let i = 0; i < that.dataBase.length; i++) {
                        //     if (!that.dataName.includes(that.dataBase[i].stat_dimention)) {
                        //         that.dataName.push(that.dataBase[i].stat_dimention);//大连、沈阳、鞍山
                        //     }
                        //     if (!that.dataTime.includes(that.dataBase[i].create_time)) {
                        //         that.dataTime.push(that.dataBase[i].create_time);//1,2,3,4,5
                        //     }
                        // };
                        // for (let j = 0; j < that.dataName.length; j++) {
                        //     that.seriesData = [];
                        //     for (let n = 0; n < that.dataTime.length; n++) {
                        //
                        //         for (let m = 0; m < that.dataBase.length; m++) {
                        //             if (that.dataName[j] == that.dataBase[m].stat_dimention && that.dataTime[n] == that.dataBase[m].create_time) {
                        //                 that.seriesData.push(parseInt(that.dataBase[m].precent));
                        //                 break;
                        //             } else if (m == (that.dataBase.length - 1)) {
                        //                 that.seriesData.push(0);
                        //                 break;
                        //             }
                        //         }
                        //     }
                        //     that.dataMore.push({
                        //         name: that.dataName[j],
                        //         type: 'line',
                        //         stack: '总量',
                        //         data: that.seriesData
                        //     })
                        // }
                    } else {

                    }
                    that.init();
                })
                    .catch(error => {
                        console.log(error);
                    });
            },

            //折线图
            init() {
                let mychart = this.$echarts.init(document.getElementById("mychart"));
                let option = {
                    title: {
                        text: '正确率(%)',
                        textStyle: {
                            color: '#333333',
                            fontSize: 14
                        }
                    },
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {
                        data: this.dataName
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        data: this.dataTime
                    },
                    yAxis: {
                        type: 'value',
                        axisLabel: {
                            formatter: '{value} %'
                        }
                    },
                    series: this.dataMore
                };
                mychart.clear();
                mychart.setOption(option);
            },

            //选择数据源
            changelabel(value) {
                let obj = {};
                let obj2 = {};
                this.tableRowForm.startTime = '';
                this.tableRowForm.endTime = '';
                this.tableRowForm.startTime_m = '';
                this.tableRowForm.endTime_m = '';
                this.tableRowForm.startTime_h = '';
                this.tableRowForm.endTime_h = '';
                obj = this.dsourceData.find((item) => {
                    return item.NAME === value;
                });
                this.tableRowForm.schema_id = obj.SCHEMA_ID
                obj2 = this.options.dataType.find((item) => {
                    return item.value == obj.UNIT;
                });
                this.tableRowForm.label = obj2.label;
            },

            //查询方案正确率环比排名
            queryLinkRatio() {
                var tmp = {};
                var params = this.$merge({}, tmp, this.pagination);
                this.$http
                    .post(
                        this.urlManage.queryLinkRatio,
                        params
                    )
                    .then(response => {
                        if (response.status == true) {
                            if (response.data.list == null) {
                                this.linkRatioData = [];
                            } else {
                                this.linkRatioData = response.data.list;
                            }
                            this.pagination.total = Number(response.data.total);
                        } else {
                            // 弹出提示
                            this.$message({
                                showClose: true,
                                message: response.errorCode
                            });
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            },

            //正确率环比翻页
            handlePageChange(val) {
                // 当前页
                this.pagination.pageNum = val ? val : 1;
                this.queryLinkRatio();
            },

            //pagination相关事件
            handleSizeChange(val) {
                this.pagination.pageSize = val;
                this.queryLinkRatio();
            },

            //时间校验
            datemeStart(endTime_h) {
                if (this.tableRowForm.startTime_h == '') {
                    this.$message({showClose: true, message: "请先选择开始时间！"});
                    return;
                }
                let startTime = this.tableRowForm.startTime_h.substring(0, 10);
                if (endTime_h.substring(0, 10) != startTime) {
                    this.$message({showClose: true, message: "请先选择当天时间！"});
                    this.$set(this.tableRowForm, "endTime_h", null);
                    this.$forceUpdate();
                    return;
                }
            },
        }
    };
</script>
<style>

    .dm-title {
        position: relative;
        height: 40px;
        line-height: 40px;
        padding-left: 16px;
        background-color: #fff;
        position: relative;
        font-size: 15px;
        font-weight: 500;
        margin: 10px 0 0;
    }

    .dm-title:before {
        display: block;
        content: "";
        position: absolute;
        left: 9px;
        height: 16px;
        top: 13px;
        background: #0FB2EE;
        width: 3px;
    }

    .dm-panel-bodier.data-standard > div {
        height: calc(100%);
    }

    .dm-panel-bodier.data-standard .neu-table {
        height: calc(100% - 9em);
    }

    .dm-panel-bodier.data-standard .neu-table > .el-table {
        height: calc(100%);
    }

    .dm-panel-bodier.data-standard .el-table__body-wrapper {
        height: calc(100% - 4em);
        overflow-y: auto;
    }

    .neu-pagination {
        padding-bottom: 0;
    }
</style>
