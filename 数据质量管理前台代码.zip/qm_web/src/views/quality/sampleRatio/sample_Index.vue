<template>
    <moc-container id="page-content" flex>
        <moc-section class="qm-search">
            <el-form :inline="true" label-width="100px" class="dm-table-tools" label-suffix="：">
                <el-form-item label="数据源名称">
                    <el-input v-model="filterTableName" placeholder="请输入"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onSearch()"><i class="el-icon-search"></i> 搜索
                    </el-button>
                </el-form-item>
            </el-form>
        </moc-section>

        <moc-section class="qm-buttons">
            <el-button type="primary" @click="addDsource()"><i class="el-icon-circle-plus-outline"></i> 添加</el-button>
            <el-button @click="removeDsource()"><i class="el-icon-delete"></i> 删除</el-button>
        </moc-section>

        <moc-section id="project-table" bodier class="qm-table">
            <el-table :data="tableData" :height="tableHeight"
                      v-loading="tableLoading" border stripe tooltip-effect="light"
                      @selection-change="handleSelectionChange">
                <el-table-column type="selection" width="40" align="center"
                                 label-class-name="dm-table-chackbox"></el-table-column>
                <el-table-column type="index" label="序号" width="60" :index="handleIndex"
                                 align="center"></el-table-column>
                <el-table-column label="数据源名称" prop="name" min-width="200"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="抽样比例(%)" prop="ratio" min-width="100"
                                 show-overflow-tooltip></el-table-column>
                <el-table-column label="操作" width="128">
                    <template slot-scope="scope">
                        <el-link @click="editTableRow(scope.$index,scope.row)" type="primary">编辑
                        </el-link>
                    </template>
                </el-table-column>
            </el-table>
        </moc-section>

        <moc-section class="qm-pagination">
            <el-pagination
                :current-page.sync="pagination.pageNum"
                :page-size.sync="pagination.pageSize"
                :page-sizes="pagesizes"
                :total="pagination.total"
                :layout="pagelayout"
                background
                @size-change="handleSizeChange"
                @current-change="onSearch"
            >
            </el-pagination>
        </moc-section>
        <el-dialog title="抽样比例" :visible.sync="dialogVisible" width="50%" append-to-body v-mocDialogDrag>
            <el-form ref="tableRowForm" :model="tableRowForm" :rules="rules" label-width="120px" label-suffix="："
                     class="dm-dialog-form">
                <el-form-item label="数据源" prop="name">
                    <el-select v-model="tableRowForm.name" class="neu-form-block"
                               placeholder="请选择" filterable
                               clearable @change="changelabel" :disabled="flage">
                        <el-option
                            v-for="(item,index) in dsourceData"
                            :key="index"
                            :value="item.name"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="抽样比例" prop="ratio">
                    <el-input v-model="tableRowForm.ratio" placeholder="请输入">
                        <i slot="suffix" style="font-style:normal;margin-right: 10px;">%</i>
                    </el-input>
                </el-form-item>
            </el-form>
            <template #footer>
                <el-button @click="closeDialog">取 消</el-button>
                <el-button @click="saveSamepleRatio" type="primary">保 存</el-button>
            </template>
        </el-dialog>
    </moc-container>
</template>

<script>
    /**
     * 混入对象
     */
    // 页面通用的
    import common from '@/mixins/common.js';
    // 表格通用的
    import tableCommon from '@/mixins/tableCommon.js';
    // 表格数据格式化
    import tableFormatter from '@/mixins/tableFormatter.js';
    // 加载资源
    export default {
        components: {},
        mixins: [
            common,
            tableCommon,
            tableFormatter
        ],
        data() {
            return {
                /**
                 * 请求路径
                 */
                urlManage: {
                    queryDsourceData: "/config1/queryDsourceData",
                    saveSamepleRatio: "/config1/saveSamepleRatio",
                    querySamepleRatio: "/config1/querySamepleRatio",
                    deleteSamepleRatio: "/config1/deleteSamepleRatio"

                },
                /**
                 * 分页器相关
                 */
                pagesizes: [10, 20, 30, 50],
                pagelayout: "total, sizes, prev, pager, next, jumper",
                pagination: {
                    pageNum: 1,              // 当前页
                    pageSize: 10,     // 每页显示条目个数
                    total: 0                // 总条数
                },
                tableData: [],
                filterTableName: "",
                selectedRows: [],
                dsourceData: [],
                dialogVisible: false,
                flage: false,
                tableRowForm: {
                    id: "",
                    source_id: "",
                    name: "",
                    ratio: ""
                },
                source_id: "",
                rules: {
                    name: [
                        {required: true, message: "请选择数据源", trigger: "blur"}
                    ],
                    ratio: [
                        {required: true, message: "请输入抽样比例百分比", trigger: "blur"},
                        {max: 3, message: "最大长度不能超过3个字符", trigger: "blur"},
                        {
                            pattern: /^(?:0|[1-9][0-9]?|100)$/,
                            message: "输入最大值不能超过100",
                            trigger: "blur"
                        }
                    ]
                }
            };
        },
        created() {

        },
        mounted() {
            this.querySamepleRatio();
            this.queryDsourceData();
        },
        computed: {},
        watch: {},
        methods: {

            //选择数据源
            changelabel(value) {
                let obj = {};
                obj = this.dsourceData.find((item) => {
                    return item.name === value;
                });
                this.tableRowForm.source_id = obj.id;
                if (this.tableData.length > 0) {
                    for (let i = 0; i < this.tableData.length; i++) {
                        if (this.tableData[i].source_id == obj.id) {
                            this.$message({type: "warning", message: "此数据源已经添加，无需重复操作！"});
                            this.tableRowForm = {};
                            break;
                        }
                    }
                }
            },

            //关闭
            closeDialog() {
                this.$nextTick(() => {
                    this.dialogVisible = false;
                });
            },

            //添加
            addDsource() {
                this.flage = false;
                this.tableRowForm = {};
                this.$nextTick(() => {
                    this.dialogVisible = true;
                });
            },

            //保存
            saveSamepleRatio() {
                this.$refs["tableRowForm"].validate(valid => {
                        if (valid) {
                        this.$http.post(this.urlManage.saveSamepleRatio, this.tableRowForm)
                            .then(response => {
                                if (response.status == true) {
                                    this.querySamepleRatio();
                                    this.$message({type: "success", message: "保存成功！"});
                                    this.dialogVisible = false;
                                } else {
                                    this.$message({type: "warning", message: "保存失败！"});
                                }
                            });
                    }
                })
            },

            //编辑
            editTableRow(index, row) {
                this.flage = true;
                this.tableRowForm = Object.assign({}, row);
                this.dialogVisible = true;
            },

            //复选框选中事件
            handleSelectionChange(rows) {
                this.selectedRows = rows;
            },

            //删除
            removeDsource() {
                if (this.selectedRows.length > 0) {
                    this.$confirm("此操作将永久删除, 是否继续?", "系统提示", {
                        type: "warning"
                    }).then(() => {
                        this.$http.post(this.urlManage.deleteSamepleRatio, this.selectedRows).then(response => {
                            if (response.status == true) {
                                this.querySamepleRatio();
                                this.$message({type: "success", message: "删除成功！"});
                            } else {
                                this.$message({type: "success", message: "删除失败！"});
                            }
                        })
                            .catch(error => {
                                console.log(error);
                            });
                    }).catch(() => {
                    });
                } else {
                    this.$alert("请至少选择一条记录进行删除", "系统提示", {
                        confirmButtonText: "确定",
                        callback: action => {
                        }
                    });
                }
            },

            //查询数据源
            queryDsourceData() {
                let params = {name: ""};
                this.$http.post(this.urlManage.queryDsourceData, params).then(response => {
                    if (response.data.length > 0) {
                        this.dsourceData = response.data;
                    }
                })
                    .catch(error => {
                        console.log(error);
                    });
            },

            //查询按钮的事件
            onSearch(val) {
                // 当前页
                this.pagination.pageNum = val ? val : 1;
                this.querySamepleRatio();
            },

            //pagination相关事件
            handleSizeChange(val) {
                this.pagination.pageSize = val;
                this.querySamepleRatio();
            },

            //查询抽样比例
            querySamepleRatio() {
                var tmp = {
                    name: this.filterTableName
                };
                var params = this.$merge({}, tmp, this.pagination);
                this.$http
                    .post(
                        this.urlManage.querySamepleRatio,
                        params
                    )
                    .then(response => {
                        if (response.status == true) {
                            if (response.data.list == null) {
                                this.tableData = [];
                            } else {
                                this.tableData = response.data.list;
                            }
                            this.pagination.total = Number(response.data.total);
                        } else {
                            // 弹出提示
                            this.$message({
                                showClose: true,
                                message: response.errorCode
                            });
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            }
        }
    };
</script>
<style>
    .dm-panel-bodier.data-standard > div {
        height: calc(100%);
    }

    .dm-panel-bodier.data-standard .neu-table {
        height: calc(100% - 9em);
    }

    .dm-panel-bodier.data-standard .neu-table > .el-table {
        height: calc(100%);
    }

    .dm-panel-bodier.data-standard .el-table__body-wrapper {
        height: calc(100% - 4em);
        overflow-y: auto;
    }

    .neu-pagination {
        padding-bottom: 0;
    }
</style>
