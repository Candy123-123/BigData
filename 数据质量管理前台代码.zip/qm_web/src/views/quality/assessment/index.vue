<template>
  <moc-container id="page-multiple">
    <div class="topbox" v-if="showPage === 'page'">
      <div class="lettletopbox">
        <!-- oncaozuo() -->
        <el-button @click="waitbtn()" type="primary">暂停</el-button>
        <el-button @click="gobtn()" type="primary">启动</el-button>
        <el-button @click="onAdd()" type="primary">设置执行周期</el-button>
      </div>

      <!-- 查询 -->
      <div class="chaxunbox">
        <el-form :model="search" :inline="true" label-suffix="：">
          <el-form-item label="方案名称" label-size="15px">
            <el-input clearable placeholder="方案名称" v-model="task_name"></el-input>
          </el-form-item>
          <el-form-item label="任务状态" label-size="15px">
            <el-select v-model="value" placeholder="请选择">
              <el-option
                v-for="item in options1"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item class="qm-search-btns">
            <el-button @click="querySchemaTaskList()" type="primary"
              >查询</el-button
            >
          </el-form-item>
        </el-form>
      </div>
    </div>
    <moc-container v-if="showPage === 'page'" flex horizontal id="page-content">
      <!-- 左边选择框 -->
      <dm-group-tree
        :groupTree="groupTree"
        title="分组"
        ref="qmGroupTree"
        treeType="tag"
        nodeTools
        appendRoot
        :removeNode="false"
        :renameNode="false"
        :appendChild="false"
        :default-expanded-keys="['root']"
        @tree-node-click="treeNodeClick"
        @tree-node-deleted="treeNodeDeleted"
        @add-append-node="addAppendNode"
        style="height: 85%"
      ></dm-group-tree>
      <moc-section bodier>
        <moc-container flex id="page-wrap">
          <moc-section id="project-table" bodier class="qm-table">
            <el-table
              :data="tableData"
              :height="tableHeight"
              v-loading="tableLoading"
              border
              stripe
              @selection-change="handleSelectedRows"
            >
              <el-table-column
                type="selection"
                width="50"
                align="center"
              ></el-table-column>
              <el-table-column
                label="序号"
                type="index"
                :width="tableIndexWidth"
                align="center"
              ></el-table-column>
              <el-table-column
                label="方案名称"
                prop="name"
                width="186"
              ></el-table-column>
              <el-table-column
                label="状态"
                prop="status"
                width="112"
              ></el-table-column>
              <el-table-column
                label="最后一次评估时间"
                prop="finish_time"
                width="112"
              ></el-table-column>
              <el-table-column
                label="耗时"
                prop="address"
                min-width="256"
              ></el-table-column>
              <el-table-column
                label="执行周期"
                prop="address"
                min-width="256"
              ></el-table-column>
              <el-table-column
                label="最后一次评估下详细"
                prop="address"
                min-width="256"
              ></el-table-column>
              <el-table-column label="操作" width="128">
                <template slot-scope="scope">
                  <el-link
                    @click="editTableRow(scope.$index, scope.row)"
                    type="primary"
                    >查看结果
                  </el-link>
                </template>
              </el-table-column>
            </el-table>
          </moc-section>
          <moc-section class="qm-pagination">
            <el-pagination
              :current-page.sync="pagination.current"
              :page-size.sync="pagination.size"
              @current-change="initTableData()"
              @size-change="initTableData()"
              :total="pagination.total"
              :layout="$global.paginationLayout"
              :page-sizes="$global.paginationSizes"
              background
            >
            </el-pagination>
          </moc-section>
        </moc-container>
      </moc-section>
    </moc-container>

    <viceForm
      :selectId="id"
      :selectName="name"
      @after-callback="formCallback"
      v-if="showPage === 'form'"
    ></viceForm>
    <viceForma
      @after-callback="formCallback"
      v-if="showPage === 'form1'"
    ></viceForma>
  </moc-container>
</template>
<script>
/**
 * 混入对象
 */
// 页面通用的
import common from "@/mixins/common.js";
// 表格通用的
import tableCommon from "@/mixins/tableCommon.js";
// 表格数据格式化
import tableFormatter from "@/mixins/tableFormatter.js";

export default {
  mixins: [common, tableCommon, tableFormatter],
  components: {
    viceForm: () => import("./form.vue"),
    viceForma: () => import("./form1.vue"),
    dmGroupTree: () => import("@/views/components/group-tree/main.vue"),
  },
  data() {
    return {
      //序号
      handleIndex: null,
      groupId: "",

      urlManage: {
        querySchemaTaskList: "/business/querySchemaTaskList",
      },
      task_name:"", 
      showPage: "page",
      /**
       * 左侧菜单树
       */
      groupTree: [
        {
          id: "root",
          label: "全部",
          children: [],
        },
      ],

      /**
       * 分页器相关
       */
      pagesizes: [10, 20, 30, 50],
      pagelayout: "total, sizes, prev, pager, next, jumper",
      pagination: {
        pageNum: 1, // 当前页
        pageSize: 10, // 每页显示条目个数
        total: 0, // 总条数
      },

      alertbox: true,
      /**
       * 搜索条件
       */
      search: {
        groupId: "11",
        name: "1",
      },
      /**
       * 表格相关数据
       */
      tableData: [],
      tableTotal: 0,
      selectedRows: [],


      // 查询下拉选项
      options1: [
        {
          label: "未执行",
          value: 0,
        },
        {
          label: "执行中",
          value: 1,
        },
        {
          label: "执行成功",
          value: 2,
        },
        {
          label: "执行失败",
          value: 3,
        },
        {
          label: "暂停",
          value: 4,
        },
        {
          label: "启动",
          value: 5,
        },
      ],

      value: "",

      /**
       * 下拉、单选、多选等的数据
       */
      options: {},

      id:'',
      name:""
    };
  },
  created() {
    this.initGroupList();
  },
  mounted() {},
  methods: {
    /**
     * 查询分组信息
     */
    initGroupList() {
      this.$http.post("/business/queryGroupList").then((res) => {
        this.groupTree[0].children = res.data;
        console.log(this.handleIndex);
        this.initTableData();
      });
    },
    waitbtn(){

    },
    gobtn(){

    },
    //初始化列表查询
    querySchemaTaskList() {
      let tmp = { groupId: this.groupId };
      var params = this.$merge({}, tmp, this.pagination);
      this.$http
        .post(this.urlManage.querySchemaTaskList, params)
        .then((response) => {
          this.tableData = response.data.list;
        })
        .catch((error) => {
          console.log(error);
        });
    },

    onAdd() {
      this.showPage = "form";
      

    },

    oncaozuo() {
      this.showPage = "form1";
    },
    formCallback() {
      this.showPage = "page";
    },
    /**
     * 左侧树点击事件
     */
    treeNodeClick(data) {
      this.groupId = data.id;
      this.$nextTick(() => {
        this.querySchemaTaskList();
      });
    },
    treeNodeDeleted(data) {},
    treeNodeRename(data) {},

    /**
     * 搜索事件
     */
    onSearch() {
      this.pagination.current = 1;
    },
    /**
     * table 的相关事件
     */
    handleSelectedRows(rows) {
      this.id = rows[0].schema_id;
      this.name= rows[0].name
    },
    /**
     * 下拉框 options 的数据
     */
    initOptions() {
      /**
       * 模拟请求数据
       */
      this.$http.post("/group/querySchemaTaskList").then((res) => {
        console.log(res);
      });
    },
    /**
     * 初始化表格数据
     */
    initTableData() {
      let params = { ...this.search, ...this.pagination };

      // this.$http.get(`/mock/tableData`, params).then( res => {
      //     this.tableData = res.table;
      //     this.tableTotal = res.total;
      // })
      // .catch( error => {
      //     this.$message(error);
      // });
    },
  },
};
</script>
<style scoped>
.leftbox {
  width: 18vw;
  /* padding-top: 20px; */
  border-color: gray;
}

.topbox {
  margin-top: 10px;
  margin-left: 10px;
}

.chaxunbox {
  margin-top: 10px;
}

#page-wrap {
  padding: 0px 10px;
  height: calc(100% - 40px);
}

.alertbox {
  position: fixed;
  float: left;
  z-index: 100;
  width: 500px;
  height: 50vh;
  margin-left: 22vw;
  background-color: rgb(255, 255, 255);
  box-shadow: darkgrey 10px 10px 30px 5px;
  padding: 10px;
  border-color: rgba(141, 141, 141, 0.781);
}
</style>
