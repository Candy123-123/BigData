<template>
  <moc-container id="page-content">
    <moc-section>
      <div class="qm-vice-page-title">
        <a @click="onCancel()" href="javascript:;">
          <i class="el-icon-arrow-left"></i>评估方案的结果
        </a>
      </div>
    </moc-section>
    <moc-section class="qm-form">
     <el-table
      :data="tableData"
      style="width: 100%">
      <el-table-column
        prop="date"
        label="日期"
        width="180">
      </el-table-column>
      <el-table-column
        prop="name"
        label="姓名"
        width="180">
      </el-table-column>
      <el-table-column
        prop="address"
        label="地址">
      </el-table-column>
    </el-table>
    </moc-section>
  </moc-container>
</template>
<script>
/**
 * 混入对象
 */
import common from "@/mixins/common.js"; // 通用  每个页面都需要引入

export default {
  mixins: [common],
  data() {
    return {
          tableData: [{
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1518 弄'
          }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1517 弄'
          }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }]
    };
  },
  computed: {},
  created() {},
  mounted() {
    // this.initOptions();
  },

  methods: {
    removeTableRow() {},
    selectOptions() {},
    /**
     * 确定、取消
     */
    onSubmit(formName) {
      // this.$refs[formName].validate((valid) => {
      //     if (valid) {
      //         this.$emit('after-callback', true);
      //     } else {
      //         console.log('error submit!!');
      //         return false;
      //     }
      // });
    },
    onCancel() {
      this.$emit("after-callback", false);
    },
  },
};
</script>
<style scoped>
.inputbox {
  outline-style: none;
  width: 320px;
  font-family: "Microsoft soft";
  height: 32px;
  line-height: 32px;
  padding-right: 30px;

  background-color: #ffffff;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  box-sizing: border-box;
  color: #606266;
  font-size: inherit;
  padding: 0 15px;
}
.inputbox:hover {
  border-color: #c0c4cc;
}
.inputbox:focus {
  outline: none;
  border-color: #409eff;
}
.btnbox{
    margin-left: 320px;
    margin-top: 40px;
}
</style>