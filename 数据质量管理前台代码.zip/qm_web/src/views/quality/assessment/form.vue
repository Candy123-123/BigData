<template>
  <moc-container id="page-content">
    <moc-section>
      <div class="qm-vice-page-title">
        <a @click="onCancel()" href="javascript:;">
          <i class="el-icon-arrow-left"></i>设定执行周期
        </a>
      </div>
    </moc-section>

    <moc-section class="qm-form">
      <el-form
        :rules="rules"
        :model="newForm"
        ref="newForm"
        label-width="100px"
        class="qm-form-horizontal"
        label-suffix="："
      >
        <div class="m-b-sm">
          <div class="qm-search-item">
            <el-form-item label="方案名称" disabled prop="idValue" label-size="15px">
              <el-input
                clearable
                placeholder="预评方案"
                v-model="idValue"
              ></el-input>
            </el-form-item>
            <el-form-item label="执行方式" prop="radio" label-size="15px">
              <el-radio v-model="newForm.radio" label="C" @change="selectOne1"
                >周期执行</el-radio
              >
              <el-radio v-model="newForm.radio" label="N" @change="selectOne2"
                >立即执行</el-radio
              >
            </el-form-item>

            <!-- 执行粒度 可选天月 -->

            <el-form-item label="执行粒度" label-size="15px" v-if="ZXlidu">
              <el-select
                v-model="newForm.value1"
                placeholder="请选择"
                :disabled="disabled"
                @change="selectOne3"
              >
                <el-option
                  v-for="item in timeoptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                >
                </el-option>
              </el-select>
            </el-form-item>

            <!-- 采样时间 -->
            <!-- 天数 -->
            <el-row>
              <el-col :span="14">
                <el-form-item label="采样时间" label-size="15px">
                  <el-select
                    v-model="newForm.value3"
                    multiple
                    placeholder="请选择天数"
                    :disabled="ddisabled"
                  >
                    <el-option
                      v-for="item in dayoptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <!-- 小时数 -->
              <el-col :span="10" v-if="dayif">
                <el-form-item label="" label-width="20px" label-size="15px">
                  <el-select
                    v-model="newForm.value2"
                    multiple
                    placeholder="请选择小时数"
                    :disabled="hdisabled"
                  >
                    <el-option
                      v-for="item in hoptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    >
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>

            <el-form-item label="抽样比例" prop="value4" label-size="15px">
              <el-input
                type="text"
                v-model="newForm.value4"
                placeholder="请输入抽样比例"
              >
                <i slot="suffix" style="font-style: normal; margin-right: 10px"
                  >%</i
                >
              </el-input>
            </el-form-item>

            <div class="btnbox">
              <el-button @click="okbtn()" type="primary">保存</el-button>
              <el-button @click="nobtn()" type="primary">取消</el-button>
            </div>
          </div>
        </div>
      </el-form>
    </moc-section>
  </moc-container>
</template>
<script>
/**
 * 混入对象
 */
import common from "@/mixins/common.js"; // 通用  每个页面都需要引入

export default {
  mixins: [common],
  props: {
    selectId: {
      type: String,
      default: "",
    },
    selectName: {
      type: String,
      default: "",
    },
  },
  data() {
    
const validateAcquaintance = (rule, value, callback) => {
　　if (value <= 0 || value >= 100) {
　　　　callback(new Error('数字在 0 至 100 %之间'))
　　} 
    let a = /^[0-9]*$/;
    if(!a.test(value)){
　     callback(new Error('必须是数字'))
    }else{
      callback()
    }
}
    return {
      disabled: true,
      hdisabled: true,
      ddisabled: true,
      ZXlidu: true,
      dayif: true,
      idValue: "",
      name: "",
      urlManage: {
        getsetSchemaCycle: "/business/setSchemaCycle",
      },
      newForm: {
        value1: "D",
        value2: [],
        value3: [],
        value4: "",
        
      },
      radio: "C",
      value: "",
      // newForm: [],
      //   执行粒度
      timeoptions: [
        {
          value: "D",
          label: "天",
        },
        {
          value: "M",
          label: "月",
        },
      ],
      // 天
      dayoptions: [
        {
          value: "01",
          label: "01",
        },
        {
          value: "02",
          label: "02",
        },
        {
          value: "03",
          label: "03",
        },
        {
          value: "04",
          label: "04",
        },
        {
          value: "05",
          label: "05",
        },
        {
          value: "06",
          label: "06",
        },
        {
          value: "07",
          label: "07",
        },
        {
          value: "08",
          label: "08",
        },
        {
          value: "09",
          label: "09",
        },
        {
          value: "10",
          label: "10",
        },
        {
          value: "11",
          label: "11",
        },
        {
          value: "12",
          label: "12",
        },
        {
          value: "13",
          label: "13",
        },
        {
          value: "14",
          label: "14",
        },
        {
          value: "15",
          label: "15",
        },
        {
          value: "16",
          label: "16",
        },
        {
          value: "17",
          label: "17",
        },
        {
          value: "18",
          label: "18",
        },
        {
          value: "19",
          label: "19",
        },
        {
          value: "20",
          label: "20",
        },
        {
          value: "21",
          label: "21",
        },
        {
          value: "22",
          label: "22",
        },
        {
          value: "23",
          label: "23",
        },
        {
          value: "24",
          label: "24",
        },
        {
          value: "25",
          label: "25",
        },
        {
          value: "26",
          label: "26",
        },
        {
          value: "27",
          label: "27",
        },
        {
          value: "28",
          label: "28",
        },
        {
          value: "29",
          label: "29",
        },
        {
          value: "30",
          label: "30",
        },
        {
          value: "31",
          label: "31",
        },
      ],
      // 小时
      hoptions: [
        {
          value: "01",
          label: "01",
        },
        {
          value: "02",
          label: "02",
        },
        {
          value: "03",
          label: "03",
        },
        {
          value: "04",
          label: "04",
        },
        {
          value: "05",
          label: "05",
        },
        {
          value: "06",
          label: "06",
        },
        {
          value: "07",
          label: "07",
        },
        {
          value: "08",
          label: "08",
        },
        {
          value: "09",
          label: "09",
        },
        {
          value: "10",
          label: "10",
        },
        {
          value: "11",
          label: "11",
        },
        {
          value: "12",
          label: "12",
        },
        {
          value: "13",
          label: "13",
        },
        {
          value: "14",
          label: "14",
        },
        {
          value: "15",
          label: "15",
        },
        {
          value: "16",
          label: "16",
        },
        {
          value: "17",
          label: "17",
        },
        {
          value: "18",
          label: "18",
        },
        {
          value: "19",
          label: "19",
        },
        {
          value: "20",
          label: "20",
        },
        {
          value: "21",
          label: "21",
        },
        {
          value: "22",
          label: "22",
        },
        {
          value: "23",
          label: "23",
        },
        {
          value: "24",
          label: "24",
        },
      ],

      value: "",

      rules: {     
        value4: [
       
          { validator: validateAcquaintance },

        ]
        
      },

      
    };
    
  },
  computed: {},
  created() {
    this.getData(); //获取数据方法
  },
  // this.initOptions();
  // debugger;
  // let id = this.selectData.id;
  // let name = this.selectData.name;

  methods: {
    removeTableRow() {},
    selectOptions() {},
    selectOne2() {
      this.newForm.value1 = "";
      this.ZXlidu = false;
      this.disabled = true;
    },
    selectOne1() {
      this.ZXlidu = true;
      this.disabled = false;
    },

    selectOne3() {
      // console.log("111",this.newForm.value1)
      if (this.newForm.value1 == "D") {
        this.ddisabled = true;
        this.hdisabled = false;
        this.newForm.value2 = "";
        this.newForm.value3 = "";
      } else {
        this.ddisabled = false;
        this.hdisabled = false;
        this.newForm.value2 = "";
        this.newForm.value3 = "";
      }
    },

    // 保存
    okbtn() {
      this.$refs["newForm"].validate((valid) => {
        if (valid) {
          let day = this.newForm.value3;
          let hour = this.newForm.value2;
          if (day == "") {
            day = [];
          }
          if (hour == "") {
            hour = [];
          }
          let sampleTime = { day, hour };
          console.info(sampleTime);
          let params = {
            // name: this.selectName,
            name: this.idValue,
            schema_id: this.selectId,
            radio: this.radio,
            unit: this.newForm.value1,
            sample_rate: this.newForm.value4,
            sample_time: sampleTime,
          };
          this.$http
            .post(this.urlManage.getsetSchemaCycle, params)
            .then((response) => {
              if (response.status == true) {
                this.$message({ type: "success", message: "保存成功！" });
                onCancel();
              } else {
                this.$message({ type: "warning", message: "保存失败！" });
              }
            });
        }
      });

      // let day = this.newForm.value3;
      // let hour = this.newForm.value2;
      // if (day == "") {
      //   day = [];
      // }
      // if (hour == "") {
      //   hour = [];
      // }
      // let sampleTime = { day, hour };
      // console.info(sampleTime);
      // let params = {
      //   // name: this.selectName,
      //   name: this.idValue,
      //   schema_id: this.selectId,
      //   radio: this.radio,
      //   unit: this.newForm.value1,
      //   sample_rate: this.newForm.value4,
      //   sample_time: sampleTime,
      // };
      // console.log(params);
      // this.getsetSchemaCycle(params);
      // getsetSchemaCycle(params).then((res) => {
      //   console.log("11111", res);
      //   this.data = res.data;
      // });
    },

    strToArr(str) {
      return str.split(",");
    },

    /**
     * 确定、取消
     */

    // 获取数据
    getData() {
      //this.getsetSchemaCycle();
      //  let params = {
      //     schema_id:"",
      //     task_id:"",}
      // //  getquerySchema(params).then((res) => {
      // //      console.log("11111",res);
      // //      this.data=res.data
      // //  })
      this.idValue = this.selectName;
      this.selectId = this.selectId;
      // this.name = this.name;
      this.newForm.value1;
      if ((this.radio = "C")) {
        this.disabled = false;
      }
      if (this.newForm.value1 == "D") {
        this.hdisabled = false;
      }
    },
    getsetSchemaCycle(params) {
      // let params = {
      //   schema_id:"1",
      // task_id:"2"
      // };
      debugger;

      this.$http
        .post(this.urlManage.getsetSchemaCycle, params)
        .then((response) => {
          debugger;
          console.log("response", response);
          // this.rule_name=response.data.rule_name
          // this.rule_msg_cnt=response.data.rule_msg_cnt

          // console.log(this.rule_name);
          // console.log(this.rule_msg_cnt);
          // if (response.status == 200) {
          //     if (response.data.data.list == null) {
          //         this.tableData = [];
          //     } else {
          //         this.tableData = response.data.data.list;
          //     }
          //     this.pagination.total = Number(response.data.data.total);
          // } else {
          //     // 弹出提示
          //     this.$message({
          //         showClose: true,
          //         message: response.errorCode
          //     });
          // }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    onCancel() {
      this.$emit("after-callback", false);
    },
  },
};
</script>
<style scoped>
.inputbox {
  outline-style: none;
  width: 320px;
  font-family: "Microsoft soft";
  height: 32px;
  line-height: 32px;
  padding-right: 30px;

  background-color: #ffffff;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  box-sizing: border-box;
  color: #606266;
  font-size: inherit;
  padding: 0 15px;
}
.inputbox:hover {
  border-color: #c0c4cc;
}
.inputbox:focus {
  outline: none;
  border-color: #409eff;
}
.btnbox {
  margin-left: 320px;
  margin-top: 40px;
}
</style>