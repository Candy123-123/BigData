<template>

    <moc-container flex horizontal id="page-content">
        <dmGroupTree
            title="基础规则"
            :showHeader="true"
            :groupTree="groupTree"
            ref="dmGroupTree"
            treeType="tag"
            @tree-node-click="treeNodeClick"
            style="margin-right: 1%"
        ></dmGroupTree>
        <moc-section bodier >
            <moc-container flex id="page-bodier" style="height: 94%">
                <moc-section class="qm-search" >
                    <el-form  :model="search" :inline="true"  label-suffix="：">
                        <el-form-item label="名称">
                            <el-input v-model="search.name" clearable placeholder="请输入"></el-input>
                        </el-form-item>
                        <el-form-item class="qm-search-btns">
                            <el-button @click="onSearch(search)" type="primary"><i class="el-icon-search"></i> 搜索
                            </el-button>
                        </el-form-item>
                    </el-form>
                </moc-section>

                <moc-section id="project-table" bodier class="qm-table">
                    <el-table
                        :data="tableData"
                        :height="tableHeight"
                        v-loading="tableLoading"
                        border
                        stripe
                        tooltip-effect="light"
                    >
                        <el-table-column type="index" label="序号" width="60" :index="handleIndex"
                                         align="center"></el-table-column>
                        <el-table-column label="编码" prop="code" width="80"></el-table-column>
                        <el-table-column label="名称" prop="name" width="150"></el-table-column>
                        <el-table-column label="描述" prop="desc_info" width="650"></el-table-column>
                        <el-table-column label="更新时间" prop="timestamp" min-width="120"></el-table-column>
                    </el-table>
                </moc-section>
                <moc-section class="qm-pagination" >
                    <el-pagination
                        :current-page.sync="pagination.current"
                        :page-size.sync="pagination.size"
                        @current-change="initTableData()"
                        @size-change="handleSizeChange(pagination.size)"
                        :total="pagination.total"
                        :layout="$global.paginationLayout"
                        :page-sizes="$global.paginationSizes"
                        background
                    >
                    </el-pagination>
                </moc-section>
            </moc-container>
        </moc-section>

    </moc-container>
</template>
<script>

    /**
     * 混入对象
     */
    // 页面通用的
    import common from '@/mixins/common.js';
    // 表格通用的
    import tableCommon from '@/mixins/tableCommon.js';
    // 表格数据格式化
    import tableFormatter from '@/mixins/tableFormatter.js';

    export default {
        mixins:[
            common,
            tableCommon,
            tableFormatter
        ],
        components: {
            formDialog:()=>import('./form-dialog.vue'),
            dmGroupTree: () => import("@/views/components/group-tree/main.vue")
        },
        data () {
            return {

                urlManage: {
                    queryBasicRule:"/config1/queryBasicRuleList"
                },
                //左侧菜单树
                groupTree: [
                    {
                        id:null,
                        label: '全部',
                        tools: false,
                        children:[
                            {
                                id: '1',
                                label: '表规则',
                                tools: false,
                            },
                            {
                                id: '2',
                                label: '列规则',
                                tools: false,
                            }
                        ]
                    }
                ],

                /**
                 * 搜索条件
                 */
                search: {
                    name: ''
                },
                /**
                 * 表格相关数据
                 */
                tableData: [],
                tableTotal: 0,
                /**
                 * 分页数据
                 */
                pagination:{
                    pageNum: 1,              // 当前页
                    pageSize: 10,     // 每页显示条目个数
                    total: 0                // 总条数
                },

            }
        },
        created(){
            this.initTableData();
        },
        mounted () {
        },
        methods:{
            /**
             * pagination相关事件
             */
            handleSizeChange(val) {

                this.pagination.pageSize=val
                this.initTableData()
            },
            /**
             * 左侧树点击事件
             */
            treeNodeClick(data) {
                let treedata={
                    group_id:data.id
                }
                this.initTableData(treedata);
            },
            /**
             * 搜索事件
             */
            onSearch(data){

                this.initTableData(data)
            },
            /**
             * 初始化表格数据
             */
            initTableData() {
                let params = { ...this.search, ...this.pagination };
                this.$http
                    .post(this.urlManage.queryBasicRule,params)
                    .then(response => {
                        debugger
                        if (response.status==true) {
                            if (response.data.list == null) {
                                this.tableData = [];
                            } else {
                                this.tableData = response.data.list;
                                this.tableTotal = response.data.total;
                                this.pagination.size=Number(response.data.pageSize);
                                this.pagination.total=Number(response.data.total);
                                this.pagination.pageNum=Number(response.data.pageNum);
                            }

                        } else {
                            this.$message({
                                showClose: true,
                                type: "warning" ,
                                message: "查询出错!"
                            });
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            },
            initTableData(data) {
                let params = { ...data,...this.pagination };
                this.$http
                    .post(this.urlManage.queryBasicRule,params)
                    .then(response => {
                        if (response.status==true) {
                            if (response.data.list == null) {
                                this.tableData = [];
                            } else {
                                this.tableData = response.data.list;
                                this.tableTotal = response.data.total;
                                this.pagination.size=Number(response.data.pageSize);
                                this.pagination.total=Number(response.data.total);
                                this.pagination.pageNum=Number(response.data.pageNum);
                            }

                        } else {
                            // 弹出提示
                            this.$message({
                                showClose: true,
                                type: "warning" ,
                                message: "查询出错！"
                            });
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            }
        }
    }
</script>
<style>
    .dm-panel-bodier.data-standard > div {
        height: calc(100%);
    }

    .dm-panel-bodier.data-standard .neu-table {
        height: calc(100% - 9em);
    }

    .dm-panel-bodier.data-standard .neu-table > .el-table {
        height: calc(100%);
    }

    .dm-panel-bodier.data-standard .el-table__body-wrapper {
        height: calc(100% - 4em);
        overflow-y: auto;
    }

    .neu-pagination {
        padding-bottom: 0;
    }

</style>

