<template>
    <moc-container flex horizontal id="page-content">
        <dm-group-tree
            :groupTree="groupTree"
            title="分组"
            ref="dmGroupTree"
            treeType="tag"
            @tree-node-click="treeNodeClick"
            @tree-node-deleted="treeNodeDeleted"
            @tree-node-rename="treeNodeRename"
        ></dm-group-tree>
        <moc-section bodier>
            <moc-container flex id="page-wrap">
                <moc-section class="qm-search">
                    <el-form :model="search" :inline="true" label-width="100px" label-suffix="：">
                        <el-form-item label="数据源">
                            <el-input v-model="search.user" clearable placeholder="审批人"></el-input>
                        </el-form-item>
                        <el-form-item class="qm-search-btns">
                            <el-button @click="onSearch()" type="primary">查询</el-button>
                        </el-form-item>
                    </el-form>
                </moc-section>

                <moc-section class="qm-buttons">
                    <el-button @click="onAdd()" type="primary" icon="el-icon-circle-plus-outline">新增</el-button>
                    <el-button icon="el-icon-delete">删除</el-button>
                </moc-section>
            
                <moc-section id="project-table" bodier class="qm-table">
                    <el-table
                        :data="tableData"
                        :height="tableHeight"
                        v-loading="tableLoading"
                        border
                        stripe
                        @selection-change="handleSelectedRows"
                    >
                        
                        <el-table-column label="序号" type="index" :index="handleIndex" :width="tableIndexWidth" align="center"></el-table-column>
                        <el-table-column type="selection" width="50" align="center"></el-table-column>
                        <el-table-column label="姓名" prop="name" width="186"></el-table-column>
                        <el-table-column label="性别" prop="sex" width="112"></el-table-column>
                        <el-table-column label="年龄" prop="age" width="112"></el-table-column>
                        <el-table-column label="地址" prop="address" min-width="256"></el-table-column>
                    </el-table>
                </moc-section>
                <moc-section class="qm-pagination">
                    <el-pagination
                        :current-page.sync="pagination.current"
                        :page-size.sync="pagination.size"
                        @current-change="initTableData()"
                        @size-change="initTableData()"
                        :total="pagination.total"
                        :layout="$global.paginationLayout"
                        :page-sizes="$global.paginationSizes"
                        background
                    >
                    </el-pagination>
                </moc-section>
            </moc-container>
        </moc-section>

        <!-- 弹出框 -->
        <el-dialog
            title="新增"
            :visible.sync="formDialogVisible"
            width="560px"
            top="50px"
            append-to-body
            v-mocDialogDrag
        >
            <form-dialog v-if="formDialogVisible" @after-callback="dialogCallback" ref="dialogTableTemplate"></form-dialog>
            <template #footer>
                <el-button @click="$refs.dialogTableTemplate.onCancel()">取 消</el-button>
                <el-button @click="$refs.dialogTableTemplate.onSubmit('ruleForm')" type="primary">确 定</el-button>
            </template>
        </el-dialog>

    </moc-container>
</template>
<script>

    /**
     * 混入对象
     */
    // 页面通用的
    import common from '@/mixins/common.js';
    // 表格通用的
    import tableCommon from '@/mixins/tableCommon.js';
    // 表格数据格式化
    import tableFormatter from '@/mixins/tableFormatter.js';

    export default {
        mixins:[
            common,
            tableCommon,
            tableFormatter
        ],
        components: {
            formDialog:()=>import('./form-dialog.vue'),
            dmGroupTree: () => import("@/views/components/group-tree/main.vue")
        },
        data () {
			return {

                //左侧菜单树
                groupTree: [
                    {
                        id: 'root',
                        label: '全部',
                        tools: false,
                        children:[
                            {
                                id: '11',
                                label: '111',
                                tools: false
                            }
                        ]
                    }
                ],

                /**
                 * 搜索条件
                 */
                search: {
                    user: '1'
                },
                /**
                 * 表格相关数据
                 */
				tableData: [],
				tableTotal: 0,
				selectedRows: [],


                formDialogVisible: false,
                
                /**
                 * 下拉、单选、多选等的数据
                 */
                options:{
                    
                }
			}
        },
        created(){
            this.initOptions();
        },
        mounted () {
        },
        methods:{
            onAdd(){
                this.formDialogVisible = true
            },
            dialogCallback(){
                this.formDialogVisible = false
            },
            /**
             * 左侧树点击事件
             */
            treeNodeClick(data) {
                
            },
            treeNodeDeleted(data) {
                
            },
            treeNodeRename(data) {
                
            },


            /**
             * 搜索事件
             */
            onSearch(){
                this.pagination.current = 1;
            
            },
            /**
             * table 的相关事件
             */
            handleSelectedRows(rows){
                this.selectedRows = rows;
            },
            /**
             * 下拉框 options 的数据
             */
            initOptions(){
                /**
                 * 模拟请求数据
                 */
                // this.$http.post('/mock/tableData').then( res => {
                //     console.log(res)
                // });


            },
            /**
             * 初始化表格数据
             */
            initTableData() {
                let params = { ...this.search, ...this.pagination };


                // this.$http.get(`/mock/tableData`, params).then( res => {
                //     this.tableData = res.table;
                //     this.tableTotal = res.total;
                // })
                // .catch( error => {
                //     this.$message(error);
                // });
            },
        }
    }
</script>
