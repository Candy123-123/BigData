<template>
    <moc-container id="page-content" flex>
        <moc-section class="qm-search">
            <el-form   style="margin-left: -2%" :model="search" :inline="true" label-width="100px" label-suffix="：">
                <el-form-item label="数据源">
                    <el-input v-model="search.name" clearable placeholder="数据源名称"></el-input>
                </el-form-item>
                <el-form-item class="qm-search-btns">
                    <el-button @click="onSearch(search)" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </moc-section>

        <moc-section class="qm-buttons" >
            <el-button @click="onAdd()" type="primary" icon="el-icon-circle-plus-outline">新增</el-button>
		    <el-button @click="onDelete()" icon="el-icon-delete">删除</el-button>
        </moc-section>

        <moc-section id="project-table" bodier class="qm-table">
            <el-table
                :data="tableData"
                :height="tableHeight"
                v-loading="tableLoading"
                border
                stripe
                @selection-change="handleSelectedRows"
            >
                <el-table-column type="selection" width="56" align="center"></el-table-column>
                <el-table-column label="序号"  prop="id" :index="handleIndex" width="200" align="center"></el-table-column>
                <el-table-column label="数据源名称"  prop="name" width="500"></el-table-column>
                <el-table-column label="描述"  prop="desc_info" min-width="400"></el-table-column>
            </el-table>
        </moc-section>
        <moc-section class="qm-pagination">
            <el-pagination
                :current-page.sync="pagination.current"
                :page-size.sync="pagination.size"
                @current-change="initTableData()"
                @size-change="handleSizeChange(pagination.size)"
                :total="pagination.total"
                :layout="$global.paginationLayout"
                :page-sizes="$global.paginationSizes"
                background
            >
            </el-pagination>
        </moc-section>

        <!-- 弹出框 -->
        <el-dialog
            title="新增"
            :visible.sync="formDialogVisible"
            width="560px"
            top="50px"
            append-to-body
            v-mocDialogDrag
        >
            <form-dialog v-if="formDialogVisible" @after-callback="dialogCallback" name="对话框" :onSearch="onSearch"  ref="dialogTableTemplate"></form-dialog>
            <template #footer>
                <el-button @click="$refs.dialogTableTemplate.onCancel()">取 消</el-button>
                <el-button @click="$refs.dialogTableTemplate.onSubmit()"  type="primary">确 定</el-button>
            </template>
        </el-dialog>

    </moc-container>
</template>
<script>

    /**
     * 混入对象
     */
    // 页面通用的
    import common from '@/mixins/common.js';
    // 表格通用的
    import tableCommon from '@/mixins/tableCommon.js';
    // 表格数据格式化
    import tableFormatter from '@/mixins/tableFormatter.js';

    export default {
        mixins:[
            common,
            tableCommon,
            tableFormatter
        ],
        components: {
            formDialog:()=>import('./form-dialog.vue')
        },
        data () {
			return {
                urlManage: {
                    queryDataSourceList:"/config1/queryDataSourceList",
                    delDataSourceList:"/config1/delDataSourceList"
                },
                pagination:{
                    pageNum: 1,              // 当前页
                    pageSize: 10,     // 每页显示条目个数
                    total: 0                // 总条数
                },
                /**
                 * 搜索条件
                 */
                search: {
                    name:''
                },
                /**
                 * 表格相关数据
                 */
				tableData: [],
				tableTotal: 0,
				selectedRows: [

                ],

                ids:[],
                /**
                 * 要删除的数据的id集合 以及 选择行的详细信息
                 */
                deleteData:{
				    ids:[]
                },
                formDialogVisible: false,
                /**
                 * 添加页面的数据
                 */
                addData:{
                    name:"",
                    desc_info:""
                },
                /**
                 * 下拉、单选、多选等的数据
                 */
                options:{

                },

			}
        },
        created(){
            this.initTableData();
        },
        mounted () {
        },
        methods:{
            onAdd(){
                this.formDialogVisible = true
            },
            onDelete(){
                if(this.selectedRows.length==0){
                    this.$message({
                        showClose: true,
                        type: "warning" ,
                        message: "删除的数据为空！ 请至少选择一条数据"
                    })
                }else{
                    this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning'
                    }).then(() => {
                        let param={...this.deleteData,...this.pagination}
                        this.$http.post(this.urlManage.delDataSourceList,param)
                            .then(response=>{
                                if(response.status==true){
                                    if(!response.data.flag){
                                        this.$message({
                                            type: 'warning',
                                            message: '有数据源正在被核查！部分数据源无法删除！'
                                        });
                                        this.initTableData(this.search);
                                    }else{
                                        this.initTableData(this.search);
                                        this.$message({

                                            type: "success" ,
                                            message: '删除成功！'
                                        });
                                    }
                                }
                            })
                    });
                }


            },
            dialogCallback(){
                this.formDialogVisible = false
            },
            /**
             * 搜索事件
             */
            onSearch(data){
                this.initTableData(data)
            },
            /**
             * table 的相关事件
             * 构造ids数组
             */
            handleSelectedRows(rows){
                this.selectedRows = rows;
                for(let i=0;i<this.selectedRows.length;i++){
                    this.deleteData.ids.push(this.selectedRows[i].id);
                }
                this.deleteData.ids=Array.from(new Set(this.deleteData.ids))
            },
            /**
             * 将要deleteData ids 置空 方便下次删除
             *
             */
            initDeledteDate(){
                this.deleteData.ids=[]
            },
            /**
             * pagination相关事件
             */
            handleSizeChange(val) {

                this.pagination.pageSize=val
                this.initTableData()
            },



            /**
             * 初始化表格数据
             */
            initTableData() {
                this.initDeledteDate();
                let params = { ...this.search, ...this.pagination };
                this.$http
                    .post(this.urlManage.queryDataSourceList,params)
                    .then(response=>{

                        if(response.status==true){
                            if(response.data==null){
                                this.tableData=[]
                            }else{
                                this.tableData=response.data.list
                                this.pagination.size=Number(response.data.pageSize);
                                this.pagination.total=Number(response.data.total);
                                this.pagination.pageNum=Number(response.data.pageNum);
                            }
                        }else{
                            this.$message({
                                showClose: true,
                                type: "warning" ,
                                message: "查询出错！"
                            })
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            },
            initTableData(data) {
                let param={...data,...this.pagination}
                this.$http
                    .post(this.urlManage.queryDataSourceList,param)
                    .then(response=>{
                        if(response.status==true){
                            if(response.data==null){
                                this.tableData=[]
                            }else{
                                this.tableData=response.data.list
                                this.pagination.size=Number(response.data.pageSize);
                                this.pagination.total=Number(response.data.total);
                                this.pagination.pageNum=Number(response.data.pageNum);
                            }
                        }else{
                            this.$message({
                                showClose: true,
                                type: "warning" ,
                                message: "查询出错！"
                            })
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            },
            /**
             * 删除数据源
             * @param data
            deleteTableData(data){
                let param={...data,...this.pagination}
                this.$http.post(this.urlManage.delDataSourceList,param)
                    .then(response=>{

                        if(response.status==200){
                            if(response.data==null){
                                this.tableData=[]
                            }else{
                                this.tableData=response.data.data.list
                                this.pagination.size=Number(response.data.data.pageSize);
                                this.pagination.total=Number(response.data.data.size);
                            }
                        }else{
                            this.$message({
                                showClose: true,
                                message: "删除出错！"
                            })
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });


            }*/
        }
    }
</script>
