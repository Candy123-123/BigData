<template>
    <moc-container>
        <moc-section>
            <el-form :model="ruleForm" ref="ruleForm" label-width="140px" class="qm-form-horizontal" label-suffix="：">
                <el-form-item
                    label="数据源名称"
                    prop="name"
                >
                    <!-- <moc-cascader
                        v-model="ruleForm.name"
                        :options="options.rangeOptions"
                        :root-options="options.rootOptions"
                        clearable
                        width="500"
                        placement="bottom-start"
                        :placeholder="['分组','值域']"
                        @selected-second="selectOptions"
                    ></moc-cascader> -->


                    <el-cascader v-model="ruleForm.name" :options="options.rangeOptions" @change="handleChange" clearable></el-cascader>
                </el-form-item>
                <el-form-item
                    label="描述"
                    prop="desc"
                    :rules="{  message: '请输入描述', trigger: 'blur' }"
                >
                    <el-input type="textarea" v-model="ruleForm.desc" rows="4"></el-input>
                </el-form-item>
            </el-form>
        </moc-section>
    </moc-container>

</template>
<script>
    /**
     * 混入对象
     */
    import common from '@/mixins/common.js'; // 通用  每个页面都需要引入

    export default {
        props: {
            onSearch: { // 指定属性名, 属性值的类型, 必要性
                type: Function,
                required: true
            },

        },
        mixins: [common],
        data() {
            return {
                urlManage:{
                    queryMarkTreeList:"/config1/queryMarkTreeList",
                    addDataSourceList:"/config1/addDataSourceList",
                    queryMarkerDataSource:"/config1/queryMarkerDataSource"
                },
                ruleForm: {
                    label:'',
                    name:[], //对应的id+code
                    desc: '' //对应的描述
                },
                formlabel: {
                    label:'',
                },
                param1:{
                  name:'',
                },
                options:{
                    rangeOptions:[
                        {
                            value: 'zhinan',
                            label: '指南',
                            children: [
                                {
                                    value: 'shejiyuanze',
                                    label: '设计原则',
                                    children: [
                                        {
                                            value: 'yizhi',
                                            label: '一致'
                                        },
                                        {
                                            value: 'fankui',
                                            label: '反馈'
                                        },
                                        {
                                            value: 'xiaolv',
                                            label: '效率'
                                        },
                                        {
                                            value: 'kekong',
                                            label: '可控'
                                        }
                                    ]
                                },
                                {
                                    value: 'daohang',
                                    label: '导航',
                                    children: [
                                        {
                                            value: 'cexiangdaohang',
                                            label: '侧向导航'
                                        },
                                        {
                                            value: 'dingbudaohang',
                                            label: '顶部导航'
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            value: 'ziyuan',
                            label: '资源',
                            children: [
                                {
                                    value: 'axure',
                                    label: 'Axure Components'
                                },
                                {
                                    value: 'sketch',
                                    label: 'Sketch Templates'
                                },
                                {
                                    value: 'jiaohu',
                                    label: '组件交互文档'
                                }
                            ]
                        }
                    ]
                }
            }
        },
        created() {

        },
        mounted() {
            this.initOptions();
        },
        methods: {
            selectOptions(){

            },
            handleChange(value) {

            },
            /**
             * 确定、取消
             */
            onSubmit() {
                let param={
                    id_code_name:this.ruleForm.name[this.ruleForm.name.length-1],
                    desc_info:this.ruleForm.desc
                }
                this.$http
                    .post(this.urlManage.addDataSourceList,param)
                    .then(response=>{
                        this.onSearch(this.param1)
                        console.log(response.status)
                        if(response.status==true){
                            if(response.data.flag){
                                this.$message({
                                    showClose: true,
                                    type: "success" ,
                                    message: "添加成功！"
                                })
                            }else{
                                this.$message({
                                    showClose: true,
                                    type: "warning" ,
                                    message: "数据源重复！ 请勿重复添加！"
                                })
                            }

                        }
                    })
                    .catch(error=>{
                        console.log(error)
                    })

                this.$emit('after-callback', false);

            },
            onCancel() {
                this.$emit('after-callback', false);
            },


            initOptions(){
                this.$http
                    .post(this.urlManage.queryMarkTreeList)
                    .then(response=>{
                        if(response.status==true){
                            if(response.data==null){
                                this.options.rangeOptions=[]
                            }else{
                                this.options.rangeOptions=response.data
                            }
                        }else{
                            this.$message({
                                showClose: true,
                                type: "warning" ,
                                message: "查询出错！"
                            })
                        }
                    })
                    .catch(error=>{
                        console.log(error)
                    })
            }
        }
    }
</script>
