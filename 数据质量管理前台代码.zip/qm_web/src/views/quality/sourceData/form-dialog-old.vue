<template>
    <moc-container>
        <moc-section>
            <el-form :model="ruleForm" ref="ruleForm" label-width="140px" class="qm-form-horizontal" label-suffix="：">
                <el-form-item
                    label="数据源名称"
                    prop="name"
                >
                    <moc-cascader
                        v-model="ruleForm.name"
                        :options="options.rangeOptions"
                        :root-options="options.rootOptions"
                        clearable
                        width="500"
                        placement="bottom-start"
                        :placeholder="['分组','值域']"
                        @selected-second="selectOptions"
                    ></moc-cascader>
                </el-form-item>
                <el-form-item
                    label="描述"
                    prop="desc"
                    :rules="{ required: true, message: '请输入描述', trigger: 'blur' }"
                >
                    <el-input type="textarea" v-model="ruleForm.desc" rows="4"></el-input>
                </el-form-item>
            </el-form>
        </moc-section>
    </moc-container>

</template>
<script>
    /**
     * 混入对象
     */
    import common from '@/mixins/common.js'; // 通用  每个页面都需要引入

    export default {
        mixins: [common],
        data() {
            return {
                ruleForm: {
                    name: '',
                    desc: ''
                },
                options:{
                    rangeOptions:[
                        {
                            "label":"国际信令",
                            "value":"561147351516409856",
                            "children":[
                                {
                                    "label":"call_result",
                                    "value":"561188624013029376"
                                },
                                {
                                    "label":"cause",
                                    "value":"561188868805193728"
                                },
                                {
                                    "label":"singalflag",
                                    "value":"561188968042426368"
                                },
                                {
                                    "label":"illegal_type",
                                    "value":"561189136057856000"
                                }
                            ]
                        },
                        {
                            "label":"通用",
                            "value":"561148266281529344",
                            "children":[
                                {
                                    "label":"time_yyyyMMddHHmmss",
                                    "value":"561152603288334336"
                                },
                                {
                                    "label":"毫秒数",
                                    "value":"561480020213198848"
                                },
                                {
                                    "label":"province",
                                    "value":"561562300151590912"
                                },
                                {
                                    "label":"operator",
                                    "value":"562214180569575424"
                                },
                                {
                                    "label":"time_yyyyMMddHH",
                                    "value":"576855602077724672"
                                }
                            ]
                        }
                    ],
                    rootOptions:{
                        value: 'all-options',
					    label: '所有资源'
                    }
                }
            }
        },
        created() {

        },
        mounted() {
            this.initOptions();
        },
        methods: {
            selectOptions(){

            },
            /**
             * 确定、取消
             */
            onSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        

                        this.$emit('after-callback', true);
                        
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
                
            },
            onCancel() {
                this.$emit('after-callback', false);
            },

            
            initOptions(){
                console.log('初始化固定数据')
            }
        }
    }
</script>
