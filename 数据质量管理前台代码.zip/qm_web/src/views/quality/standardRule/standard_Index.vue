<template>
    <moc-container flex horizontal id="page-content">

        <dmGroupNewTree ref="dmGroupTree"
                        treeType="folder"
                        :appendRoot="false" append
                        :groupTree="groupTree"
                        title="标准规则"
                        @tree-node-click="treeNodeClick"

        ></dmGroupNewTree>
        <moc-section bodier>
            <moc-container flex id="page-wrap">
                <moc-section class="qm-search">
                    <el-form :inline="true" class="dm-table-tools" label-suffix="：">
                        <el-form-item label="名称">
                            <el-input v-model="filterTableName" placeholder="请输入"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="onSearch()"><i class="el-icon-search"></i> 搜索
                            </el-button>
                        </el-form-item>
                    </el-form>
                </moc-section>
                <moc-section id="project-table" bodier class="qm-table">
                    <el-table :data="tableData" :height="tableHeight" v-loading="tableLoading" border stripe
                              tooltip-effect="light">
                        <el-table-column type="expand" width="50">
                            <template slot-scope="scope">
                                <ul class="qm-rule-list">
                                    <template v-for="(item, index) in scope.row.mdStandard.boundRule">
                                        <li v-if="item.ruleType === 1" :key="index">
                                            <p>
                                                <strong>规则：</strong>
                                                <span>{{item.ruleLabel}}</span>
                                                <span v-if="item.s_e_pos" class="m-l-xs" style="color: #999;">（{{item.s_e_pos}}）</span>
                                            </p>
                                            <div>
                                                <strong>参数：</strong>
                                                <span v-for="(param,idx) in item.params" :key="idx" class="m-r-xs">
                                                            <font>{{param.label}}：</font>
                                                            <font>{{param.text}}</font>
                                                            <font v-if="idx<item.params.length-1">，</font>
                                                        </span>
                                            </div>
                                        </li>
                                        <li v-else-if="item.ruleType === 2" :key="index">
                                            <p>
                                                <strong>规则：</strong>
                                                <span>{{item.ruleLabel}}</span>
                                                <span v-if="item.s_e_pos" class="m-l-xs" style="color: #999;">（{{item.s_e_pos}}）</span>
                                            </p>
                                            <div v-for="(param,idx) in item.params" :key="idx" class="qm-rule-computed">
                                                <strong>当：</strong>
                                                <span v-for="(when,i) in param.when" :key="'when'+i" class="m-r-xs">
                                                            <font>{{when.fieldName}}</font>
                                                            <font> {{when.operatorName}} </font>
                                                            <font>{{when.valueName}}</font>
                                                            <font v-if="i<param.when.length-1">，</font>
                                                        </span>
                                                <strong class="m-l-md">那么：</strong>
                                                <span v-for="(then,i) in param.then" :key="'then'+i" class="m-r-xs">
                                                            <font>{{then.fieldName}}</font>
                                                            <font> {{then.operatorName}} </font>
                                                            <font>{{then.valueName}}</font>
                                                            <font v-if="i<param.then.length-1">，</font>
                                                        </span>
                                            </div>
                                        </li>
                                    </template>
                                </ul>
                            </template>
                        </el-table-column>
                        <el-table-column type="index" label="序号" width="60" :index="handleIndex"
                                         align="center"></el-table-column>
                        <el-table-column label="编码" prop="mdStandard.code" min-width="120"
                                         show-overflow-tooltip></el-table-column>
                        <el-table-column label="名称" prop="mdStandard.name" min-width="120"
                                         show-overflow-tooltip></el-table-column>
                        <el-table-column label="描述" prop="mdStandard.description" min-width="200"
                                         show-overflow-tooltip></el-table-column>
                        <!--<el-table-column label="操作" width="128">
                            <template slot-scope="scope">
                                <el-link @click="editTableRow(scope.$index,scope.row)" type="primary">详细
                                </el-link>
                            </template>
                        </el-table-column>-->
                    </el-table>
                </moc-section>
                <moc-section class="qm-pagination">
                    <el-pagination
                        :current-page.sync="pagination.pageNum"
                        :page-size.sync="pagination.pageSize"
                        :page-sizes="pagesizes"
                        :total="pagination.total"
                        :layout="pagelayout"
                        background
                        @size-change="handleSizeChange"
                        @current-change="onSearch"
                    >
                    </el-pagination>
                </moc-section>
            </moc-container>
        </moc-section>
        <el-dialog
            title="详细信息"
            :visible.sync="dialogVisible"
            width="60%"
            append-to-body
            v-mocDialogDrag
        >
            <moc-section>
                <el-form :model="tableRowForm" ref="tableRowForm" label-width="140px" class="qm-form-horizontal"
                         label-suffix="：">
                    <el-form-item label="编码">
                        <el-input v-model="tableRowForm.code" placeholder="请输入"></el-input>
                    </el-form-item>
                    <el-form-item label="名称">
                        <el-input v-model="tableRowForm.name" placeholder="请输入"></el-input>
                    </el-form-item>
                    <el-form-item label="数据类型">
                        <el-select v-model="tableRowForm.dataType"
                                   class="neu-form-block"
                                   placeholder="请选择" filterable clearable>
                            <el-option
                                v-for="(item,index) in options.dataType"
                                :key="index"
                                :label="item.label"
                                :value="item.value"
                            >
                                <span style="float: left">{{ item.label }}</span>
                                <span style="float: right; color: #8492a6; font-size: 13px">{{ item.desc }}</span>
                            </el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="长度" v-show="tableRowForm.dataType ===1">
                        <el-input v-model="tableRowForm.data_length" placeholder="请输入"></el-input>
                    </el-form-item>
                    <el-form-item label="长度" v-show="tableRowForm.dataType ===2">
                        <el-col :span="11">
                            <el-input v-model="tableRowForm.data_length" class="neu-form-block"
                                      placeholder="请输入"></el-input>
                        </el-col>
                        <el-col class="line text-center" :span="2">精度：</el-col>
                        <el-col :span="11">
                            <el-input v-model="tableRowForm.data_precision" class="neu-form-block"
                                      placeholder="请输入"></el-input>
                        </el-col>
                    </el-form-item>
                    <el-form-item label="长度" v-show="tableRowForm.dataType ===3">
                        <el-col :span="11">
                            <el-input v-model="tableRowForm.min_length" class="neu-form-block"
                                      placeholder="请输入"></el-input>
                        </el-col>
                        <el-col class="line text-center" :span="2">-</el-col>
                        <el-col :span="11">
                            <el-input v-model="tableRowForm.max_length" class="neu-form-block"
                                      placeholder="请输入"></el-input>
                        </el-col>
                    </el-form-item>
                    <el-form-item label="日期格式" v-show="tableRowForm.dataType ===4">
                        <el-select v-model="tableRowForm.time_format" class="neu-form-block"
                                   placeholder="请选择"
                                   filterable
                                   clearable>
                            <el-option
                                v-for="(item,index) in options.timeFormatOptions"
                                :key="index"
                                :label="item.label"
                                :value="item.value"
                            >
                                <span style="float: left">{{ item.label }}</span>
                                <span style="float: right; color: #8492a6; font-size: 13px">{{ item.desc }}</span>
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-form>
            </moc-section>
            <template #footer>
                <el-button @click="dialogVisible=false">关 闭</el-button>
            </template>
        </el-dialog>
    </moc-container>
</template>

<script>
    /**
     * 混入对象
     */
    // 页面通用的
    import common from '@/mixins/common.js';
    // 表格通用的
    import tableCommon from '@/mixins/tableCommon.js';
    // 表格数据格式化
    import tableFormatter from '@/mixins/tableFormatter.js';
    // 加载资源
    export default {
        components: {
            dmGroupNewTree: () => import("@/views/components/group-tree/groupNew.vue"),
            // dmruleDetail: ()=> import("@/views/qualityM/standarRule/components/rule_detail.vue")
        },
        mixins: [
            common,
            tableCommon,
            tableFormatter
        ],
        data() {
            return {

                options: {
                    dataType: [
                        {
                            label: "整型",
                            value: 1
                        },
                        {
                            label: "浮点型",
                            value: 2
                        },
                        {
                            label: "字符串",
                            value: 3
                        },
                        {
                            label: "日期型",
                            value: 4
                        },
                        {
                            label: "字节型",
                            value: 5
                        }
                    ],//数据类别
                    rootOptions: {}
                    ,
                    //值域
                    rangeOptions: [],

                    approveStatus: [
                        {
                            label: "草稿",
                            value: 0
                        },
                        {
                            label: "已发布",
                            value: 1
                        },
                        {
                            label: "已驳回",
                            value: 2
                        },
                        {
                            label: "审批中",
                            value: 3
                        }
                    ],
                    timeFormatOptions: [
                        {
                            label: "yyyy-MM-dd",
                            value: "yyyy-MM-dd"
                        },
                        {
                            label: "yyyy-MM-dd HH:mm:ss",
                            value: "yyyy-MM-dd HH:mm:ss"
                        },
                        {
                            label: "yyyy/MM/dd",
                            value: "yyyy/MM/dd"
                        },
                        {
                            label: "yyyyMMddHHmmss",
                            value: "yyyyMMddHHmmss"
                        },
                        {
                            label: "yyyymmddhh24miss",
                            value: "yyyymmddhh24miss"
                        },
                        {
                            label: "毫秒数",
                            value: "0"
                        }
                    ]
                },

                //左侧菜单树
                groupTree: [],
                /**
                 * 请求路径
                 */
                urlManage: {
                    queryTreeNode: "/config1/queryStandardTreeList",
                    queryStandardRules: "/config1/queryStandardRules"

                },
                /**
                 * 分页器相关
                 */
                pagesizes: [10, 20, 30, 50],
                pagelayout: "total, sizes, prev, pager, next, jumper",
                pagination: {
                    pageNum: 1,              // 当前页
                    pageSize: 10,     // 每页显示条目个数
                    total: 0                // 总条数
                },
                //点击树节点
                clickTree: "",
                /**
                 * 表格相关
                 */
                /*tableData: [
                    {mdStandard: {"code":1,name:"11",dataType:"2"}},
                    {mdStandard: {"code":2,name:"11",dataType:"2"}}
                ],*/
                tableData: [],
                /**
                 * 表格搜索
                 */
                filterTableName: "",
                filterTableDataType: [],
                filterTableApproveStatus: [],

                selectedRows: [],

                // 编辑类别
                tableFormType: "",
                tableRowForm: {},
                //当前编辑行
                editTableRowFormNum: "",
                dialogVisible: false
            };
        },
        created() {

        },
        mounted() {
            this.initGroupTree();
        },
        computed: {},
        watch: {},

        methods: {
            /**
             * 初始化加载左侧菜单树
             */
            initGroupTree() {
                var this_ = this;
                this.$http
                    .post(
                        this.urlManage.queryTreeNode,
                        {
                            status: 1,
                            groupType: 1
                        }
                    )
                    .then(response => {
                        if (response.status == true) {
                            this.groupTree = response.data;
                        } else {
                            // 弹出提示
                            this.$message({
                                showClose: true,
                                message: response.exception.message
                            });
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            },
            /**
             * 左侧树点击事件
             */
            treeNodeClick(data) {
                this.clickTree = data.id;
                this.pagination.pageNum = 1;
                this.initStandardTableData();

            },
            /**
             * 查询按钮的事件
             */
            onSearch(val) {
                // 当前页
                this.pagination.pageNum = val ? val : 1;
                this.initStandardTableData();
            },
            /**
             * pagination相关事件
             */
            handleSizeChange(val) {
                this.pagination.pageSize = val;
                this.initStandardTableData();
            },
            /**
             * 加载标准列表
             */
            initStandardTableData() {
                var tmp = {
                    id: this.clickTree,
                    name: this.filterTableName,
                };
                var params = this.$merge({}, tmp, this.pagination);
                this.$http
                    .post(
                        this.urlManage.queryStandardRules,
                        params
                    )
                    .then(response => {
                        if (response.status == true) {
                            if (response.data.list == null) {
                                this.tableData = [];
                            } else {
                                this.tableData = response.data.list;
                            }
                            this.pagination.total = Number(response.data.total);
                        } else {
                            // 弹出提示
                            this.$message({
                                showClose: true,
                                message: response.errorCode
                            });
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });
            },

            /**
             * 编辑数据标准
             */
            editTableRow(index, row) {
                this.tableRowForm = row.mdStandard;
                this.dialogVisible = true
            },

            /**
             * 清空搜素框
             */
            clearSearch() {
                this.filterTableCode = "";
                this.filterTableName = "";
                this.filterTableDataType = [];
                this.filterTableApproveStatus = [];
            },
            changeDataType() {
                this.tableRowForm.dataLength = "";
                this.tableRowForm.dataPrecision = "";
                this.tableRowForm.timeFormat = "";
                this.tableRowForm.minLength = "";
                this.tableRowForm.maxLength = "";

            }
        }
    };
</script>
<style>
    .dm-panel-bodier.data-standard > div {
        height: calc(100%);
    }

    .dm-panel-bodier.data-standard .neu-table {
        height: calc(100% - 9em);
    }

    .dm-panel-bodier.data-standard .neu-table > .el-table {
        height: calc(100%);
    }

    .dm-panel-bodier.data-standard .el-table__body-wrapper {
        height: calc(100% - 4em);
        overflow-y: auto;
    }

    .neu-pagination {
        padding-bottom: 0;
    }
</style>
