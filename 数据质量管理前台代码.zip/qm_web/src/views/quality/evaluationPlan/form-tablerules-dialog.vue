<template>
    <moc-container>
        <moc-section class="p-r-80">
            <el-form :model="ruleForm" label-width="120px" ref="ruleForm" class="qm-form-horizontal" label-suffix="：">
                <el-form-item
                    label="规则名称"
                    prop="id"
                    :rules="{ required: true, message: '请选择', trigger: 'change' }"
                >
                    <el-select v-model="ruleForm.id" placeholder="请选择" filterable>
                        <el-option
                            v-for="(item, index) in options.rule"
                            :key="index"
                            :label="item.label"
                            :value="item.value"
                            :disabled="item.disabled"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item
                    label="字段"
                    prop="fields"
                    :rules="{ required: true, message: '请选择', trigger: 'change' }"
                >
                    <moc-all-select
                        v-model="ruleForm.fields"
                        :selectOptions="options.field"
                        filterable
                    >
                    </moc-all-select>
                </el-form-item>
                <el-form-item label="描述">
                    <el-input type="textarea" v-model="ruleForm.desc" rows="4"></el-input>
                </el-form-item>
            </el-form>
        </moc-section>
    </moc-container>

</template>
<script>
    /**
     * 混入对象
     */
    import common from '@/mixins/common.js'; // 通用  每个页面都需要引入

    export default {
        mixins: [common],
        props:{
            activeRow: '',
            selects: ''
        },
        data() {
            return {
                ruleForm: {
                    id: '',
                    ruleName: '',
                    fields: [],
                    fieldsName:'',
                    desc:''
                },
                oldId:'',
                options:{
                    rule:[
                        
                    ],
                    field:[
                        
                    ]
                }
            }
        },
        created() {
            if(this.activeRow){
                this.ruleForm = this.activeRow

                console.log( this.ruleForm )
                this.oldId = this.activeRow.id
            }
        },
        mounted() {
            this.initOptions();
        },
        methods: {
            
            /**
             * 确定、取消
             */
            onSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        for (let index = 0; index < this.options.rule.length; index++) {
                            const element = this.options.rule[index];
                            if(this.ruleForm.id === element.value){
                                this.ruleForm.ruleName = element.label
                                break;
                            }
                        }
                        let fieldsName = [];
                        for (let index = 0; index < this.options.field.length; index++) {
                            const element = this.options.field[index];
                            if(this.ruleForm.fields.indexOf(element.value) >= 0 ){
                                fieldsName.push( element.label )
                            }
                        }
                        this.ruleForm.fieldsName = fieldsName.join('，')

                        this.$emit('callback', true, this.ruleForm, this.oldId);
                        
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            onCancel() {
                this.$emit('callback', false);
            },

            
            initOptions(){
                this.options.field = this.selects.allFields
                this.options.rule = this.selects.tableRules
            }
        }
    }
</script>
