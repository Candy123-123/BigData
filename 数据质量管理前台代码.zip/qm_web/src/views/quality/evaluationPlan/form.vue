<template>
    <moc-container id="page-content">
        <moc-section>
            <div class="qm-vice-page-title">
                <a @click="onCancel()" href="javascript:;">
                    <i class="el-icon-arrow-left"></i> {{ this.option.id ? '修改 ' + option.name : '新建评估方案' }} 
                </a>
            </div>
        </moc-section>
        <moc-section class="qm-form">
            <el-form :model="newForm" ref="formRef" label-width="100px" class="qm-form-horizontal" label-suffix="：">
                <el-row :gutter="10">
                    <el-col :span="12">
                        <el-form-item
                            label="名称"
                            prop="name"
                            :rules="[
                                { required: true, message: '请输入名称', trigger: 'blur' }
                            ]"
                        >
                            <el-input v-model="newForm.name"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item
                            label="数据源"
                            prop="dataSource"
                            :rules="{ required: true, message: '请选择数据源', trigger: 'change' }"
                        >
                            <el-select v-model="newForm.dataSource" @change="dataSourceChange" :disabled="this.option.id?true:false" placeholder="请选择" filterable >
                                <el-option
                                    v-for="(option, index) in options.dataSource"
                                    :key="index"
                                    :label="option.label"
                                    :value="option.value"
                                    :disabled="option.disabled"
                                >
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-form-item label="描述">
                    <el-input type="textarea" v-model="newForm.descInfo" rows="4"></el-input>
                </el-form-item>
                <el-form-item v-if="newForm.dataSource" label="校验规则" required>
                    <el-collapse v-model="activeNames" class="qm-collapse">
                        <el-collapse-item title="字段级规则" name="1">
                            <div class="m-b-sm">
                                <el-button @click="onAddValidationRules()" :disabled="newForm.dataSource==''? true: false" type="primary" icon="el-icon-circle-plus-outline">添加</el-button>
                                <div class="qm-search-item">
                                    <span class="qm-search-label">规则名称：</span>
                                    <el-input v-model="validationRulesSearch" class="qm-search-input" clearable placeholder="搜索字段名称"></el-input>
                                </div>
                            </div>
                            <el-table :data="validationRulesTable" border stripe>
                                <el-table-column type="expand" width="50">
                                    <template slot-scope="scope">
                                        <ul class="qm-rule-list">
                                            <template v-for="(item, index) in scope.row.boundRule">
                                                <li v-if="item.ruleType === 1" :key="index">
                                                    <p>
                                                        <strong>规则：</strong>
                                                        <span>{{item.ruleLabel}}</span>
                                                        <span v-if="item.s_e_pos" class="m-l-xs" style="color: #999;">（{{item.s_e_pos}}）</span>
                                                    </p>
                                                    <div>
                                                        <strong>参数：</strong>
                                                        <span v-for="(param,idx) in item.params" :key="idx" class="m-r-xs">
                                                            <font>{{param.label}}：</font>
                                                            <font>{{param.text}}</font>
                                                            <font v-if="idx<item.params.length-1">，</font>
                                                        </span>
                                                    </div>
                                                </li>
                                                <li v-else-if="item.ruleType === 2" :key="index">
                                                    <p>
                                                        <strong>规则：</strong>
                                                        <span>{{item.ruleLabel}}</span>
                                                        <span v-if="item.s_e_pos" class="m-l-xs" style="color: #999;">（{{item.s_e_pos}}）</span>
                                                    </p>
                                                    <div v-for="(param,idx) in item.params" :key="idx" class="qm-rule-computed">
                                                        <strong>当：</strong>
                                                        <span v-for="(when,i) in param.when" :key="'when'+i" class="m-r-xs">
                                                            <font>{{when.fieldName}}</font>
                                                            <font> {{when.operatorName}} </font>
                                                            <font>{{when.valueName}}</font>
                                                            <font v-if="i<param.when.length-1">，</font>
                                                        </span>
                                                        <strong class="m-l-md">那么：</strong>
                                                        <span v-for="(then,i) in param.then" :key="'then'+i" class="m-r-xs">
                                                            <font>{{then.fieldName}}</font>
                                                            <font> {{then.operatorName}} </font>
                                                            <font>{{then.valueName}}</font>
                                                            <font v-if="i<param.then.length-1">，</font>
                                                        </span>
                                                    </div>
                                                </li>
                                            </template>
                                        </ul>
                                    </template>
                                </el-table-column>
                                <el-table-column label="序号" type="index" width="60" align="center"></el-table-column>
                                <el-table-column prop="ruleName" label="已绑定规则"></el-table-column>
                                <el-table-column prop="fieldName" label="字段名称"></el-table-column>
                                <el-table-column label="操作" width="218">
                                    <template slot-scope="scope">
                                        <el-link @click="onEntValidationRulesRow(scope.row)" type="primary">修改</el-link>
                                        <el-divider direction="vertical"></el-divider>
                                        <el-link @click="onDelValidationRulesRow(scope.$index)" type="danger">删除</el-link>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </el-collapse-item>
                        <el-collapse-item title="表级规则" name="2">
                            <div class="m-b-sm">
                                <el-button @click="onAddTableRules()" :disabled="newForm.dataSource==''? true: false" type="primary" icon="el-icon-circle-plus-outline">添加</el-button>
                            </div>
                            <el-table :data="newForm.tableRules" border stripe>
                                <el-table-column label="序号" type="index" width="60" align="center"></el-table-column>
                                <el-table-column prop="id" label="规则编码"></el-table-column>
                                <el-table-column label="规则名称">
                                    <template slot-scope="scope">
                                        <el-link @click="onLookTableRulesRow(scope.row)" type="primary">{{scope.row.ruleName}}</el-link>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="fieldsName" label="字段"></el-table-column>
                                <el-table-column label="操作" width="218">
                                    <template slot-scope="scope">
                                        <el-link @click="onEntTableRulesRow(scope.row)" type="primary">修改</el-link>
                                        <el-divider direction="vertical"></el-divider>
                                        <el-link @click="onDelTableRulesRow(scope.$index)" type="danger">删除</el-link>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </el-collapse-item>
                        <el-collapse-item title="筛选条件" name="3">
                            <el-row v-for="(item,i) in newForm.filterCondition" :key="i" :gutter="10" class="qm-filterCondition">
                                <span class="qm-form-required">*</span>
                                <el-col :span="8">
                                    <el-form-item
                                        :prop="'filterCondition.' + i + '.field'"
                                        :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                    >
                                        <el-select v-model="item.field" @change="getSettingName(1, item, options.enumFields)" placeholder="请选择" filterable>
                                            <el-option
                                                v-for="(option, index) in options.enumFields"
                                                :key="index"
                                                :label="option.label"
                                                :value="option.value"
                                                :disabled="option.disabled"
                                            >
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item
                                        :prop="'filterCondition.' + i + '.operator'"
                                        :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                    >
                                        <el-select v-model="item.operator" @change="getSettingName(2, item, options.operator)" placeholder="请选择" filterable>
                                            <el-option
                                                v-for="(option, index) in options.operator"
                                                :key="index"
                                                :label="option.label"
                                                :value="option.value"
                                                :disabled="option.disabled"
                                            >
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item
                                        :prop="'filterCondition.' + i + '.value'"
                                        :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                    >
                                        <el-select v-model="item.value" @change="getSettingName(3, item, filterValue[item.field])" placeholder="请选择" filterable>
                                            <el-option
                                                v-for="(option, index) in filterValue[item.field]"
                                                :key="index"
                                                :label="option.label"
                                                :value="option.value"
                                                :disabled="option.disabled"
                                            >
                                            </el-option>
                                        </el-select>
                                        <div class="qm-form-item-tools">
                                            <el-link @click="onDelFilterCondition(i)" type="danger"><i class="el-icon-remove"></i></el-link>
                                        </div>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-link @click="onAddFilterCondition()" :disabled="newForm.dataSource==''? true: false" type="primary">
                                <i class="el-icon-circle-plus"></i> 添加筛选条件
                            </el-link>
                        </el-collapse-item>
                        <el-collapse-item title="统计维度" name="4">
                            <el-row>
                                <el-col :span="8">
                                    <el-form-item label="统计维度">
                                        <el-select v-model="newForm.statistical" @change="setStatisticalName()" :disabled="newForm.dataSource==''? true: false" placeholder="请选择" clearable filterable>
                                            <el-option
                                                v-for="(option, index) in options.enumFields"
                                                :key="index"
                                                :label="option.label"
                                                :value="option.value"
                                                :disabled="option.disabled"
                                            >
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                        </el-collapse-item>
                    </el-collapse>
                </el-form-item>
                <el-form-item class="qm-form-btns">
                    <el-button @click="onSubmit('formRef')" type="primary">确定</el-button>
                    <el-button @click="onCancel()" >取消</el-button>
                </el-form-item>
            </el-form>
        </moc-section>

        <!-- 字段级规则 弹出框 -->
        <el-dialog
            title="添加字段级规则"
            :visible.sync="validationRulesVisible"
            width="660px"
            top="50px"
            append-to-body
            v-mocDialogDrag
        >
            <validation-dialog v-if="validationRulesVisible" :activeRow="validationRulesActive" :ruleNameArr="validationRulesNameArr" :selects="options" @callback="closeValidationRules" ref="validationDialog"></validation-dialog>
            <template #footer>
                <el-button @click="$refs.validationDialog.onCancel()">取 消</el-button>
                <el-button @click="$refs.validationDialog.onSubmit('ruleForm')" type="primary">确 定</el-button>
            </template>
        </el-dialog>
        <!-- 表级规则 弹出框 -->
        <el-dialog
            :title="tableRulesVisibleTit + '表级规则'"
            :visible.sync="tableRulesVisible"
            width="660px"
            top="50px"
            append-to-body
            v-mocDialogDrag
        >
            <tablerules-dialog v-if="tableRulesStatus === 'form'" :activeRow="tableRulesActive" :selects="options" @callback="closeTableRules" ref="tableRuleDialog"></tablerules-dialog>
            <tablerules-details v-else-if="tableRulesStatus === 'details'" :activeRow="tableRulesActive" @callback="closeTableRules" ref="tableRuleDialog"></tablerules-details>
            <template #footer>
                <el-button @click="$refs.tableRuleDialog.onCancel()">取 消</el-button>
                <el-button v-if="tableRulesStatus === 'form'" @click="$refs.tableRuleDialog.onSubmit('ruleForm')" type="primary">确 定</el-button>
            </template>
        </el-dialog>


    </moc-container>
</template>
<script>
    /**
     * 混入对象
     */
    import common from '@/mixins/common.js'; // 通用  每个页面都需要引入

    export default {
        components: {
            validationDialog:()=>import('./form-validation-dialog.vue'),
            tablerulesDialog:()=>import('./form-tablerules-dialog.vue'),
            tablerulesDetails:()=>import('./form-tablerules-details.vue')
        },
        props:{
            groupId: '',
            option: '',
        },
        mixins: [common],
        data() {
            return {
                newForm: {
                    id: '',
                    groupId: this.groupId,
                    name: '',
                    dataSource: '',
                    dataSourceName: '',
                    descInfo: '',
                    validationRules:[
                        // {
                        //     id: 'validationRules-5151515',
                        //     ruleName: '86开头主、被叫号码',          // 校验项规则
                        //     field:'15155',                          // 规则作用字段
                        //     fieldName:'src_addr(样本的主叫号码)',    // 规则作用字段
                        //     ruleType: 1,                            // 1 基础规则后台提供 2添加的规则
                        //     boundRule:[
                        //         {
                        //             ruleLabel: '1,2',               // 规则名称
                        //             ruleValue: '121215',            // 规则ID
                        //             s_e_pos:'开始位置,结束位置(如1，2)',
                        //             ruleType: '1',                    // 规则类型
                        //             params:[                        // 参数
                        //                 {
                        //                     label:'主叫号码',
                        //                     type: 'select',
                        //                     value: '151515',
                        //                     text: '86'
                        //                 },
                        //                 {
                        //                     label:'prov_code 上报省份',
                        //                     type: 'input',
                        //                     value: '151515',
                        //                     text: '辽宁'
                        //                 }
                        //             ]
                        //         },
                        //         {
                        //             ruleLabel: '前缀匹配',
                        //             ruleValue: '121215',
                        //             s_e_pos:'开始位置,结束位置(如1，2)',
                        //             ruleType: '2',
                        //             params:[
                        //                 {
                        //                     when: [                 // 当
                        //                         {
                        //                             field:'字段1',
                        //                             fieldName:'字段1',
                        //                             operator:'操作符',
                        //                             operatorName:'操作符',
                        //                             value:'字段2',
                        //                             valueName:'字段2',
                        //                             type: ''
                        //                         },
                        //                         {
                        //                             field:'字段1',
                        //                             fieldName:'字段1',
                        //                             operator:'操作符',
                        //                             operatorName:'操作符',
                        //                             value:'字段2',
                        //                             valueName:'字段2',
                        //                             type: ''
                        //                         }
                        //                     ],
                        //                     then: [             // 那么
                        //                         {
                        //                             field:'字段1',
                        //                             fieldName:'字段1',
                        //                             operator:'操作符',
                        //                             operatorName:'操作符',
                        //                             value:'字段2',
                        //                             valueName:'字段2',
                        //                             type: ''
                        //                         },
                        //                         {
                        //                             field:'字段1',
                        //                             fieldName:'字段1',
                        //                             operator:'操作符',
                        //                             operatorName:'操作符',
                        //                             value:'字段2',
                        //                             valueName:'字段2',
                        //                             type: ''
                        //                         }
                        //                     ]
                        //                 },
                        //                 {
                        //                     when: [                 // 当
                        //                         {
                        //                             field:'字段1',
                        //                             fieldName:'字段1',
                        //                             operator:'操作符',
                        //                             operatorName:'操作符',
                        //                             value:'字段2',
                        //                             valueName:'字段2',
                        //                             type: ''
                        //                         },
                        //                         {
                        //                             field:'字段1',
                        //                             fieldName:'字段1',
                        //                             operator:'操作符',
                        //                             operatorName:'操作符',
                        //                             value:'字段2',
                        //                             valueName:'字段2',
                        //                             type: ''
                        //                         }
                        //                     ],
                        //                     then: [             // 那么
                        //                         {
                        //                             field:'字段1',
                        //                             fieldName:'字段1',
                        //                             operator:'操作符',
                        //                             operatorName:'操作符',
                        //                             value:'字段2',
                        //                             valueName:'字段2',
                        //                             type: ''
                        //                         },
                        //                         {
                        //                             field:'字段1',
                        //                             fieldName:'字段1',
                        //                             operator:'操作符',
                        //                             operatorName:'操作符',
                        //                             value:'字段2',
                        //                             valueName:'字段2',
                        //                             type: ''
                        //                         }
                        //                     ]
                        //                 }
                        //             ]
                        //         }
                        //     ]
                        // }
                    ],
                    tableRules:[
                        // {
                        //     id: '561188624013029376',           // 规则id
                        //     ruleName: 'call_result',            // 规则名称
                        //     fields: ['561188968042426368'],      // 字段id
                        //     fieldsName:'singalflag',             // 字段name
                        //     desc:'描述描述描述描述描述描述描述描述描述'
                        // }
                    ],
                    filterCondition:[
                        // {
                        //     field:'',
                        //     fieldName:'',
                        //     operator:'',
                        //     operatorName:'',
                        //     value:'',
                        //     valueName:''
                        // }
                    ],
                    statistical: '',
                    statisticalName: ''
                },


                activeNames: ['1', '2', '3', '4'],



                /**
                 * 字段级规则
                 */
                validationRulesNameArr: [],             // 已有规则名称集合
                validationRulesSearch: "",              // 搜索框内容
                validationRulesActive: "",              // 选中的内容
                validationRulesVisible: false,          // 新增弹出框的状态

                /**
                 * 表级规则
                 */
                tableRulesActive: "",          // 选中的内容
                tableRulesVisible: false,      // 新增弹出框的状态
                tableRulesVisibleTit: '',      // 弹出框的标题
                tableRulesStatus: '',          // 查看详情 or 新增



                filterValue: {},            // 筛选条件第3个
                options:{
                    dataSource: [],          // 数据源
                    basicRules: [],          // 字段级规则
                    tableRules: [],          // 表级规则
                    enumFields: [],          // 每局类型  筛选条件第1个、统计维度
                    operator: [],            // 所有的操作符
                    allFields: [],           // 全部字段
                    ruleSel: []              // 规则的参数
                }
            }
        },
        computed:{
            /**
             * 字段级规则
             */
            validationRulesTable: function(){
                return this.newForm.validationRules.filter( (item)=> {
                    if( item.fieldName == null ){
                        item.fieldName = '';
                    }
                    if( item.fieldName.search(this.validationRulesSearch) !== -1 ){
                        return item
                    }
                })
            }
        },
        created() {
            this.initSources();
            if( this.option.id ){
                this.initSchemaDetail();
            }
        },
        mounted() {
        },

        methods: {
            /**
             * 字段级规则 增、删、改
             */
            onAddValidationRules(){
                this.tableRulesVisibleTit = ''
                this.validationRulesActive = ''
                this.validationRulesNameArr = []
                this.newForm.validationRules.forEach(element => {
                    this.validationRulesNameArr.push(element.ruleName)
                });
                this.validationRulesVisible = true
            },
            closeValidationRules(type, row){
                if(type){
                    let stutas = true
                    for (let index = 0; index < this.newForm.validationRules.length; index++) {
                        const element = this.newForm.validationRules[index];
                        if(row.id === element.id){
                            stutas = false


                            console.log( row )
                            this.$set(this.newForm.validationRules, index, row)
                            break;
                        }
                    }
                    if( stutas ){
                        this.newForm.validationRules.push(row)
                    }
                    console.log( this.newForm.validationRules, Math.random() )
                }
                this.validationRulesVisible = false
            },
            onDelValidationRulesRow(index){
                this.newForm.validationRules.splice(index, 1)
            },
            onEntValidationRulesRow(row){
                this.validationRulesActive = this.$lodash.cloneDeep(row);
                this.validationRulesVisible = true
            },


            /**
             * 字段级规则 增、删、改、查
             */
            onAddTableRules(){
                this.tableRulesActive = ''
                this.tableRulesVisibleTit = '添加'
                this.tableRulesStatus = 'form'
                this.tableRulesVisible = true
            },
            closeTableRules(type, row, oldId){
                if( type ){
                    if( oldId ){
                        for (let index = 0; index < this.newForm.tableRules.length; index++) {
                            const element = this.newForm.tableRules[index];
                            if( oldId === element.id ){
                                this.$set(this.newForm.tableRules, index, row)
                                break;
                            }
                        }
                    }else{
                        this.newForm.tableRules.push(row)
                    }
                }
                this.tableRulesStatus = ''
                this.tableRulesVisible = false
            },
            onDelTableRulesRow(index){
                this.newForm.tableRules.splice(index, 1)
            },
            onEntTableRulesRow(row){
                this.tableRulesActive = this.$lodash.cloneDeep(row)
                this.tableRulesVisibleTit = '修改'
                this.tableRulesStatus = 'form'
                this.tableRulesVisible = true
            },
            onLookTableRulesRow(row){
                this.tableRulesActive = this.$lodash.cloneDeep(row)
                this.tableRulesVisibleTit = '查看'
                this.tableRulesStatus = 'details';
                this.tableRulesVisible = true
            },

            /**
             * 筛选条件 增、删
             */
            onAddFilterCondition(){
                let obj = {
                    field:'',
                    fieldName:'',
                    operator:'',
                    operatorName:'',
                    value:'',
                    valueName:''
                };
                this.newForm.filterCondition.push( obj )
            },
            onDelFilterCondition(index){
                this.newForm.filterCondition.splice(index, 1)
            },
            getSettingName( num, obj,options){
                for (let index = 0; index < options.length; index++) {
                    const element = options[index];
                    if( num === 1 && element.value === obj.field ){
                        obj.fieldName = element.label
                        break;   
                    }else if( num === 2 && element.value === obj.operator ){
                        obj.operatorName = element.label
                        break;   
                    }else if( num === 3 && element.value === obj.value ){
                        obj.valueName = element.label
                        break;   
                    }
                }
            },

            /**
             * 设置 统计维度 的 name
             */
            setStatisticalName(){
                for (let index = 0; index < this.options.enumFields.length; index++) {
                    const element = this.options.enumFields[index];
                    if(element.value === this.newForm.statistical){
                        this.newForm.statisticalName = element.label
                    }
                }
            },
            /**
             * 确定、取消
             */
            onSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        if( this.option.id ){
                            this.$http.post('/business/modSchemaListList', this.newForm).then( res => {
                                this.$message.success('修改成功');
                                this.$emit('after-callback', true);
                            });
                        }else{
                            this.$http.post('/business/addSchemaListList', this.newForm).then( res => {
                                this.$message.success('添加成功');
                                this.$emit('after-callback', true);
                            });
                        }
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            onCancel() {
                this.$emit('after-callback', false);
            },


            /**
             * 根据数据源获取数据
             */
            dataSourceChange(val){
                let paramsBasicRules = {
                        dataSource: val,
                        type:'queryBasicRules'
                    },
                    paramsOperators = {
                        dataSource: val,
                        type:'queryOperators'
                    },
                    paramsSourceFields = {
                        dataSource: val,
                        type:'querySourceFields'
                    };
                let ajaxArr= [
                    this.$http.post('/business/querySchemaComboxByType', paramsBasicRules),
                    this.$http.post('/business/querySchemaComboxByType', paramsOperators),
                    this.$http.post('/business/querySchemaComboxByType', paramsSourceFields)
                ];
                this.$http.all(ajaxArr).then(this.$http.spread((basicRules, operators, sourceFields)=> {
                    this.options.basicRules = basicRules.data.basic_rules
                    this.options.tableRules = basicRules.data.table_rules
                    this.options.enumFields = sourceFields.data.enumFields
                    this.options.enumFields.forEach(element=>{
                        if( element.enumList ){
                            this.filterValue[element.value] = element.enumList
                        }
                    })
                    this.options.operator = operators.data
                    this.options.allFields = sourceFields.data.allFields
                    this.options.ruleSel = sourceFields.data.ruleSel
                    // console.log(sourceFields.data.fieldBindRule)

                    if( !this.option.id ){
                        this.newForm.validationRules = sourceFields.data.fieldBindRule
                    }
                }));
            },
            /**
             * 查询数据源
             */
            initSources(){
                let params = { type:'querySources' };
                this.$http.post('/business/querySchemaComboxByType', params).then( res => {
                    // console.log(res.data)
                    this.options.dataSource = res.data
                });
            },
            initSchemaDetail(){
                let params = { id: this.option.id };
                this.$http.post('/business/querySchemaDetail', params).then( res => {
                    console.log(res.data)
                    this.newForm = res.data
                    this.dataSourceChange(this.newForm.dataSource)
                });
            }
        }
    }
</script>
