<template>
    <moc-container>
        <moc-section>
            <el-form :model="ruleForm" ref="ruleForm" label-width="140px" class="qm-form-horizontal" label-suffix="：">
                <el-form-item
                    label="编码"
                    prop="name"
                >
                    <el-input v-model="ruleForm.name"></el-input>
                </el-form-item>
                <el-form-item
                    label="名称"
                    prop="name"
                >
                    <el-input v-model="ruleForm.name"></el-input>
                </el-form-item>
                <el-form-item
                    label="类型校验"
                    prop="name"
                >
                    <el-select
                        v-model="ruleForm.name"
                        placeholder="请选择"
                        filterable
                    >
                        <el-option
                            v-for="(item, index) in options.type"
                            :key="index"
                            :label="item.label"
                            :value="item.value"
                            :disabled="item.disabled"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item
                    label="长度校验"
                    prop="name"
                >
                    <div class="moc-form-stage">
                        <el-input v-model="ruleForm.name"></el-input>
                        <span class="qm-form-label-static">-</span>
                        <el-input v-model="ruleForm.name"></el-input>
                    </div>
                </el-form-item>

                <el-form-item
                    label="是否必填"
                    prop="name"
                >
                    <el-select
                        v-model="ruleForm.name"
                        placeholder="请选择"
                        filterable
                    >
                        <el-option
                            v-for="(item, index) in options.type"
                            :key="index"
                            :label="item.label"
                            :value="item.value"
                            :disabled="item.disabled"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>
            </el-form>
        </moc-section>
    </moc-container>

</template>
<script>
    /**
     * 混入对象
     */
    import common from '@/mixins/common.js'; // 通用  每个页面都需要引入

    export default {
        mixins: [common],
        data() {
            return {
                ruleForm: {
                    name: '',
                    desc: ''
                },
                options:{
                    type:[
                        {
                            "label":"call_result",
                            "value":"561188624013029376"
                        },
                        {
                            "label":"cause",
                            "value":"561188868805193728"
                        },
                        {
                            "label":"singalflag",
                            "value":"561188968042426368"
                        },
                        {
                            "label":"illegal_type",
                            "value":"561189136057856000"
                        }
                    ],
                    rangeOptions:[
                        {
                            "label":"国际信令",
                            "value":"561147351516409856",
                            "children":[
                                {
                                    "label":"call_result",
                                    "value":"561188624013029376"
                                },
                                {
                                    "label":"cause",
                                    "value":"561188868805193728"
                                },
                                {
                                    "label":"singalflag",
                                    "value":"561188968042426368"
                                },
                                {
                                    "label":"illegal_type",
                                    "value":"561189136057856000"
                                }
                            ]
                        },
                        {
                            "label":"通用",
                            "value":"561148266281529344",
                            "children":[
                                {
                                    "label":"time_yyyyMMddHHmmss",
                                    "value":"561152603288334336"
                                },
                                {
                                    "label":"毫秒数",
                                    "value":"561480020213198848"
                                },
                                {
                                    "label":"province",
                                    "value":"561562300151590912"
                                },
                                {
                                    "label":"operator",
                                    "value":"562214180569575424"
                                },
                                {
                                    "label":"time_yyyyMMddHH",
                                    "value":"576855602077724672"
                                }
                            ]
                        }
                    ],
                    rootOptions:{
                        value: 'all-options',
					    label: '所有资源'
                    }
                }
            }
        },
        created() {

        },
        mounted() {
            this.initOptions();
        },
        methods: {
            selectOptions(){

            },
            /**
             * 确定、取消
             */
            onSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        

                        this.$emit('after-callback', true);
                        
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
                
            },
            onCancel() {
                this.$emit('after-callback', false);
            },

            
            initOptions(){
                console.log('初始化固定数据')
            }
        }
    }
</script>
