<template>
    <moc-container>
        <moc-section class="p-r-80">
            <el-form label-width="120px" ref="ruleForm" class="qm-form-horizontal qm-form-details" label-suffix="：">
                <el-form-item label="规则名称">
                    <p class="qm-form-text">{{activeRow.ruleName}}</p>
                </el-form-item>
                <el-form-item label="字段">
                    <p class="qm-form-text">{{activeRow.fieldsName}}</p>
                </el-form-item>
                <el-form-item label="描述">
                    <p class="qm-form-text">{{activeRow.desc}}</p>
                </el-form-item>
            </el-form>
        </moc-section>
    </moc-container>

</template>
<script>
    /**
     * 混入对象
     */
    import common from '@/mixins/common.js'; // 通用  每个页面都需要引入

    export default {
        mixins: [common],
        props:{
            activeRow: ''
        },
        data() {
            return {}
        },
        created() {

        },
        mounted() {
            this.initOptions();
        },
        methods: {
            
            /**
             * 确定、取消
             */
            onSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        

                        this.$emit('callback', true);
                        
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            onCancel() {
                this.$emit('callback', false);
            },

            
            initOptions(){
                console.log('初始化固定数据')
            }
        }
    }
</script>
