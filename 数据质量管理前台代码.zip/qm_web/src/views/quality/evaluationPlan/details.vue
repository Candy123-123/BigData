<template>
    <moc-container id="page-content">
        <moc-section>
            <div class="qm-vice-page-title">
                <a @click="onCancel()" href="javascript:;">
                    <i class="el-icon-arrow-left"></i>查看 {{option.name}}
                </a>
            </div>
        </moc-section>
        <moc-section class="qm-form">
            <el-form :model="newForm" ref="formRef" label-width="100px" class="qm-form-horizontal qm-form-details" label-suffix="：">
                <el-row :gutter="10">
                    <el-col :span="12">
                        <el-form-item label="名称">
                            <p class="qm-form-text">{{newForm.name}}</p>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="数据源">
                            <p class="qm-form-text">{{newForm.dataSourceName}}</p>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-form-item label="描述">
                    <p class="qm-form-text">{{newForm.descInfo}}</p>
                </el-form-item>
                <el-form-item label="校验规则" required>
                    <el-collapse v-model="activeNames" class="qm-collapse">
                        <el-collapse-item title="字段级规则" name="1">
                            <div class="m-b-sm">
                                <div class="qm-search-item">
                                    <span class="qm-search-label">规则名称：</span>
                                    <el-input v-model="validationRulesSearch" class="qm-search-input" clearable placeholder="搜索字段名称"></el-input>
                                </div>
                            </div>
                            <el-table :data="validationRulesTable" border stripe>
                                <el-table-column type="expand" width="50">
                                    <template slot-scope="scope">
                                        <ul class="qm-rule-list">
                                            <template v-for="(item, index) in scope.row.boundRule">
                                                <li v-if="item.ruleType === 1" :key="index">
                                                    <p>
                                                        <strong>规则：</strong>
                                                        <span>{{item.ruleLabel}}</span>
                                                        <span v-if="item.s_e_pos" class="m-l-xs" style="color: #999;">（{{item.s_e_pos}}）</span>
                                                    </p>
                                                    <div>
                                                        <strong>参数：</strong>
                                                        <span v-for="(param,idx) in item.params" :key="idx" class="m-r-xs">
                                                            <font>{{param.label}}：</font>
                                                            <font>{{param.text}}</font>
                                                            <font v-if="idx<item.params.length-1">，</font>
                                                        </span>
                                                    </div>
                                                </li>
                                                <li v-else-if="item.ruleType === 2" :key="index">
                                                    <p>
                                                        <strong>规则：</strong>
                                                        <span>{{item.ruleLabel}}</span>
                                                        <span v-if="item.s_e_pos" class="m-l-xs" style="color: #999;">（{{item.s_e_pos}}）</span>
                                                    </p>
                                                    <div v-for="(param,idx) in item.params" :key="idx" class="qm-rule-computed">
                                                        <strong>当：</strong>
                                                        <span v-for="(when,i) in param.when" :key="'when'+i" class="m-r-xs">
                                                            <font>{{when.fieldName}}</font>
                                                            <font> {{when.operatorName}} </font>
                                                            <font>{{when.valueName}}</font>
                                                            <font v-if="i<param.when.length-1">，</font>
                                                        </span>
                                                        <strong class="m-l-md">那么：</strong>
                                                        <span v-for="(then,i) in param.then" :key="'then'+i" class="m-r-xs">
                                                            <font>{{then.fieldName}}</font>
                                                            <font> {{then.operatorName}} </font>
                                                            <font>{{then.valueName}}</font>
                                                            <font v-if="i<param.then.length-1">，</font>
                                                        </span>
                                                    </div>
                                                </li>
                                            </template>
                                        </ul>
                                    </template>
                                </el-table-column>
                                <el-table-column label="序号" type="index" width="60" align="center"></el-table-column>
                                <el-table-column prop="ruleName" label="已绑定规则"></el-table-column>
                                <el-table-column prop="fieldName" label="字段名称"></el-table-column>
                            </el-table>
                        </el-collapse-item>
                        <el-collapse-item title="表级规则" name="2">
                            <el-table :data="newForm.tableRules" border stripe>
                                <el-table-column label="序号" type="index" width="60" align="center"></el-table-column>
                                <el-table-column prop="id" label="规则编码"></el-table-column>
                                <el-table-column label="规则名称">
                                    <template slot-scope="scope">
                                        <el-link @click="onLookTableRulesRow(scope.row)" type="primary">{{scope.row.ruleName}}</el-link>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="fieldName" label="字段"></el-table-column>
                            </el-table>
                        </el-collapse-item>
                        <el-collapse-item title="筛选条件" name="3">
                            <!-- <el-row v-for="(item,i) in newForm.filterCondition" :key="i" :gutter="10" class="qm-filterCondition">
                                <el-col :span="8">
                                    <el-form-item>
                                        <p class="qm-form-text">{{item.fieldName}}</p>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item>
                                        <p class="qm-form-text">{{item.operatorName}}</p>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item>
                                        <p class="qm-form-text">{{item.valueName}}</p>
                                    </el-form-item>
                                </el-col>
                            </el-row> -->
                            <el-form-item v-for="(item,i) in newForm.filterCondition" :key="i">
                                <p class="qm-form-text">{{item.fieldName}} {{item.operatorName}} {{item.valueName}}</p>
                            </el-form-item>
                        </el-collapse-item>
                        <el-collapse-item title="统计维度" name="4">
                            <el-row>
                                <el-col :span="8">
                                    <el-form-item label="统计维度">
                                        <p class="qm-form-text">{{newForm.statisticalName}}</p>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                        </el-collapse-item>
                    </el-collapse>
                </el-form-item>
                <el-form-item class="qm-form-btns">
                    <el-button @click="onCancel()" >取消</el-button>
                </el-form-item>
            </el-form>
        </moc-section>


        <!-- 表级规则 弹出框 -->
        <el-dialog
            :title="'查看 ' + tableRulesActive.ruleName"
            :visible.sync="tableRulesVisible"
            width="660px"
            top="50px"
            append-to-body
            v-mocDialogDrag
        >
            <tablerules-details :activeRow="tableRulesActive" @callback="closeTableRules" ref="tableRuleDialog"></tablerules-details>
            <template #footer>
                <el-button @click="$refs.tableRuleDialog.onCancel()">取 消</el-button>
            </template>
        </el-dialog>


    </moc-container>
</template>
<script>
    /**
     * 混入对象
     */
    import common from '@/mixins/common.js'; // 通用  每个页面都需要引入

    export default {
        props:{
            option:{}
        },
        components: {
            validationDialog:()=>import('./form-validation-dialog.vue'),
            tablerulesDialog:()=>import('./form-tablerules-dialog.vue'),
            tablerulesDetails:()=>import('./form-tablerules-details.vue')
        },
        mixins: [common],
        data() {
            return {
                newForm: {
                    id: '',
                    groupId: this.groupId,
                    name: '',
                    dataSource: '',
                    dataSourceName: '',
                    descInfo: '',
                    validationRules:[
                        
                    ],
                    tableRules:[
                        
                    ],
                    filterCondition:[
                        
                    ],
                    statistical: '',
                    statisticalName: ''
                },





                activeNames: ['1', '2', '3', '4'],

                 /**
                 * 字段级规则
                 */
                validationRulesSearch: "",              // 搜索框内容
                /**
                 * 表级规则
                 */
                tableRulesActive: "",          // 选中的内容
                tableRulesVisible: false,      // 新增弹出框的状态
                
            }
        },
        computed:{
            /**
             * 字段级规则
             */
            validationRulesTable: function(){
                return this.newForm.validationRules.filter( (item)=> {
                    if( item.fieldName == null ){
                        item.fieldName = '';
                    }
                    if( item.fieldName.search(this.validationRulesSearch) !== -1 ){
                        return item
                    }
                })
            }
        },
        created() {

        },
        mounted() {
            this.initSchemaDetail();
        },

        methods: {
            
            onLookTableRulesRow(row){
                this.tableRulesActive = this.$lodash.cloneDeep(row)
                this.tableRulesVisible = true
            },
            closeTableRules(type, row, oldId){
                this.tableRulesVisible = false
                this.tableRulesActive = ''
            },


            /**
             * 取消
             */
            onCancel() {
                this.$emit('after-callback', false);
            },


            /**
             * 查询数据源
             */
            initSchemaDetail(){
                let params = { id: this.option.id };
                this.$http.post('/business/querySchemaDetail', params).then( res => {
                    this.newForm = res.data
                    console.log(res.data)
                });
            }
        }
    }
</script>
