<template>
    <main id="page-multiple">
        <moc-container v-if="showPage==='page'" flex horizontal id="page-content">
            <dm-group-tree
                :groupTree="groupTree"
                title="分组"
                ref="qmGroupTree"
                treeType="tag"
                showHeader
                nodeTools
                search
                appendRoot
                :default-expanded-keys="['root']"
                @tree-node-click="treeNodeClick"
                @tree-node-deleted="treeNodeDeleted"
                @add-append-node="addAppendNode"
            ></dm-group-tree>
            <moc-section bodier>
                <moc-container flex id="page-wrap">
                    <moc-section class="qm-search">
                        <el-form :model="search" :inline="true" label-width="100px" label-suffix="：">
                            <el-form-item label="方案名称">
                                <el-input v-model="search.name" clearable placeholder="请输入"></el-input>
                            </el-form-item>
                            <el-form-item class="qm-search-btns">
                                <el-button @click="initTableData()" type="primary">查询</el-button>
                            </el-form-item>
                        </el-form>
                    </moc-section>

                    <moc-section class="qm-buttons">
                        <el-button @click="onAdd()" type="primary" icon="el-icon-circle-plus-outline">新增</el-button>
                        <el-button @click="onModify()" type="primary" icon="el-icon-edit-outline">修改</el-button>
                        <el-button @click="onRemove()" icon="el-icon-delete">删除</el-button>
                    </moc-section>
                
                    <moc-section id="project-table" bodier class="qm-table">
                        <el-table
                            :data="tableData"
                            :height="tableHeight"
                            v-loading="tableLoading"
                            border
                            stripe
                            @selection-change="handleSelectedRows"
                        >
                            <el-table-column label="序号" type="index" :index="handleIndex" :width="tableIndexWidth" align="center"></el-table-column>
                            <el-table-column type="selection" width="50" align="center"></el-table-column>
                            <el-table-column label="方案名称" prop="name" width="256">
                                <template slot-scope="scope">
                                    <el-link @click="onDetails(scope.row)" type="primary">{{scope.row.name}}</el-link>
                                </template>
                            </el-table-column>
                            <el-table-column label="描述" prop="descInfo"></el-table-column>
                            <el-table-column label="修改时间" prop="timesamp" width="186"></el-table-column>
                        </el-table>
                    </moc-section>
                    <moc-section class="qm-pagination">
                        <el-pagination
                            :current-page.sync="pagination.current"
                            :page-size.sync="pagination.size"
                            @current-change="initTableData()"
                            @size-change="initTableData()"
                            :total="tableTotal"
                            :layout="$global.paginationLayout"
                            :page-sizes="$global.paginationSizes"
                            background
                        >
                        </el-pagination>
                    </moc-section>
                </moc-container>
            </moc-section>
        </moc-container>
        <vice-form :groupId="search.groupId" :option="activeRow" @after-callback="formCallback" v-else-if="showPage==='form'"></vice-form>
        <vice-details :option="activeRow" @after-callback="formCallback" v-else-if="showPage==='details'"></vice-details>
    </main>
</template>
<script>

    /**
     * 混入对象
     */
    // 页面通用的
    import common from '@/mixins/common.js';
    // 表格通用的
    import tableCommon from '@/mixins/tableCommon.js';
    // 表格数据格式化
    import tableFormatter from '@/mixins/tableFormatter.js';

    export default {
        mixins:[
            common,
            tableCommon,
            tableFormatter
        ],
        components: {
            viceForm:()=>import('./form.vue'),
            viceDetails:()=>import('./details.vue'),
            dmGroupTree: () => import("@/views/components/group-tree/main.vue")
        },
        data () {
			return {
                showPage: 'page',

                /**
                 * 左侧菜单树
                 */
                groupTree: [
                    {
                        id: 'root',
                        label: '全部',
                        children:[
                            // {
                            //     id: '11',
                            //     label: '111'
                            // },
                            // {
                            //     id: '22',
                            //     label: '222'
                            // },
                            // {
                            //     id: '33',
                            //     label: '333'
                            // }
                        ]
                    }
                ],

                /**
                 * 搜索条件
                 */
                search: {
                    groupId: 0,
                    name: ''
                },
                /**
                 * 表格相关数据
                 */
				tableData: [],
				tableTotal: 0,
				selectedRows: [],
                activeRow:{},



                
                /**
                 * 下拉、单选、多选等的数据
                 */
                options:{
                    
                }
			}
        },
        created(){
            this.initGroupList();
        },
        mounted () {
        },
        methods:{
            /**
             * 左侧树
             */
            treeNodeClick(data) {
                if(data.id === "root"){
                    this.search.groupId = 0
                    this.initTableData()
                }else{
                    if( !data.children || data.children.length==0 ){
                        this.search.groupId = data.id
                        this.initTableData()
                    }
                }
            },
            treeNodeDeleted(data) {
                // console.log( data )
                this.$http.post('/business/delGroupList', data).then( res => {
                    this.$message.success('删除成功');
                    this.$refs.qmGroupTree.deleteNode(data)
                });
            },
            addAppendNode(data) {
                // console.log(data)
                this.$http.post('/business/addGroupList', data).then( res => {
                    this.$message.success('添加成功');
                    this.initGroupList()
                });

            },
            /**
             * 增、删、改、查
             */
            onAdd(){
                this.showPage = "form"
                this.activeRow = {}
            },
            onRemove(){
                // console.log(this.selectedRows)
                if( this.selectedRows.length > 0 ){
                    var params = {
                        id: []
                    };
                    this.selectedRows.forEach( (el)=>{
                        params.id.push( el.id );
                    } );
                    this.$confirm('此操作将永久删除, 是否继续?', '系统提示', {
                        type: 'warning'
                    }).then(() => {
                        this.$http.post('/business/delSchemaListList', params).then( res => {
                            this.$message.success('删除成功');
                            this.initTableData();
                        });
                    }).catch(() => {
                             
                    });
                }else{
                    this.$alert('请至少选择一条记录进行删除', '系统提示', {
                        callback: action => {}
                    });
                }
            },
            onModify(){
                if( this.selectedRows.length === 1 ){
                    // console.log(this.selectedRows[0])
                    this.activeRow = this.selectedRows[0]
                    this.showPage = "form"
                }else{
                    this.$alert('请选择一条记录进行修改', '系统提示', {
                        callback: action => {}
                    });
                }
            },
            onDetails(row){
                this.showPage = "details"
                this.activeRow = row
                console.log(row)
            },
            formCallback(type){
                if(type){
                    this.initTableData()
                }
                this.showPage = "page"
                this.activeRow = {}
            },
            
            /**
             * 搜索事件
             */
            onSearch(){
                this.pagination.current = 1;
            
            },
            /**
             * table 的相关事件
             */
            handleSelectedRows(rows){
                this.selectedRows = rows;
            },


            /**
             * 查询分组信息
             */
            initGroupList(){
                this.$http.post('/business/queryGroupList').then( res => {
                    // console.log(res.data)
                    this.groupTree[0].children = res.data
                    this.initTableData()
                });
            },
            /**
             * 初始化表格数据
             */
            initTableData(){
                let params = { ...this.search, ...this.pagination };
                // console.log( params )
                this.$http.post('/business/querySchemaList', params).then( res => {
                    // console.log( res.data )
                    this.tableData = res.data.list;
                    this.tableTotal = Number(res.data.total);
                });
            },
        }
    }
</script>
