<template>
    <moc-container>
        <moc-section class="p-r-80">
            <el-form :model="ruleForm" ref="ruleForm" class="qm-form-horizontal" label-suffix="：">
                <el-form-item
                    label="校验项规则"
                    prop="ruleName"
                    label-width="140px"
                    :rules="[
                        { required: true, message: '请输入', trigger: 'blur' },
                        { validator: validateRule, trigger: 'blur' }
                    ]"
                >
                    <el-input v-model="ruleForm.ruleName"></el-input>
                </el-form-item>
                <el-form-item
                    label="规则作用字段"
                    prop="field"
                    label-width="140px"
                    :rules="{ required: true, message: '请选择', trigger: 'change' }"
                >
                    <el-select v-model="ruleForm.field" placeholder="请选择" filterable>
                        <el-option
                            v-for="(option, index) in options.field"
                            :key="index"
                            :label="option.label"
                            :value="option.value"
                            :disabled="option.disabled"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>
                <div v-for="(item, index) in ruleForm.boundRule" :key="index">
                    <el-form-item
                        label="规则"
                        :prop="'boundRule.' + index + '.ruleValue'"
                        :rules="{ required: true, message: '请选择', trigger: 'change' }"
                        label-width="160px"
                    >
                        <el-select v-model="item.ruleValue" @change="changeRule(item)" placeholder="请选择" filterable>
                            <el-option
                                v-for="(option, index) in options.rule"
                                :key="index"
                                :label="option.label"
                                :value="option.value"
                                :disabled="option.disabled"
                            >
                            </el-option>
                        </el-select>
                        <div class="qm-form-item-tools">
                            <el-link v-if="ruleForm.boundRule.length>1" @click="onDelRow(ruleForm.boundRule, index)" type="danger"><i class="el-icon-remove"></i></el-link>
                        </div>
                    </el-form-item>

                    <!-- 常规参数 -->
                    <el-form-item v-if="item.ruleType === 1 && item.params.length>0" label="参数" required label-width="160px">

                        <el-form-item
                            v-for="(param, idx) in item.params" :key="idx"
                            :prop="'boundRule.' + index + '.params.' + idx + '.value' "
                            :rules="{ required: true, message: param.type === 'input' ? '请输入' : '请选择', trigger: param.type === 'input' ? 'blur' : 'change' }"
                        >
                            <el-input v-if="param.type === 'input'" v-model="param.value" @blur="paramValueBlur(param)" :placeholder="param.label"></el-input>
                            <template v-else-if="param.type === 'select'">
                                <el-select v-if="idx===0" v-model="param.value" @change="setParamText(param, options.field)" :placeholder="param.label" filterable>
                                    <el-option
                                        v-for="(option, index) in options.field"
                                        :key="index"
                                        :label="option.label"
                                        :value="option.value"
                                        :disabled="option.disabled"
                                    >
                                    </el-option>
                                </el-select>

                                
                                <el-select v-model="param.value" @change="paramValueChange(param, paramoptions[item.ruleValue], idx, item)" v-if="idx===1" :placeholder="param.label" filterable>
                                    <el-option
                                        v-for="(option, index) in paramoptions[item.ruleValue]"
                                        :key="index"
                                        :label="option.label"
                                        :value="option.value"
                                        :disabled="option.disabled"
                                    >
                                    </el-option>
                                </el-select>
                                <el-select v-if="idx>1" v-model="param.value" :placeholder="param.label" filterable multiple
                                    @change="paramValueChange(param, paramoptions[item.params[idx-1].value], idx, item)"
                                >
                                    <el-option
                                        v-for="(option, index) in paramoptions[item.params[idx-1].value]"
                                        :key="index"
                                        :label="option.label"
                                        :value="option.value"
                                        :disabled="option.disabled"
                                    >
                                    </el-option>
                                </el-select>
                                



                            </template>
                        </el-form-item>
                    </el-form-item>
                    <!-- 当 那么 -->
                    <template v-else-if="item.ruleType === 2"> 
                        <div v-for="(param, idx) in item.params" :key="idx">
                            <el-form-item label="当" label-width="160px" required class="m-b-0">
                                <el-row v-for="(when,i) in param.when" :key="i">
                                    <el-col :span="8">
                                        <el-form-item
                                            :prop="'boundRule.' + index + '.params.' + idx + '.when.' + i + '.field'"
                                            :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                        >
                                            <el-select v-model="when.field" @change="whenThenFieldChange(when)" placeholder="请选择" filterable>
                                                <el-option
                                                    v-for="(option, index) in options.field"
                                                    :key="index"
                                                    :label="option.label"
                                                    :value="option.value"
                                                    :disabled="option.disabled"
                                                >
                                                </el-option>
                                            </el-select>
                                        </el-form-item>
                                    </el-col>
                                    <el-col :span="8">
                                        <el-form-item
                                            label-width="10px"
                                            :prop="'boundRule.' + index + '.params.' + idx + '.when.' + i + '.operator'"
                                            :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                        >
                                            <el-select v-model="when.operator" @change="whenThenOperatorChange(when)" placeholder="请选择" filterable>
                                                <el-option
                                                    v-for="(option, index) in options.operator"
                                                    :key="index"
                                                    :label="option.label"
                                                    :value="option.value"
                                                    :disabled="option.disabled"
                                                >
                                                </el-option>
                                            </el-select>
                                        </el-form-item>
                                    </el-col>
                                    <el-col :span="8">
                                        <el-form-item
                                            label-width="10px"
                                            :prop="'boundRule.' + index + '.params.' + idx + '.when.' + i + '.value'"
                                            :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                        >
                                            <el-select v-if="when.type === 'select'" v-model="when.value" @change="whenThenValueChange(when)" placeholder="请选择" filterable>
                                                <el-option
                                                    v-for="(option, index) in paramvalueoptions[when.field]"
                                                    :key="index"
                                                    :label="option.label"
                                                    :value="option.value"
                                                    :disabled="option.disabled"
                                                >
                                                </el-option>
                                            </el-select>
                                            <el-input v-else v-model="when.value" @blur="whenThenValueBlur(when)" placeholder="请输入"></el-input>
                                            <div class="qm-form-item-tools">
                                                <el-link v-if="i===param.when.length-1" @click="onAddParam(param.when)" type="primary"><i class="el-icon-circle-plus"></i></el-link>
                                                <el-link v-if="param.when.length>1" @click="onDelRow(param.when, i)" type="danger"><i class="el-icon-remove"></i></el-link>
                                            </div>
                                        </el-form-item>
                                    </el-col>
                                </el-row>
                            </el-form-item>
                            <el-form-item label="那么" label-width="160px" required>
                                <el-row v-for="(then,i) in param.then" :key="i">
                                    <el-col :span="8">
                                        <el-form-item
                                            :prop="'boundRule.' + index + '.params.' + idx + '.then.' + i + '.field'"
                                            :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                        >
                                            <el-select v-model="then.field" @change="whenThenFieldChange(then)" placeholder="请选择" filterable>
                                                <el-option
                                                    v-for="(option, index) in options.field"
                                                    :key="index"
                                                    :label="option.label"
                                                    :value="option.value"
                                                    :disabled="option.disabled"
                                                >
                                                </el-option>
                                            </el-select>
                                        </el-form-item>
                                    </el-col>
                                    <el-col :span="8">
                                        <el-form-item
                                            label-width="10px"
                                            :prop="'boundRule.' + index + '.params.' + idx + '.then.' + i + '.operator'"
                                            :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                        >
                                            <el-select v-model="then.operator" @change="whenThenOperatorChange(then)" placeholder="请选择" filterable>
                                                <el-option
                                                    v-for="(option, index) in options.operator"
                                                    :key="index"
                                                    :label="option.label"
                                                    :value="option.value"
                                                    :disabled="option.disabled"
                                                >
                                                </el-option>
                                            </el-select>
                                        </el-form-item>
                                    </el-col>
                                    <el-col :span="8">
                                        <el-form-item
                                            label-width="10px"
                                            :prop="'boundRule.' + index + '.params.' + idx + '.then.' + i + '.value'"
                                            :rules="{ required: true, message: '请选择', trigger: 'change' }"
                                        >
                                            <el-select v-if="then.type === 'select'" v-model="then.value" @change="whenThenValueChange(then)" placeholder="请选择" filterable>
                                                <el-option
                                                    v-for="(option, index) in paramvalueoptions[then.field]"
                                                    :key="index"
                                                    :label="option.label"
                                                    :value="option.value"
                                                    :disabled="option.disabled"
                                                >
                                                </el-option>
                                            </el-select>
                                            <el-input v-else v-model="then.value" @blur="whenThenValueBlur(then)" placeholder="请输入"></el-input>
                                            <div class="qm-form-item-tools">
                                                <el-link v-if="i===param.then.length-1" @click="onAddParam(param.then)" type="primary"><i class="el-icon-circle-plus"></i></el-link>
                                                <el-link v-if="param.then.length>1" @click="onDelRow(param.then, i)" type="danger"><i class="el-icon-remove"></i></el-link>
                                            </div>
                                        </el-form-item>
                                    </el-col>
                                </el-row>
                            </el-form-item>
                        </div>
                    </template>
                </div>
                <el-form-item label-width="160px">
                    <el-link @click="onAddBoundRule()" type="primary"><i class="el-icon-circle-plus"></i> 添加规则</el-link>
                </el-form-item>
            </el-form>
        </moc-section>
    </moc-container>

</template>
<script>
    /**
     * 混入对象
     */
    import common from '@/mixins/common.js'; // 通用  每个页面都需要引入

    export default {
        mixins: [common],
        props:{
            activeRow: '',
            ruleNameArr: '',
            selects: ''
        },
        data() {
            return {
                ruleForm: {
                    id: '',
                    ruleName: '',           // 校验项规则
                    field:'',               // 规则作用字段
                    fieldName:'',           // 规则作用字段
                    ruleType: 2,            // 1 基础规则后台提供 2添加的规则
                    boundRule:[
                        {
                            ruleLabel: '',                  // 规则名称
                            ruleValue: '',                  // 规则ID
                            ruleType: '',                   // 规则类型
                            s_e_pos:'',
                            params:[                        // 参数
                                // {
                                //     label:'选择字段',
                                //     type: 'select',
                                //     value: '',
                                //     text: ''
                                // },
                                // {
                                //     label:'填写前缀字符',
                                //     type: 'input',
                                //     value: '',
                                //     text: ''
                                // }
                            ]
                        },
                        // {
                        //     ruleLabel: '',
                        //     ruleValue: '',
                        //     ruleType: 2,
                        //     params:[
                        //         {
                        //             when: [                 // 当
                        //                 {
                        //                     field:'字段1',
                        //                     fieldName:'字段1',
                        //                     operator:'操作符',
                        //                     operatorName:'操作符',
                        //                     value:'字段2',
                        //                     valueName:'字段2',
                        //                     type: ''
                        //                 }
                        //             ],
                        //             then: [             // 那么
                        //                 {
                        //                     field:'字段1',
                        //                     fieldName:'字段1',
                        //                     operator:'操作符',
                        //                     operatorName:'操作符',
                        //                     value:'字段2',
                        //                     valueName:'字段2',
                        //                     type: ''
                        //                 }
                        //             ]
                        //         }
                        //     ]
                        // }
                    ]
                },
                /**
                 * 当 boundRule里面选择的ruleType===2时的数据
                 */
                whenthen:[
                    {
                        when: [                 // 当
                            {
                                field:'',
                                fieldName:'',
                                operator:'',
                                operatorName:'',
                                value:'',
                                valueName:'',
                                type: ''
                            }
                        ],
                        then: [             // 那么
                            {
                                field:'',
                                fieldName:'',
                                operator:'',
                                operatorName:'',
                                value:'',
                                valueName:'',
                                type: ''
                            }
                        ]
                    }
                ],

                paramoptions:{},
                paramvalueoptions:{},
                options:{
                    field:[],
                    rule:[
                        // {
                        //     "label":"prov_code 上报省份",
                        //     "value":"123",
                        //     "ruleType": 1,
                        //     "params": [                        // 参数
                        //         {
                        //             label:'选择字段',
                        //             type: 'select',
                        //             value: '',
                        //             text: ''
                        //         },
                        //         {
                        //             label:'填写前缀字符',
                        //             type: 'input',
                        //             value: '',
                        //             text: ''
                        //         }
                        //     ]
                        // },
                        // {
                        //     "label":"主叫号码",
                        //     "value":"1234",
                        //     "ruleType": 1,
                        //     "params": [                        // 参数
                        //         {
                        //             label:'选择字段',
                        //             type: 'select',
                        //             value: '',
                        //             text: ''
                        //         },
                        //         {
                        //             label:'填写前缀字符',
                        //             type: 'input',
                        //             value: '',
                        //             text: ''
                        //         }
                        //     ]
                        // },
                        // {
                        //     "label":"dst_addr(样本的被叫号码)",
                        //     "value":"12345",
                        //     "ruleType": 1,
                        //     "params": [                        // 参数
                        //         {
                        //             label:'选择字段',
                        //             type: 'select',
                        //             value: '',
                        //             text: ''
                        //         },
                        //         {
                        //             label:'填写前缀字符',
                        //             type: 'input',
                        //             value: '',
                        //             text: ''
                        //         }
                        //     ]
                        // },
                        // {
                        //     "label":"关联关系",
                        //     "value":"123456",
                        //     ruleType: 2,
                        //     params:[
                        //         {
                        //             when: [                 // 当
                        //                 {
                        //                     field:'字段1',
                        //                     fieldName:'字段1',
                        //                     operator:'操作符',
                        //                     operatorName:'操作符',
                        //                     value:'字段2',
                        //                     valueName:'字段2',
                        //                 }
                        //             ],
                        //             then: [             // 那么
                        //                 {
                        //                     field:'字段1',
                        //                     fieldName:'字段1',
                        //                     operator:'操作符',
                        //                     operatorName:'操作符',
                        //                     value:'字段2',
                        //                     valueName:'字段2',
                        //                 }
                        //             ]
                        //         }
                        //     ]
                        // }
                    ],
                    operator:[]
                }
            }
        },
        created() {
            if(this.activeRow){
                this.ruleForm = this.activeRow
            }
        },
        mounted() {
            this.initOptions();
        },
        methods: {
            validateRule(rule, value, callback){
                if ( this.ruleNameArr.indexOf(value) >= 0 ) {
                    callback(new Error('校验项规则不可以重复'));
                } else {
                    callback();
                }
            },
            /**
             * 规则的改变事件
             */
            changeRule(rule){
                this.options.rule.forEach(item=>{
                    if( rule.ruleValue === item.value ){
                        rule.ruleType = item.ruleType
                        rule.ruleLabel = item.label
                        if(rule.ruleType===1){
                            rule.params = this.$lodash.cloneDeep(item.enumList)
                        }else if(rule.ruleType===2){
                            rule.params = this.$lodash.cloneDeep(this.whenthen)
                        }
                    }
                })

                // console.log(this.ruleForm.boundRule)
            },
            paramValueBlur(item){
                item.text = item.value
                // console.log(item)
            },
            paramValueChange(obj, options, idx, parent){
                if( typeof obj.value === 'string' ){
                    options.forEach(field=>{
                        if(obj.value === field.value){
                            obj.text = field.label
                        }
                    })
                    /**
                     * 第二项 赋值
                     */
                    let valueArr = []
                    let textArr = []
                    this.paramoptions[obj.value].forEach(field=>{
                       valueArr.push(field.value)
                       textArr.push(field.label)
                    })
                    parent.params[idx+1].value = valueArr
                    parent.params[idx+1].text = textArr.join('，')
                }else if( Array.isArray(obj.value) ){
                    let textArr = []
                    options.forEach(field=>{


                        console.log(obj.value)
                        if(obj.value.indexOf(field.value)!=-1){
                            textArr.push(field.label)
                        }
                    })
                    obj.text = textArr.join('，')
                    
                }
            },
            setParamText(obj, options){
                options.forEach(field=>{
                    if(obj.value === field.value){
                        obj.text = field.label
                    }
                })
            },
            /**
             * 规则的添加、删除
             */
            onAddBoundRule(){
                let obj =  {
                    ruleLabel: '',
                    ruleValue: '',
                    ruleType: '', 
                    s_e_pos:'',
                    params:[]
                }
                this.ruleForm.boundRule.push(obj)
            },
            onAddParam(param){
                let obj = {
                    field:'',
                    fieldName:'',
                    operator:'',
                    operatorName:'',
                    value:'',
                    valueName:''
                }
                param.push(obj)
            },
            onDelRow(rows,index){
                rows.splice(index, 1)
            },
            whenThenFieldChange(item){
                item.value = ''
                this.options.field.forEach(field=>{
                    if( item.field === field.value ){
                        item.fieldName = field.label
                        if(field.enumList){
                            item.type = "select"
                        }else{
                            item.type = "input"
                        }
                    }
                })
            },
            whenThenOperatorChange(item){
                this.options.operator.forEach(operator=>{
                    if( item.operator === operator.value ){
                        item.operatorName = operator.label
                    }
                })
            },
            whenThenValueChange(item){
                this.paramvalueoptions[item.field].forEach(element=>{
                    if( item.value === element.value ){
                        item.valueName = element.label
                    }
                })
            },
            whenThenValueBlur(item){
                item.valueName = item.value
            },
            /**
             * 确定、取消
             */
            onSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        for (let index = 0; index < this.options.field.length; index++) {
                            const element = this.options.field[index];
                            if(this.ruleForm.field === element.value){
                                this.ruleForm.fieldName = element.label
                                break;
                            }
                        }
                        if( !this.ruleForm.id ){
                            this.ruleForm.id = 'validation' + new Date().getTime();
                        }
                        this.$emit('callback', true, this.ruleForm);
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            onCancel() {
                this.$emit('callback', false);
            },

            
            initOptions(){
                this.options.field = this.selects.allFields
                this.options.field.forEach(element=>{
                    if( element.enumList ){
                        this.paramvalueoptions[element.value] = element.enumList
                    }
                })
                this.options.rule = this.selects.basicRules
                this.options.operator = this.selects.operator
                this.paramoptions = this.selects.ruleSel

                // console.log( this.selects )
            }
        }
    }
</script>
