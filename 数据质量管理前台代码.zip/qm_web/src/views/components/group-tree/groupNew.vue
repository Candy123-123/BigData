<template>
    <div class="moc-group-tree">
        <div class="moc-group-tree-header" v-if="showHeader">
            <p class="moc-group-tree-title">{{title}}</p>
            <div class="moc-group-tree-tools">
                <div v-if="appendRoot" @click="addGroupTree" class="moc-group-tree-add">
                    <i class="el-icon-folder-add"></i>
                </div>
            </div>
        </div>
        <div class="moc-group-tree-bodier">
            <div class="moc-group-tree-search" v-if="search">
                <el-input v-model="filterGroupTreeNodeText" placeholder="搜索" suffix-icon="el-icon-search" clearable></el-input>
            </div>
            <div class="moc-group-tree-box">
                <el-tree
                    :data="groupTree"
                    node-key="id"
                    highlight-current
                    :current-node-key="currentNodeKey"
                    :filter-node-method="filterGroupTreeNode"
                    :default-expanded-keys="defaultExpandedKeys"
                    @node-click="nodeClick"
                    :expand-on-click-node=false
                    ref="groupTree"
                    default-expand-all
                >
                    <div class="moc-group-tree-node" slot-scope="{ node, data }">
                        <moc-tooltip
                            :content="node.label"
                            :refName="'id'+data.id"
                            placement="top-start"
                            effect="light"
                            popper-class="generalView"
                            class="moc-group-tree-node-text"
                        >
                        </moc-tooltip>
                        <a @click.stop="nodeContextmenu(node, data)" v-if="data.id !== 'root' && nodeTools && !data.nodeTools" class="moc-group-tree-node-more" href="javascript:;"><i class="el-icon-more"></i></a>
                        <div class="moc-group-tree-node-tools" v-if="data.tools">
                            <span v-if="removeNode && !data.removeNode" @click.stop="deleteGroupTreeNode(data)">删除</span>
                            <span v-if="renameNode && !data.renameNode" @click.stop="renameGroupTreeNode(data)">重命名</span>
                            <span v-if="appendChild && !data.appendChild" @click.stop="addGroupTreeNode(data)">添加子节点</span>
                        </div>
                    </div>
                </el-tree>
            </div>
        </div>
    </div>
</template>

<script>


    export default {
        props: {
            showHeader: {	// 是否显示顶部栏
                type: Boolean,
                default: true
            },
            search: {	// 是否可以搜索
                type: Boolean,
                default: false
            },
            groupTree: {
                type: Array,
                default: () => []
            },
            title: {
                type: String,
                default: '资源'
            },
            //树的属性，包括唯一标识，子节点名称等
            treeProps: {
                type: Object,
                default: () => {
                    return {'nodeKey': 'id', 'label': 'label', 'children': 'children'};
                }
            },
            append: {	// 是否可以添加子节点
                type: Boolean,
                default: false
            },
            nodeTools: {	// 是否显示节点工具栏
                type: Boolean,
                default: true
            },
            //树的类型，document，folder
            treeType: {
                type: String,
                default: 'document'
            },
            //document的标识，和标识值
            documentProps: {
                type: Object,
                default: () => {
                    return {'flag': 'treeFileType', 'documentValue': 1, 'folderValue': 0};
                }
            },
            customAppend: {	// 是否 自定义 添加子节点
                type: Boolean,
                default: false
            },
            appendRoot: {	// 是否可以添加根节点
                type: Boolean,
                default: true
            },
            customAppendRoot: {	// 是否 自定义 添加一级节点
                type: Boolean,
                default: false
            },
            defaultExpandedKeys:{	// 需要展开的节点
                type: Array,
                default: () => []
            },
            //自定义创建分组方法
            addFolderDefine: {type: Function}
            // modelstatus:0,
            //currentNodeKey:""// 默认选中的key
        },
        data() {
            return {
                filterGroupTreeNodeText: "",
                //选中节点
                currentKey: '',
                clickTree: '',
                //展开的节点
                treeExpandData: [],
                currentNodeKey:"",
            }
        },
        created() {
            this.$emit('tree-node-init', '');
        },
        updated() {
        },
        mounted() {
        },
        watch: {
            filterGroupTreeNodeText(val) {
                this.$refs.groupTree.filter(val);
            }
        },
        methods: {
            nodeClick(data, node, dom) {
                //获取id 设置当前节点
                this.currentKey = data.id;
                this.clickTree = data;
                this.$emit('tree-node-click', data);
                this.$refs.groupTree.setCurrentKey(this.currentKey);
            },
            /**
             * 搜索事件
             */
            filterGroupTreeNode(value, data) {
                if (!value) return true;
                return data.label.indexOf(value) !== -1;
            },
            addGroupTree(){
                if( this.customAppendRoot ){
                    this.$emit('custom-append-root', false);
                }else{
                    this.$prompt('你正在添加树的一级子节点', '添加子节点').then(({ value }) => {
                        if(value){
                            let obj = {
                                id: value,
                                label: value,
                                tools: false,
                            };
                            this.createdGroupTreeRoot(obj)
                        }
                    }).catch(() => {
                    });
                }
            }

        }
    };
</script>
<style>
    .neu-group-tree .dm-group-tree {
        height: calc(100% - 120px);
        overflow: auto;
    }

    .neu-group-tree .dm-group-tree-tools {
        right: 5px;
        margin-right: 0;
    }
</style>
