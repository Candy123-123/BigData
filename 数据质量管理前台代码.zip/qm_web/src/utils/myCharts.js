/**
 * 引入echarts
 */
import * as echarts from 'echarts'
const myCharts = {
    
	/**
	 * 封装echarts的柱形图例子
	 * @param  {'string'}   id   		调用插件的dom的ID
	 * @param  {[Array]}   	data  		插件需要的数据
	 * @param  {Function} 	fn   	 	修改options的属性，调用传过来的方法
	 * @param  {Function} 	callback 	事件的回调
	 */
	makeBar:function(id, data, fn, callback){
        var myChart = echarts.init(document.getElementById(id));
		var option={
			tooltip: {
		        trigger: 'axis',
		        axisPointer: {
		            type: 'shadow'
		        }
		    },
			title: data.title,
		    legend: {
                right: 50,
                top: 10,
		        data: data.legend
		        // data: ['直接访问', '邮件营销', '联盟广告', '视频广告', '搜索引擎'],
		    },
		    grid: {
                top: 40,
		        left: 20,
		        right: 50,
		        bottom: 10,
		        containLabel: true
		    },
		    xAxis: {
		        type: 'category',
		        data: data.xAxisData,
                splitLine:{  
                    show:true
                }
		        // data: ['直接访问', '邮件营销', '联盟广告', '视频广告', '搜索引擎'],
		    },
		    yAxis: {
		       type: 'value'
		    },
		    color:['#38506a','#0fb2ee','#3197a5','#ce8d01'],
		    series: data.series
		    /*series: [
                {
                    name: '直接访问',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        show: true,
                        position: 'insideRight'
                    },
                    data: [320, 302, 301, 334, 390, 330, 320]
                },
                {
                    name: '邮件营销',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        show: true,
                        position: 'insideRight'
                    },
                    data: [120, 132, 101, 134, 90, 230, 210]
                }
        	]*/
		};
		if (fn!=undefined) fn(option);
		myChart.clear();
		myChart.setOption(option);
		myChart.on('click', function (params) {
			if (callback!=undefined){
				callback(params);
			}
		});
		return myChart;
    },
};
export default myCharts;
