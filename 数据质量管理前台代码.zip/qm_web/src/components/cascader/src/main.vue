<template>
    <div class="moc-cascader" v-clickoutside="handleClose">
        <el-popover trigger="manual" v-model="visible" :width="width" :placement="placement" popper-class="moc-cascader-popover">
            <div class="moc-cascader-menu" :style="{ height: height+'px' }">
                <div class="moc-cascader-list">
                    <el-input v-model="firstSearch" suffix-icon="el-icon-search" :placeholder="placeholder[0]" class="moc-cascader-search"></el-input>
                    <ul class="moc-cascader-group ">
                        <li @click.stop="onClickFirstList(rootOptions)">
                            <span :class="{'is-active': firstValue == rootOptions.value }"><i class="el-icon-folder"></i>{{ rootOptions.label }}</span>
                            <ul>
                                <li  v-for="(item, index) in firstOptions" :key="index">
                                    <span
                                        :class="{'is-active': firstValue == item.value }"
                                        @click.stop="onClickFirstList( item )"
                                    >
                                        <i :class="item.children && item.children.length>0 ? 'el-icon-folder': 'el-icon-document'"></i>{{item.label}}
                                    </span>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="moc-cascader-list">
                    <el-input v-model="secondSearch" suffix-icon="el-icon-search" :placeholder="placeholder[1]" class="moc-cascader-search"></el-input>
                    <ul class="moc-cascader-group">
                        <li v-for="(item, index) in secondOptions" :key="index">
                            <span
                                :class="{'is-active': secondValue == item.value }"
                                @click.stop="onClickSecondList( item )"
                            >
                                <i :class="item.children && item.children.length>0 ? 'el-icon-folder': 'el-icon-document'"></i>{{item.label}}
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
            <el-input
                v-model="cascaderLabel"
                @focus="handleOpen"
                @keydown.native.esc.stop.prevent="visible = false"
                @keydown.native.tab="visible = false"
				:clearable="clearable"
				@input="handleClear"
                slot="reference"
                :suffix-icon=" visible ? 'el-icon-arrow-up' : 'el-icon-arrow-down'"
            ></el-input>
        </el-popover>
    </div>
</template>

<script>
    import clickoutside from '@/utils/clickoutside';

    export default {
        name: 'mocCascader',
        componentName: 'mocCascader',
        props: {
            value: {				// 选中的值
                type: [String, Number],
                default: ""
            },
            options: {				// 数据
                type: Array,
                default: () => []
            },
            rootOptions: {			// 根目录
                type: Object,
                default: () => {
                    return {
                        value: 'all-options',
					    label: '全部'
                    }
                }
            },
            width: {			// 宽
                type: [String, Number],
                default: "420"
            },
            height: {			// 高
                type: [String, Number],
                default: "280"
            },
            placeholder: {			// 搜索框占位符
                type: Array,
                default: () => ['分组', '标准']
            },
            separator:{				// 分隔符
                type: String,
                default: "-"
            },
            placement:{
                type:String,
                default:"bottom-start"
            },
			clearable:{				// 是否带有清空按钮
			    type: Boolean,
			    default: true
			}
        },
        data() {
            return {
                visible: false,
                /**
                 * 值
                 */
                cascaderLabel:"",
                /**
                 * 第一
                 */
                firstSearch: "",
                firstValue: "",
                firstLabel: "",
                /**
                 * 第二
                 */
                secondSearch: "",
                secondValue: "",
                secondLabel: "",
                secondData:[]
            }
        },
        computed: {
            /**
             * 输出字段搜索的方法
             */
            firstOptions: function(){
                return this.options && this.options.filter( (item)=> {
                    if( item.label == null ){
                        item.label = '';
                    }
                    if( item.label.search(this.firstSearch) !== -1 && item.children && item.children.length>0 ){
                        return item
                    }
                })
            },
            secondOptions: function(){
                return this.secondData && this.secondData.filter( (item)=> {
                    if( item.label == null ){
                        item.label = '';
                    }
                    if( item.label.search(this.secondSearch) !== -1 ){
                        return item
                    }
                })
            }
        },
        watch: {
            value:{
                immediate: true,
                handler(val, oldName) {
                    this.initData(val)
                }
            },
        },
        directives: { clickoutside },
        methods: {
			handleClear(){
				this.$emit('input', null);
			},
            // 展开
            handleOpen(){
                if( this.visible === false ){
                    this.visible = true;
                    this.initData( this.value );
                }
            },
            // 关闭
            handleClose(){
                this.visible = false;
            },
            // 一级点击
            onClickFirstList(item){
                if( item.value === this.rootOptions.value ){
                    this.firstValue = item.value
                    this.allSecondOptions();
                }else{
                    this.firstValue = item.value
                    this.secondData = item.children
                }
            },
            // 二级点击
            onClickSecondList(item){
                this.$emit('input', item.value);
                this.handleClose();
            },
            /**
             * 初始化数据
             */
            initData(val){
                if( val ){
                    let valueArray = val.split( this.separator );
                    if( valueArray.length > 1 ){
                        this.options.forEach(item => {
                            if( valueArray[0] == item.value ){
                                this.firstValue = item.value
                                this.firstLabel = item.label
                                this.secondData = item.children
                            }
                        });
                        this.secondData.forEach(item => {
                            if( val == item.value ){
                                this.secondValue = item.value
                                this.secondLabel = item.label
                                this.cascaderLabel = this.firstLabel + this.separator + item.label
                            }
                        });
                    }else{
                        this.allSecondOptions();
                        this.secondData.forEach(item => {
                            if( val == item.value ){
                                this.firstLabel = ""
                                this.firstValue = this.rootOptions.value

                                this.secondValue = item.value
                                this.secondLabel = item.label
                                this.cascaderLabel = item.label
                            }
                        });
                    }
                }else{
					this.firstValue = ""
					this.secondValue = ""
                    this.allSecondOptions();
                }
            },
            allSecondOptions(){
                this.secondData=[];
                this.options.forEach(item => {
                    if( item.children && item.children.length > 0 ){
                        item.children.forEach(el => {
                            this.secondData.push( el )
                        });
                    }else{
                        this.secondData.push( item )
                    }
                });
            }
        },
    }
</script>